class_name GameScreen
extends Control
## Base class for every full-screen menu page.

var main: Node


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	theme = UiTheme.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	build()


func build() -> void:
	pass


func on_show(_data: Dictionary = {}) -> void:
	pass


func on_hide() -> void:
	pass
