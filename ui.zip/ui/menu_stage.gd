class_name MenuStage
extends Node3D
## Animated 3D diorama behind the menus. Shows the selected character and map mood.

const FURN := "res://assets/furniture/"

var character_root: Node3D
var model: Node3D
var anim: AnimationPlayer
var camera: Camera3D
var key_light: SpotLight3D
var rim_light: SpotLight3D
var fill_light: OmniLight3D
var floor_mesh: MeshInstance3D
var floor_mat: StandardMaterial3D
var backdrop_mat: StandardMaterial3D
var accent_mat: StandardMaterial3D
var env: Environment
var sun: DirectionalLight3D

var _t := 0.0
var _map_id := "suburban"
var _character_id := "barbarian"


func _ready() -> void:
	_build_environment()
	_build_room()
	_build_lighting()
	_build_particles()
	set_map(_map_id)
	set_character(_character_id)


func _process(delta: float) -> void:
	_t += delta
	if character_root and is_instance_valid(character_root):
		character_root.rotation.y += delta * 0.28
	if camera:
		camera.position.x = sin(_t * 0.18) * 0.22
		camera.position.y = 1.78 + sin(_t * 0.31) * 0.035
		camera.look_at(Vector3(0, 1.02, 0.2), Vector3.UP)
	if rim_light:
		rim_light.light_energy = 2.3 + sin(_t * 0.8) * 0.25


func set_character(id: String) -> void:
	_character_id = id
	if character_root and is_instance_valid(character_root):
		character_root.queue_free()
	character_root = Node3D.new()
	character_root.position = Vector3(0, 0.14, 0.2)
	add_child(character_root)
	var data := Config.character_data(id)
	var path: String = data["path"]
	if not ResourceLoader.exists(path):
		return
	var scene: PackedScene = load(path)
	if scene == null:
		return
	model = scene.instantiate()
	character_root.add_child(model)
	model.scale = Vector3.ONE * float(data["scale"]) * 1.08
	anim = _find_anim(model)
	if anim and anim.has_animation("Idle"):
		anim.play("Idle", 0.1)


func set_map(id: String) -> void:
	_map_id = id
	var data := MapData.get_map(id)
	if floor_mat:
		match id:
			"mansion":
				floor_mat.albedo_texture = _tex("marble")
				floor_mat.albedo_color = Color(0.92, 0.9, 0.86)
			"apartment":
				floor_mat.albedo_texture = _tex("terracotta")
				floor_mat.albedo_color = Color(0.8, 0.76, 0.72)
			_:
				floor_mat.albedo_texture = _tex("wood_floor")
				floor_mat.albedo_color = Color(0.9, 0.82, 0.74)
	if backdrop_mat:
		backdrop_mat.albedo_color = data["wall_tint"].darkened(0.18)
	if env:
		env.ambient_light_color = data["ambient"]
		env.fog_light_color = data["fog"].darkened(0.25)
	if sun:
		sun.light_color = data["sun_color"]
		sun.light_energy = float(data["sun_energy"]) * 0.9
	if accent_mat:
		accent_mat.albedo_color = data["accent_tint"]
		accent_mat.emission = data["accent_tint"]
	if rim_light:
		rim_light.light_color = Config.map_data(id)["accent"].lightened(0.15)


func _build_environment() -> void:
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.032, 0.027, 0.048)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.42, 0.4, 0.52)
	env.ambient_light_energy = 0.55
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.16, 0.14, 0.22)
	env.fog_density = 0.012
	env.fog_sky_affect = 0.0
	env.glow_enabled = false
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)


func _build_room() -> void:
	camera = Camera3D.new()
	camera.position = Vector3(0, 1.78, 4.7)
	camera.fov = 44.0
	camera.near = 0.05
	camera.current = true
	add_child(camera)
	camera.look_at(Vector3(0, 1.02, 0.2), Vector3.UP)

	floor_mat = StandardMaterial3D.new()
	floor_mat.albedo_texture = _tex("wood_floor")
	floor_mat.albedo_color = Color(0.9, 0.82, 0.74)
	floor_mat.roughness = 0.9
	floor_mat.uv1_scale = Vector3(8, 8, 1)
	floor_mat.texture_repeat = 0
	floor_mesh = MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(26, 0.2, 22)
	floor_mesh.mesh = fm
	floor_mesh.material_override = floor_mat
	floor_mesh.position = Vector3(0, -0.1, 0)
	add_child(floor_mesh)

	backdrop_mat = StandardMaterial3D.new()
	backdrop_mat.albedo_texture = _tex("stucco")
	backdrop_mat.albedo_color = Color(0.76, 0.72, 0.65)
	backdrop_mat.roughness = 0.95
	backdrop_mat.uv1_scale = Vector3(0.4, 0.4, 0.4)
	backdrop_mat.uv1_triplanar = true
	backdrop_mat.uv1_world_triplanar = true
	_box(Vector3(14, 4.6, 0.24), Vector3(0, 2.3, -3.6), backdrop_mat)
	_box(Vector3(0.24, 4.6, 9), Vector3(-6.2, 2.3, -0.4), backdrop_mat)
	# Baseboards.
	var trim := _simple(Color(0.22, 0.18, 0.15), 0.8)
	_box(Vector3(14, 0.16, 0.1), Vector3(0, 0.08, -3.46), trim)
	_box(Vector3(0.1, 0.16, 9), Vector3(-6.06, 0.08, -0.4), trim)

	# Window with warm light.
	accent_mat = StandardMaterial3D.new()
	accent_mat.albedo_color = Color(0.78, 0.7, 0.58)
	accent_mat.emission_enabled = true
	accent_mat.emission = Color(0.78, 0.7, 0.58)
	accent_mat.emission_energy_multiplier = 0.2
	var frame := _simple(Color(0.18, 0.15, 0.13), 0.6)
	_box(Vector3(3.3, 2.3, 0.12), Vector3(2.9, 2.2, -3.44), frame)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.65, 0.8, 1.0, 0.45)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.emission_enabled = true
	glass.emission = Color(0.55, 0.7, 1.0)
	glass.emission_energy_multiplier = 0.5
	_box(Vector3(3.0, 2.0, 0.08), Vector3(2.9, 2.2, -3.4), glass)
	_box(Vector3(0.08, 2.0, 0.12), Vector3(2.9, 2.2, -3.36), frame)

	# Pedestal.
	var ped := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.15
	cm.bottom_radius = 1.25
	cm.height = 0.16
	cm.radial_segments = 40
	ped.mesh = cm
	ped.material_override = _simple(Color(0.09, 0.08, 0.11), 0.45, 0.15)
	ped.position = Vector3(0, 0.08, 0.2)
	add_child(ped)
	var rim := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 1.14
	tm.outer_radius = 1.2
	tm.rings = 40
	tm.ring_segments = 6
	rim.mesh = tm
	var rim_mat := StandardMaterial3D.new()
	rim_mat.albedo_color = UiTheme.LIME
	rim_mat.emission_enabled = true
	rim_mat.emission = UiTheme.LIME
	rim_mat.emission_energy_multiplier = 1.2
	rim.material_override = rim_mat
	rim.position = Vector3(0, 0.17, 0.2)
	add_child(rim)

	# Furniture dressing.
	_place(FURN + "rug_rectangle_stripes_A.gltf", Vector3(0, 0.02, 0.2), 0, 1.6, false)
	_place(FURN + "couch.gltf", Vector3(-3.4, 0, -2.2), 8, 1.15)
	_place(FURN + "table_low.gltf", Vector3(-1.2, 0, -1.35), -6, 1.0)
	_place(FURN + "lamp_standing.gltf", Vector3(3.9, 0, -2.6), 0, 1.0)
	_place(FURN + "cabinet_medium.gltf", Vector3(5.3, 0, -2.9), -90, 1.0)
	_place(FURN + "cactus_medium_A.gltf", Vector3(-5.3, 0, -2.6), 0, 1.2, false)
	_place(FURN + "book_set.gltf", Vector3(-1.2, 0.5, -1.35), 20, 0.8, false)
	_place(FURN + "pictureframe_large_A.gltf", Vector3(-3.4, 2.1, -3.44), 0, 1.0, false)
	_place(FURN + "chair_A.gltf", Vector3(2.0, 0, -1.1), -150, 1.0)


func _build_lighting() -> void:
	sun = DirectionalLight3D.new()
	sun.light_color = Color(1.0, 0.88, 0.72)
	sun.light_energy = 1.0
	sun.rotation_degrees = Vector3(-52, -35, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 30.0
	add_child(sun)

	key_light = SpotLight3D.new()
	key_light.position = Vector3(3.0, 4.4, 3.4)
	key_light.light_color = Color(1.0, 0.93, 0.82)
	key_light.light_energy = 5.0
	key_light.spot_range = 14.0
	key_light.spot_angle = 36.0
	key_light.spot_attenuation = 1.1
	key_light.shadow_enabled = true
	add_child(key_light)
	key_light.look_at(Vector3(0, 1.0, 0.2), Vector3.UP)

	rim_light = SpotLight3D.new()
	rim_light.position = Vector3(-2.8, 3.2, -2.6)
	rim_light.light_color = UiTheme.LIME
	rim_light.light_energy = 2.4
	rim_light.spot_range = 12.0
	rim_light.spot_angle = 42.0
	add_child(rim_light)
	rim_light.look_at(Vector3(0, 1.2, 0.2), Vector3.UP)

	fill_light = OmniLight3D.new()
	fill_light.position = Vector3(0, 1.6, 3.2)
	fill_light.light_color = Color(0.6, 0.65, 1.0)
	fill_light.light_energy = 0.75
	fill_light.omni_range = 9.0
	add_child(fill_light)


func _build_particles() -> void:
	var p := CPUParticles3D.new()
	p.amount = 34
	p.lifetime = 7.0
	p.preprocess = 5.0
	p.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	p.emission_box_extents = Vector3(5.0, 2.4, 2.6)
	p.direction = Vector3(0, 1, 0)
	p.spread = 30.0
	p.initial_velocity_min = 0.05
	p.initial_velocity_max = 0.22
	p.gravity = Vector3(0, 0.015, 0)
	p.scale_amount_min = 0.3
	p.scale_amount_max = 0.8
	var mesh := SphereMesh.new()
	mesh.radius = 0.022
	mesh.height = 0.044
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.9, 0.65, 0.65)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.85, 0.55)
	mat.emission_energy_multiplier = 2.0
	mesh.material = mat
	p.mesh = mesh
	p.position = Vector3(0, 1.8, 0)
	add_child(p)


func _find_anim(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node
	for child in node.get_children():
		var a := _find_anim(child)
		if a:
			return a
	return null


func _tex(name: String) -> Texture2D:
	var path := "res://assets/textures/" + name + ".jpg"
	if ResourceLoader.exists(path):
		return load(path)
	return null


func _simple(color: Color, roughness: float = 0.8, metallic: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m


func _box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi


func _place(path: String, pos: Vector3, yaw: float, s: float, collide: bool = true) -> Node3D:
	if not ResourceLoader.exists(path):
		return null
	var scene: PackedScene = load(path)
	if scene == null:
		return null
	var inst := scene.instantiate()
	add_child(inst)
	inst.position = pos
	inst.rotation_degrees = Vector3(0, yaw, 0)
	inst.scale = Vector3.ONE * s
	var aabb := _aabb_of(inst)
	if aabb.size != Vector3.ZERO:
		inst.position.y = pos.y - aabb.position.y * s
	if collide and aabb.size != Vector3.ZERO:
		var body := StaticBody3D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		body.position = aabb.get_center()
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = aabb.size * 0.9
		cs.shape = shape
		body.add_child(cs)
		inst.add_child(body)
	return inst


func _aabb_of(root: Node) -> AABB:
	var acc := {"first": true, "aabb": AABB()}
	for child in root.get_children():
		_walk_aabb(child, child.transform, acc)
	return acc["aabb"]


func _walk_aabb(node: Node, xform: Transform3D, acc: Dictionary) -> void:
	if node is MeshInstance3D and node.mesh:
		var mesh_aabb: AABB = node.mesh.get_aabb()
		var a: AABB = xform * mesh_aabb
		if acc["first"]:
			acc["aabb"] = a
			acc["first"] = false
		else:
			acc["aabb"] = acc["aabb"].merge(a)
	for child in node.get_children():
		_walk_aabb(child, xform * child.transform, acc)
