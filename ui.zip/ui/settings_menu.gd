class_name SettingsMenu
extends GameScreen
## Audio, video, accessibility, profile and control bindings.

var _sliders: Dictionary = {}
var _slider_labels: Dictionary = {}
var _checks: Dictionary = {}
var _key_labels: Dictionary = {}
var _name_edit: LineEdit
var _modal: Control
var _modal_title: Label
var _rebinding := ""
var _rebind_buttons: Dictionary = {}


func build() -> void:
	add_child(UiKit.left_shade(1200, 0.9))
	add_child(UiKit.vignette(0.45))
	var margin := UiTheme.margin(40)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)
	root.add_child(UiKit.page_header("SETTINGS", "Tune the chaos until it fits your headphones.", "BACK", func(): main.close_settings()))

	var scroll := UiKit.scroll_page(14)
	root.add_child(scroll)
	var body := UiKit.body_of(scroll)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 16)
	body.add_child(columns)
	var col_a := VBoxContainer.new()
	col_a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col_a.add_theme_constant_override("separation", 14)
	columns.add_child(col_a)
	var col_b := VBoxContainer.new()
	col_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col_b.add_theme_constant_override("separation", 14)
	columns.add_child(col_b)

	col_a.add_child(_audio_panel())
	col_a.add_child(_access_panel())
	col_b.add_child(_video_panel())
	col_b.add_child(_profile_panel())
	body.add_child(_controls_panel())

	# ---- rebind modal
	_modal = Control.new()
	_modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.mouse_filter = Control.MOUSE_FILTER_STOP
	_modal.visible = false
	add_child(_modal)
	var shade := ColorRect.new()
	shade.color = Color(0.02, 0.015, 0.03, 0.78)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.add_child(shade)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.add_child(center)
	var box := UiKit.panel_box(34, Color(0.08, 0.07, 0.105, 0.98), UiTheme.LIME, 18)
	box.custom_minimum_size = Vector2(520, 0)
	center.add_child(box)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 12)
	box.add_child(mv)
	mv.add_child(UiKit.tag_heading("REBINDING", UiTheme.LIME))
	_modal_title = UiTheme.text("Press a key for Move Forward", 24, UiTheme.TEXT)
	_modal_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mv.add_child(_modal_title)
	mv.add_child(UiTheme.muted("Press any keyboard key. Escape cancels. Mouse buttons are fixed.", 13))
	var cancel := UiTheme.button("CANCEL", "GhostButton", 42)
	cancel.pressed.connect(_cancel_rebind)
	mv.add_child(cancel)


func _audio_panel() -> PanelContainer:
	var p := UiKit.panel_box(18)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	v.add_child(UiKit.section("AUDIO", "Everything except the sound of your own regret."))
	v.add_child(_slider("Master volume", "master_volume", 0.0, 1.0, 0.01, func(nv: float): return "%d%%" % int(round(nv * 100.0))))
	v.add_child(_slider("Music volume", "music_volume", 0.0, 1.0, 0.01, func(nv: float): return "%d%%" % int(round(nv * 100.0))))
	v.add_child(_slider("Effects volume", "sfx_volume", 0.0, 1.0, 0.01, func(nv: float): return "%d%%" % int(round(nv * 100.0))))
	var test := UiTheme.button("PLAY A TEST SOUND", "GhostButton", 38)
	test.pressed.connect(func(): Audio.play_sfx("sparkle", -6.0, 1.1))
	v.add_child(test)
	return p


func _video_panel() -> PanelContainer:
	var p := UiKit.panel_box(18)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(UiKit.section("VIDEO", "Make it smooth, or make it pretty. Pick a lane."))
	v.add_child(_toggle("Fullscreen", "Borderless window, maximum presence.", "fullscreen"))
	v.add_child(_toggle("V-Sync", "Prevents screen tearing.", "vsync"))
	v.add_child(_toggle("Shadows", "Turn off for older hardware.", "shadows"))
	v.add_child(_toggle("Show FPS", "A small counter in the corner.", "show_fps"))
	v.add_child(_slider("Field of view", "fov", 60.0, 110.0, 1.0, func(nv: float): return "%d°" % int(nv)))
	return p


func _access_panel() -> PanelContainer:
	var p := UiKit.panel_box(18)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(UiKit.section("ACCESSIBILITY", "More readable. Less wobble. Same amount of shame."))
	v.add_child(_toggle("Captions", "Show important audio cues as text.", "captions"))
	v.add_child(_slider("UI scale", "ui_scale", 0.75, 1.35, 0.05, func(nv: float): return "%d%%" % int(round(nv * 100.0))))
	v.add_child(_slider("Camera shake", "camera_shake", 0.0, 1.5, 0.05, func(nv: float): return "%d%%" % int(round(nv * 100.0))))
	v.add_child(_slider("Mouse sensitivity", "sensitivity", 0.3, 3.0, 0.05, func(nv: float): return "%.1fx" % nv))
	v.add_child(_toggle("Invert vertical look", "For the pilots and the contrarians.", "invert_y"))
	return p


func _profile_panel() -> PanelContainer:
	var p := UiKit.panel_box(18)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	p.add_child(v)
	v.add_child(UiKit.section("PROFILE", "The name everyone will shout across the house."))
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = "Your display name"
	_name_edit.max_length = 18
	_name_edit.custom_minimum_size = Vector2(0, 44)
	v.add_child(_name_edit)
	var save := UiTheme.button("SAVE NAME", "GhostButton", 38)
	save.pressed.connect(_commit_name)
	v.add_child(save)
	var stats := UiKit.kv("Matches played", str(Settings.matches_played), UiTheme.TEXT, 14)
	stats.name = "MatchesRow"
	v.add_child(stats)
	var xp := UiKit.kv("Total XP", str(Settings.total_xp), UiTheme.GOLD, 14)
	xp.name = "XpRow"
	v.add_child(xp)
	var note := UiTheme.muted("Character changes live on the main menu and in the lobby.", 12)
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(note)
	return p


func _controls_panel() -> PanelContainer:
	var p := UiKit.panel_box(18)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	p.add_child(v)
	v.add_child(UiKit.section("CONTROLS", "Rebind anything. The mouse throw stays on left click."))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 26)
	grid.add_theme_constant_override("v_separation", 5)
	v.add_child(grid)
	for action in Config.ACTION_LABELS.keys():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 9)
		grid.add_child(row)
		var label := UiTheme.text(str(Config.ACTION_LABELS[action]), 14, UiTheme.TEXT)
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var key := UiKit.keycap(Config.key_name_for_action(action))
		key.custom_minimum_size = Vector2(72, 0)
		row.add_child(key)
		_key_labels[action] = key.get_child(0) as Label
		var rebind := UiTheme.button("REBIND", "GhostButton", 30)
		rebind.custom_minimum_size = Vector2(82, 30)
		rebind.add_theme_font_size_override("font_size", 11)
		rebind.pressed.connect(func(): _begin_rebind(action))
		row.add_child(rebind)
		_rebind_buttons[action] = rebind
	var reset := UiTheme.button("RESET ALL CONTROLS", "DangerButton", 38)
	reset.custom_minimum_size = Vector2(230, 38)
	reset.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	reset.pressed.connect(func():
		Settings.reset_bindings()
		_sync_bindings()
	)
	v.add_child(reset)
	return p


func _slider(title: String, key: String, minv: float, maxv: float, step: float, fmt: Callable) -> VBoxContainer:
	var row := UiKit.slider_row(title, minv, maxv, step, float(Settings.get(key)), fmt, func(nv: float): Settings.set_value(key, nv))
	_sliders[key] = row.get_meta("slider")
	_slider_labels[key] = row.get_meta("value_label")
	return row


func _toggle(title: String, desc: String, key: String) -> HBoxContainer:
	var row := UiKit.toggle_row(title, desc, bool(Settings.get(key)), func(v: bool): Settings.set_value(key, v))
	_checks[key] = row.get_meta("check")
	return row


func on_show(_data: Dictionary = {}) -> void:
	_sync_all()


func on_hide() -> void:
	_cancel_rebind()


func _sync_all() -> void:
	for key in _sliders.keys():
		var s: HSlider = _sliders[key]
		s.set_value_no_signal(float(Settings.get(key)))
	for key in _checks.keys():
		var c: CheckButton = _checks[key]
		c.set_pressed_no_signal(bool(Settings.get(key)))
	_sync_bindings()
	if _name_edit:
		_name_edit.text = Settings.player_name
	var matches := find_child("MatchesRow", true, false)
	if matches:
		var lbl := matches.get_child(1) as Label
		if lbl:
			lbl.text = str(Settings.matches_played)
	var xp := find_child("XpRow", true, false)
	if xp:
		var lbl := xp.get_child(1) as Label
		if lbl:
			lbl.text = str(Settings.total_xp)


func _sync_bindings() -> void:
	for action in _key_labels.keys():
		var lbl: Label = _key_labels[action]
		if lbl:
			lbl.text = Config.key_name_for_action(action)


func _commit_name() -> void:
	var clean := _name_edit.text.strip_edges().substr(0, 18)
	if clean.is_empty():
		clean = Settings.player_name
	_name_edit.text = clean
	Settings.set_value("player_name", clean)
	if Net.is_online():
		Net.set_player_name(clean)


func _begin_rebind(action: String) -> void:
	_rebinding = action
	_modal_title.text = "Press a key for %s" % str(Config.ACTION_LABELS.get(action, action))
	_modal.visible = true
	Audio.play_ui("click")


func _cancel_rebind() -> void:
	_rebinding = ""
	if _modal:
		_modal.visible = false


func _input(event: InputEvent) -> void:
	if _rebinding.is_empty():
		return
	if event is InputEventKey:
		var k := event as InputEventKey
		if not k.pressed or k.echo:
			return
		get_viewport().set_input_as_handled()
		if k.physical_keycode == KEY_ESCAPE:
			_cancel_rebind()
			return
		Settings.set_binding(_rebinding, k.physical_keycode)
		_cancel_rebind()
		_sync_bindings()
		Audio.play_sfx("sparkle", -8.0, 1.2)
