class_name ResultsScreen
extends Control
## End-of-round recap: winner, score table, highlights and progression.

var main: Node
var _content: VBoxContainer
var _result: Dictionary = {}
var _confetti: CPUParticles2D


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	theme = UiTheme.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.025, 0.02, 0.038, 0.93)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	add_child(UiKit.vignette(0.65))

	_confetti = CPUParticles2D.new()
	_confetti.emitting = false
	_confetti.amount = 90
	_confetti.lifetime = 4.5
	_confetti.one_shot = true
	_confetti.explosiveness = 0.55
	_confetti.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	_confetti.emission_rect_extents = Vector2(760, 12)
	_confetti.position = Vector2(800, -20)
	_confetti.direction = Vector2(0, 1)
	_confetti.spread = 22.0
	_confetti.initial_velocity_min = 160.0
	_confetti.initial_velocity_max = 420.0
	_confetti.gravity = Vector2(0, 220)
	_confetti.angular_velocity_min = -180.0
	_confetti.angular_velocity_max = 180.0
	_confetti.scale_amount_min = 3.0
	_confetti.scale_amount_max = 7.0
	_confetti.color = UiTheme.LIME
	var ramp := Gradient.new()
	ramp.colors = PackedColorArray([UiTheme.LIME, UiTheme.GOLD, UiTheme.PINK, UiTheme.BLUE, UiTheme.LIME])
	_confetti.color_ramp = ramp
	add_child(_confetti)

	var margin := UiTheme.margin(34)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)
	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 12)
	scroll.add_child(_content)


func set_result(result: Dictionary) -> void:
	_result = result
	visible = true
	for child in _content.get_children():
		child.queue_free()
	_build_content()


func _build_content() -> void:
	var winner := str(_result.get("winner", "runners"))
	var runners_won := winner == "runners"
	var accent := UiTheme.LIME if runners_won else UiTheme.PINK
	var rows: Array = _result.get("rows", [])
	var elapsed := maxf(0.0, Game.match_time - float(_result.get("time_left", Game.time_left)))

	# ---- banner
	var banner := UiKit.panel_box(26, Color(0.07, 0.06, 0.095, 0.97), Color(accent.r, accent.g, accent.b, 0.5), 20)
	_content.add_child(banner)
	var bv := VBoxContainer.new()
	bv.add_theme_constant_override("separation", 2)
	banner.add_child(bv)
	var tag := UiKit.tag_heading("ROUND COMPLETE", accent)
	tag.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bv.add_child(tag)
	var title := UiTheme.text_label("RUNNERS WIN" if runners_won else "CHASERS WIN", 64, accent)
	title.add_theme_font_override("font", UiTheme.title_font())
	title.add_theme_font_size_override("font_size", 68)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_constant_override("outline_size", 8)
	title.add_theme_color_override("font_outline_color", Color(0.02, 0.015, 0.03, 0.8))
	bv.add_child(title)
	var sub := UiTheme.text("%s  ·  %s  ·  %d players" % [
		str(_result.get("map_name", "Unknown")),
		Config.time_string(elapsed),
		rows.size(),
	], 15, UiTheme.MUTED)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bv.add_child(sub)
	if bool(_result.get("local_won", false)):
		var you := UiTheme.text_label("YOU WERE ON THE WINNING SIDE", 12, UiTheme.GOLD)
		you.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		bv.add_child(you)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 12)
	_content.add_child(columns)

	# ---- table
	var table_panel := UiKit.panel_box(18, Color(0.06, 0.05, 0.08, 0.96), Color(1, 1, 1, 0.1), 16)
	table_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(table_panel)
	var tv := VBoxContainer.new()
	tv.add_theme_constant_override("separation", 5)
	table_panel.add_child(tv)
	tv.add_child(UiKit.section("THE SCOREBOARD", "Sorted by XP. Shame is not a column yet."))
	var head := _row(["#", "PLAYER", "ROLE", "CATCHES", "CAUGHT", "HIDDEN", "PROPS", "XP"], true, UiTheme.MUTED)
	tv.add_child(head)
	for i in rows.size():
		var row: Dictionary = rows[i]
		var local := int(row.get("id", -1)) == Game.local_peer_id
		var role := int(row.get("role", 0))
		var name_text := str(row.get("name", "Player"))
		if bool(row.get("bot", false)):
			name_text += "  [BOT]"
		var values := [
			str(i + 1),
			name_text,
			Config.role_icon(role) + " " + Config.role_name(role),
			str(int(row.get("catches", 0))),
			str(int(row.get("caught", 0))),
			"%.1fs" % float(row.get("hidden", 0.0)),
			str(int(row.get("props", 0))),
			"+%d" % int(row.get("xp", 0)),
		]
		var r := _row(values, false, UiTheme.TEXT)
		if local:
			var sb := StyleBoxFlat.new()
			sb.bg_color = Color(accent.r, accent.g, accent.b, 0.13)
			sb.border_color = Color(accent.r, accent.g, accent.b, 0.5)
			sb.set_border_width_all(1)
			sb.set_corner_radius_all(8)
			sb.content_margin_left = 8
			sb.content_margin_right = 8
			sb.content_margin_top = 4
			sb.content_margin_bottom = 4
			r.add_theme_stylebox_override("panel", sb)
		else:
			var sb2 := StyleBoxFlat.new()
			sb2.bg_color = Color(1, 1, 1, 0.025)
			sb2.set_corner_radius_all(8)
			sb2.content_margin_left = 8
			sb2.content_margin_right = 8
			sb2.content_margin_top = 4
			sb2.content_margin_bottom = 4
			r.add_theme_stylebox_override("panel", sb2)
		tv.add_child(r)

	# ---- side column
	var side := VBoxContainer.new()
	side.custom_minimum_size = Vector2(380, 0)
	side.add_theme_constant_override("separation", 12)
	columns.add_child(side)

	var xp_panel := UiKit.panel_box(18, Color(0.07, 0.06, 0.09, 0.96), Color(UiTheme.GOLD.r, UiTheme.GOLD.g, UiTheme.GOLD.b, 0.4), 16)
	side.add_child(xp_panel)
	var xv := VBoxContainer.new()
	xv.add_theme_constant_override("separation", 5)
	xp_panel.add_child(xv)
	xv.add_child(UiKit.tag_heading("PROGRESS", UiTheme.GOLD))
	var gained := UiTheme.text_label("+%d XP" % int(_result.get("local_xp", 0)), 40, UiTheme.GOLD)
	gained.add_theme_font_override("font", UiTheme.title_font())
	gained.add_theme_font_size_override("font_size", 44)
	xv.add_child(gained)
	var level := 1 + int(Settings.total_xp / 500)
	var into := Settings.total_xp % 500
	xv.add_child(UiKit.kv("Level", str(level), UiTheme.TEXT, 14))
	xv.add_child(UiKit.kv("Total XP", str(Settings.total_xp), UiTheme.TEXT, 14))
	var bar := ProgressBar.new()
	bar.max_value = 500
	bar.value = into
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 9)
	xv.add_child(bar)
	xv.add_child(UiTheme.muted("%d XP to level %d" % [500 - into, level + 1], 12))

	var highlights: Array = _result.get("highlights", [])
	var hi_panel := UiKit.panel_box(18, Color(0.065, 0.055, 0.085, 0.96), Color(1, 1, 1, 0.1), 16)
	side.add_child(hi_panel)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 5)
	hi_panel.add_child(hv)
	hv.add_child(UiKit.tag_heading("MOMENTS OF SHAME", UiTheme.PINK))
	for h in highlights:
		var l := UiTheme.text("✦  " + str(h), 13, UiTheme.TEXT)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		hv.add_child(l)

	# ---- actions
	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 9)
	_content.add_child(actions)
	var can_rematch := Game.is_solo or Net.is_hosting()
	if can_rematch:
		var rematch := UiTheme.button("REMATCH", "PrimaryButton", 54)
		rematch.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		rematch.pressed.connect(func(): main.rematch())
		actions.add_child(rematch)
	else:
		var wait := UiTheme.button("WAITING FOR HOST TO REMATCH...", "GhostButton", 54)
		wait.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		wait.disabled = true
		actions.add_child(wait)
	if Net.is_online():
		var lobby := UiTheme.button("BACK TO LOBBY", "GhostButton", 54)
		lobby.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lobby.pressed.connect(func(): main.return_to_lobby())
		actions.add_child(lobby)
	var menu := UiTheme.button("MAIN MENU", "GhostButton", 54)
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu.pressed.connect(func(): main.leave_match())
	actions.add_child(menu)

	if runners_won:
		_confetti.position = Vector2(800, -30)
		_confetti.restart()
	else:
		_confetti.emitting = false


func _row(values: Array, header: bool, color: Color) -> PanelContainer:
	var p := PanelContainer.new()
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 4)
	p.add_child(h)
	var widths := [34, 0, 122, 70, 66, 76, 60, 70]
	for i in values.size():
		var l := UiTheme.text_label(str(values[i]), 12 if header else 14, color)
		if i == 1:
			l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			l.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
		else:
			l.custom_minimum_size = Vector2(widths[i], 0)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT if i > 1 else HORIZONTAL_ALIGNMENT_LEFT
		if header:
			l.add_theme_color_override("font_color", UiTheme.MUTED)
		h.add_child(l)
	return p
