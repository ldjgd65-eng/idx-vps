class_name GameHUD
extends Control
## In-match HUD: timer, role, stamina, prompts, abilities, feed, scoreboard and emotes.

var player: Player
var timer_label: Label
var runner_label: Label
var role_panel: PanelContainer
var role_title: Label
var role_objective: Label
var stamina_bar: ProgressBar
var stamina_label: Label
var prop_label: Label
var prompt_panel: PanelContainer
var prompt_label: Label
var event_box: VBoxContainer
var ability_box: VBoxContainer
var sense_bar: ProgressBar
var hint_bar: ProgressBar
var catch_bar: ProgressBar
var countdown_label: Label
var banner_label: Label
var hint_arrow: Control
var hint_text: Label
var crosshair: Control
var hidden_overlay: Control
var flash_rect: ColorRect
var scoreboard: Control
var scoreboard_rows: VBoxContainer
var emote_panel: Control
var captions: VBoxContainer
var fps_label: Label
var objective_tag: Label

var _hint_dir := Vector3.ZERO
var _hint_time := 0.0
var _event_times: Array = []
var _banner_time := 0.0
var _scoreboard_timer := 0.0
var _emote_open := false
var _sense_flash := 0.0
var _last_state := -1


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build()
	Game.timer_changed.connect(_on_timer)
	Game.countdown_changed.connect(_on_countdown)
	Game.match_event.connect(_on_event)
	Game.state_changed.connect(_on_state)
	Game.hint_ping.connect(_on_hint)
	Game.sense_ping.connect(_on_sense)
	Audio.caption_shown.connect(_on_caption)


func setup(p: Player) -> void:
	player = p
	if player:
		player.stamina_changed.connect(_on_stamina)
		player.prompt_changed.connect(_on_prompt)
		player.hidden_changed.connect(_on_hidden)
		player.scoreboard_toggled.connect(show_scoreboard)
		player.emote_menu_requested.connect(toggle_emote)
		player.role_changed_local.connect(set_role)
		player.ability_used.connect(_on_ability)
		_on_stamina(player.stamina)
		set_role(player.role)
		_on_prompt("")
	_on_timer(Game.time_left)
	_on_state(Game.state)


# ------------------------------------------------------------------ build

func _build() -> void:
	# Role card (top left) - improved responsive positioning
	role_panel = PanelContainer.new()
	role_panel.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	role_panel.add_theme_stylebox_override("panel", UiTheme.panel(Color(0.06, 0.05, 0.08, 0.85), Color(1, 1, 1, 0.15), 16))
	role_panel.custom_minimum_size = Vector2(320, 100)
	role_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(role_panel)
	var rv := UiTheme.vbox(3)
	rv.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	role_panel.add_child(rv)
	var top := UiTheme.hbox(8)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rv.add_child(top)
	objective_tag = UiTheme.tag("YOU ARE", UiTheme.MUTED)
	top.add_child(objective_tag)
	role_title = UiTheme.text_label("RUNNER", 27, UiTheme.LIME)
	role_title.add_theme_font_override("font", UiTheme.title_font())
	role_title.add_theme_font_size_override("font_size", 30)
	rv.add_child(role_title)
	role_objective = UiTheme.muted("Survive until the timer runs out.", 13)
	role_objective.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	role_objective.custom_minimum_size = Vector2(0, 0)
	role_objective.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rv.add_child(role_objective)

	# Timer (top center) - improved responsive positioning
	var timer_box := VBoxContainer.new()
	timer_box.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	timer_box.add_theme_constant_override("separation", -8)
	timer_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	timer_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	timer_box.custom_minimum_size = Vector2(280, 80)
	timer_box.alignment = BoxContainer.ALIGNMENT_CENTER
	timer_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(timer_box)
	timer_label = UiTheme.text_label("5:00", 52, UiTheme.TEXT)
	timer_label.add_theme_font_override("font", UiTheme.title_font())
	timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	timer_label.add_theme_constant_override("outline_size", 6)
	timer_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	timer_label.add_theme_color_override("font_color", UiTheme.GOLD)
	timer_box.add_child(timer_label)
	runner_label = UiTheme.text_label("6 RUNNERS", 14, UiTheme.MUTED)
	runner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	runner_label.add_theme_color_override("font_color", UiTheme.TEXT)
	timer_box.add_child(runner_label)

	# Event feed (top right) - improved responsive positioning
	event_box = VBoxContainer.new()
	event_box.set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT)
	event_box.add_theme_constant_override("separation", 6)
	event_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	event_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	event_box.custom_minimum_size = Vector2(380, 10)
	event_box.alignment = BoxContainer.ALIGNMENT_END
	event_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(event_box)

	# Stamina + held prop (bottom left) - improved responsive positioning
	var stamina_box := VBoxContainer.new()
	stamina_box.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	stamina_box.add_theme_constant_override("separation", 6)
	stamina_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stamina_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	stamina_box.custom_minimum_size = Vector2(300, 80)
	stamina_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(stamina_box)
	var stam_head := UiTheme.hbox(8)
	stam_head.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stamina_box.add_child(stam_head)
	stam_head.add_child(UiTheme.tag("STAMINA", UiTheme.LIME))
	stamina_label = UiTheme.text_label("100", 12, UiTheme.TEXT)
	stam_head.add_child(stamina_label)
	stamina_bar = ProgressBar.new()
	stamina_bar.custom_minimum_size = Vector2(280, 12)
	stamina_bar.max_value = 100
	stamina_bar.value = 100
	stamina_bar.show_percentage = false
	stamina_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stamina_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stamina_box.add_child(stamina_bar)
	prop_label = UiTheme.text_label("", 15, UiTheme.GOLD)
	prop_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prop_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stamina_box.add_child(prop_label)

	# Prompt (bottom center) - improved responsive positioning
	prompt_panel = PanelContainer.new()
	prompt_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	prompt_panel.add_theme_stylebox_override("panel", UiTheme.panel(Color(0.05, 0.045, 0.07, 0.9), Color(1, 1, 1, 0.18), 25))
	prompt_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	prompt_panel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	prompt_panel.custom_minimum_size = Vector2(420, 54)
	prompt_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(prompt_panel)
	prompt_label = UiTheme.text_label("", 17, UiTheme.TEXT)
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_label.add_theme_color_override("font_color", UiTheme.GOLD)
	prompt_panel.add_child(prompt_label)
	prompt_panel.visible = false

	# Abilities (bottom right) - improved responsive positioning
	ability_box = VBoxContainer.new()
	ability_box.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	ability_box.add_theme_constant_override("separation", 8)
	ability_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ability_box.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ability_box.custom_minimum_size = Vector2(220, 100)
	ability_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(ability_box)
	sense_bar = _ability_row("SENSE", "Q", UiTheme.PINK)
	hint_bar = _ability_row("HINT", "Q", UiTheme.BLUE)
	catch_bar = _ability_row("CATCH", "F", UiTheme.GOLD)

	# Crosshair - improved responsive positioning
	crosshair = Crosshair.new()
	crosshair.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	crosshair.add_theme_stylebox_override("panel", UiTheme.panel(Color(1, 1, 1, 0.1), Color.WHITE, 12, 2))
	crosshair.custom_minimum_size = Vector2(20, 20)
	crosshair.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(crosshair)

	# Countdown - improved responsive positioning
	countdown_label = UiTheme.text_label("", 140, UiTheme.TEXT)
	countdown_label.add_theme_font_override("font", UiTheme.title_font())
	countdown_label.add_theme_constant_override("outline_size", 16)
	countdown_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	countdown_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	countdown_label.custom_minimum_size = Vector2(0, 0)
	countdown_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	countdown_label.size_flags_vertical = Control.SIZE_EXPAND_FILL
	countdown_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	countdown_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	countdown_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(countdown_label)

	# Banner - improved responsive positioning
	banner_label = UiTheme.text_label("", 44, UiTheme.TEXT)
	banner_label.add_theme_font_override("font", UiTheme.title_font())
	banner_label.add_theme_constant_override("outline_size", 10)
	banner_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	banner_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	banner_label.add_theme_color_override("font_color", UiTheme.GOLD)
	banner_label.custom_minimum_size = Vector2(0, 80)
	banner_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	banner_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	banner_label.modulate.a = 0.0
	add_child(banner_label)

	# Hint arrow - improved responsive positioning
	hint_arrow = HintArrow.new()
	hint_arrow.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	hint_arrow.add_theme_stylebox_override("panel", UiTheme.panel(Color(1, 1, 1, 0.1), Color.WHITE, 8, 1))
	hint_arrow.custom_minimum_size = Vector2(120, 120)
	hint_arrow.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_arrow.visible = false
	add_child(hint_arrow)
	hint_text = UiTheme.text_label("", 16, UiTheme.BLUE)
	hint_text.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	hint_text.add_theme_color_override("font_color", UiTheme.GOLD)
	hint_text.custom_minimum_size = Vector2(300, 30)
	hint_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hint_text.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_text.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hint_text.visible = false
	add_child(hint_text)

	# Hidden overlay - improved responsive positioning
	hidden_overlay = Control.new()
	hidden_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hidden_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hidden_overlay.visible = false
	add_child(hidden_overlay)
	var hb := ColorRect.new()
	hb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hb.color = Color(0.01, 0.01, 0.02, 0.65)
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hidden_overlay.add_child(hb)
	var ht := UiTheme.text_label("HIDDEN", 64, UiTheme.BLUE)
	ht.add_theme_font_override("font", UiTheme.title_font())
	ht.add_theme_constant_override("outline_size", 10)
	ht.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	ht.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	ht.add_theme_color_override("font_color", UiTheme.GOLD)
	ht.custom_minimum_size = Vector2(0, 100)
	ht.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ht.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ht.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hidden_overlay.add_child(ht)
	var hs := UiTheme.text_label("Press E to leave the hiding spot", 17, UiTheme.MUTED)
	hs.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	hs.custom_minimum_size = Vector2(0, 40)
	hs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hs.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hs.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hidden_overlay.add_child(hs)

	# Damage / sense flash.
	flash_rect = ColorRect.new()
	flash_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	flash_rect.color = Color(1, 0.2, 0.2, 0)
	flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(flash_rect)

	# Captions - improved responsive positioning
	captions = VBoxContainer.new()
	captions.set_anchors_and_offsets_preset(Control.PRESET_CENTER_BOTTOM)
	captions.add_theme_constant_override("separation", 8)
	captions.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	captions.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	captions.custom_minimum_size = Vector2(0, 50)
	captions.alignment = BoxContainer.ALIGNMENT_END
	captions.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(captions)

	# FPS - improved responsive positioning
	fps_label = UiTheme.text_label("", 12, UiTheme.MUTED)
	fps_label.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	fps_label.add_theme_color_override("font_color", UiTheme.GOLD)
	fps_label.custom_minimum_size = Vector2(0, 0)
	fps_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	fps_label.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fps_label.visible = Settings.show_fps
	add_child(fps_label)

	_build_scoreboard()
	_build_emote_panel()


func _ability_row(title_text: String, key: String, color: Color) -> ProgressBar:
	var row := VBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var head := UiTheme.hbox(6)
	head.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var t := UiTheme.tag(title_text, color)
	head.add_child(t)
	head.add_child(UiTheme.spacer())
	head.add_child(UiTheme.text_label(key, 11, UiTheme.MUTED))
	row.add_child(head)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(240, 9)
	bar.max_value = 1.0
	bar.value = 1.0
	bar.show_percentage = false
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill := StyleBoxFlat.new()
	fill.bg_color = color
	fill.set_corner_radius_all(5)
	bar.add_theme_stylebox_override("fill", fill)
	row.add_child(bar)
	ability_box.add_child(row)
	return bar


func _build_scoreboard() -> void:
	scoreboard = Control.new()
	scoreboard.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scoreboard.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scoreboard.visible = false
	add_child(scoreboard)
	var bg := ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.02, 0.018, 0.03, 0.82)
	scoreboard.add_child(bg)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scoreboard.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(820, 520)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(panel)
	var v := UiTheme.vbox(10)
	panel.add_child(v)
	v.add_child(UiTheme.heading("MATCH STATUS", 32))
	v.add_child(UiTheme.separator())
	var header := UiTheme.hbox(10)
	header.add_child(_col_label("PLAYER", 300))
	header.add_child(_col_label("ROLE", 140))
	header.add_child(_col_label("CATCHES", 110))
	header.add_child(_col_label("CAUGHT", 110))
	header.add_child(_col_label("HIDDEN", 100))
	v.add_child(header)
	scoreboard_rows = UiTheme.vbox(4)
	v.add_child(scoreboard_rows)
	v.add_child(UiTheme.spacer())
	v.add_child(UiTheme.muted("Hold TAB to view. Release to return to the chase."))


func _col_label(text: String, width: int) -> Label:
	var l := UiTheme.tag(text, UiTheme.MUTED)
	l.custom_minimum_size = Vector2(width, 0)
	return l


func _build_emote_panel() -> void:
	emote_panel = PanelContainer.new()
	emote_panel.set_anchors_preset(Control.PRESET_CENTER)
	emote_panel.position = Vector2(180, -140)
	emote_panel.custom_minimum_size = Vector2(260, 280)
	emote_panel.visible = false
	add_child(emote_panel)
	var v := UiTheme.vbox(8)
	emote_panel.add_child(v)
	v.add_child(UiTheme.heading("EMOTES", 22))
	v.add_child(UiTheme.muted("Click one. Esc to close.", 12))
	for entry in [["Cheer", "cheer"], ["Dodge", "dodge"], ["Sit", "sit"], ["Punch", "punch"]]:
		var b := UiTheme.button(str(entry[0]), "", 42)
		b.pressed.connect(func():
			if player and is_instance_valid(player):
				player.play_emote(str(entry[1]))
			toggle_emote()
		)
		v.add_child(b)


# ------------------------------------------------------------------ updates

func _process(delta: float) -> void:
	if player and is_instance_valid(player):
		stamina_bar.value = player.stamina
		stamina_label.text = "%d" % int(player.stamina)
		if player.held_prop.is_empty():
			prop_label.text = ""
		else:
			prop_label.text = "HOLDING: %s   [LMB] throw   [G] drop" % player.held_prop.to_upper()
		var sense_max: float = Player.SENSE_COOLDOWN
		var hint_max: float = Player.HINT_COOLDOWN
		var catch_max: float = Player.CATCH_COOLDOWN
		sense_bar.value = 1.0 - clampf(player.sense_cd / sense_max, 0.0, 1.0)
		hint_bar.value = 1.0 - clampf(player.hint_cd / hint_max, 0.0, 1.0)
		catch_bar.value = 1.0 - clampf(player.catch_cd / catch_max, 0.0, 1.0)
		sense_bar.visible = player.role == Config.Role.CHASER
		catch_bar.visible = player.role == Config.Role.CHASER
		hint_bar.visible = player.role == Config.Role.HELPER
		crosshair.visible = not player.hidden and player.role != Config.Role.HELPER
		_update_hint(delta)
		if player.role == Config.Role.HELPER:
			role_objective.text = "Free-fly and send hints. [Q] Reveal Hint"
		elif player.role == Config.Role.CHASER:
			role_objective.text = "Catch every Runner before the timer ends."
		elif player.role == Config.Role.RUNNER:
			role_objective.text = "Survive until the timer runs out."
		fps_label.visible = Settings.show_fps
		if Settings.show_fps:
			fps_label.text = "%d FPS" % Engine.get_frames_per_second()
		if _emote_open and not Game.paused:
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	if _banner_time > 0.0:
		_banner_time -= delta
		banner_label.modulate.a = clampf(_banner_time / 0.5, 0.0, 1.0)
	if _sense_flash > 0.0:
		_sense_flash = maxf(0.0, _sense_flash - delta)
		flash_rect.color = Color(1.0, 0.25, 0.2, _sense_flash * 0.28)
	else:
		flash_rect.color.a = 0.0
	if scoreboard.visible:
		_scoreboard_timer -= delta
		if _scoreboard_timer <= 0.0:
			_scoreboard_timer = 0.35
			_refresh_scoreboard()
	_update_events(delta)


func _update_hint(delta: float) -> void:
	if _hint_time <= 0.0:
		hint_arrow.visible = false
		hint_text.visible = false
		return
	_hint_time -= delta
	hint_arrow.visible = true
	hint_text.visible = true
	var local := _hint_dir.rotated(Vector3.UP, -player.camera_yaw)
	var ang := atan2(local.x, -local.z)
	hint_arrow.rotation = ang
	hint_arrow.modulate.a = clampf(_hint_time / 1.0, 0.0, 1.0)


func _update_events(delta: float) -> void:
	var now := Time.get_ticks_msec() / 1000.0
	var keep: Array = []
	for entry in _event_times:
		var label: Label = entry["label"]
		if not is_instance_valid(label):
			continue
		var age: float = now - float(entry["time"])
		if age > 7.0:
			label.queue_free()
			continue
		label.modulate.a = clampf((7.0 - age) / 1.2, 0.0, 1.0)
		keep.append(entry)
	_event_times = keep


func _on_timer(value: float) -> void:
	if timer_label == null:
		return
	timer_label.text = Config.time_string(value)
	var urgent := value <= 30.0
	timer_label.add_theme_color_override("font_color", UiTheme.PINK if urgent else UiTheme.TEXT)
	var runners := Game.active_runners().size()
	runner_label.text = "%d RUNNER%s LEFT" % [runners, "" if runners == 1 else "S"]


func _on_countdown(value: float) -> void:
	if countdown_label == null:
		return
	if value <= 0.0:
		countdown_label.text = ""
		countdown_label.visible = false
		return
	countdown_label.visible = true
	countdown_label.text = str(int(ceil(value)))
	var frac: float = value - floor(value)
	countdown_label.scale = Vector2.ONE * (1.0 + frac * 0.25)
	countdown_label.modulate.a = clampf(frac * 2.5, 0.35, 1.0)


func _on_state(new_state: int) -> void:
	_last_state = new_state
	if new_state == Config.MatchState.ACTIVE:
		countdown_label.visible = false
		show_banner("RUN!", UiTheme.LIME, 1.1)
		Audio.play_music("music_game")
	elif new_state == Config.MatchState.COUNTDOWN:
		Audio.play_music("music_game")
		show_banner("GET READY", UiTheme.GOLD, 1.2)
	elif new_state == Config.MatchState.RESULTS or new_state == Config.MatchState.RESOLVING:
		countdown_label.visible = false


func set_role(role: int) -> void:
	if role_title == null:
		return
	var color := Config.role_color(role)
	role_title.text = Config.role_name(role)
	role_title.add_theme_color_override("font_color", color)
	objective_tag.text = "YOU ARE"
	var sb := role_panel.get_theme_stylebox("panel").duplicate() as StyleBoxFlat
	sb.border_color = Color(color.r, color.g, color.b, 0.55)
	role_panel.add_theme_stylebox_override("panel", sb)
	show_banner("YOU ARE THE " + Config.role_name(role), color, 2.2)


func _on_stamina(value: float) -> void:
	if stamina_bar == null:
		return
	stamina_bar.value = value
	var fill := StyleBoxFlat.new()
	var c := UiTheme.LIME
	if value < 25.0:
		c = UiTheme.PINK
	elif value < 55.0:
		c = UiTheme.GOLD
	fill.bg_color = c
	fill.set_corner_radius_all(6)
	stamina_bar.add_theme_stylebox_override("fill", fill)


func _on_prompt(value: String) -> void:
	if prompt_panel == null:
		return
	prompt_label.text = value
	prompt_panel.visible = not value.is_empty()


func _on_hidden(value: bool) -> void:
	if hidden_overlay:
		hidden_overlay.visible = value


func _on_event(text: String, color: Color) -> void:
	if text.is_empty():
		return
	var panel := PanelContainer.new()
	var sb := UiTheme.panel(Color(0.05, 0.045, 0.07, 0.78), Color(color.r, color.g, color.b, 0.45), 10, 1)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 5
	sb.content_margin_bottom = 5
	panel.add_theme_stylebox_override("panel", sb)
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var l := UiTheme.text_label(text, 14, color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(l)
	event_box.add_child(panel)
	_event_times.append({"label": l, "time": Time.get_ticks_msec() / 1000.0})
	while event_box.get_child_count() > 6:
		var first := event_box.get_child(0)
		first.queue_free()
		event_box.remove_child(first)
	Audio.caption(text)


func _on_hint(direction: Vector3, distance_text: String) -> void:
	_hint_dir = direction
	_hint_time = 6.0
	hint_text.text = "A Runner is %s" % distance_text
	hint_arrow.visible = true
	hint_text.visible = true


func _on_sense(ids: Array) -> void:
	_sense_flash = 0.8
	if ids.is_empty():
		show_banner("NOTHING NEARBY", UiTheme.MUTED, 1.4)
	else:
		show_banner("SENSE: %d NEARBY" % ids.size(), UiTheme.PINK, 1.4)


func _on_ability(kind: String) -> void:
	if kind == "sense":
		show_banner("SENSE PULSE", UiTheme.PINK, 1.0)
	elif kind == "hint":
		show_banner("HINT SENT", UiTheme.BLUE, 1.0)


func _on_caption(text: String) -> void:
	if captions == null or text.is_empty():
		return
	var l := UiTheme.text_label(text, 14, Color(0.9, 0.9, 0.95))
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	captions.add_child(l)
	var tw := create_tween()
	tw.tween_interval(3.5)
	tw.tween_property(l, "modulate:a", 0.0, 0.7)
	tw.tween_callback(l.queue_free)
	while captions.get_child_count() > 3:
		var first := captions.get_child(0)
		captions.remove_child(first)
		first.queue_free()


func show_banner(text: String, color: Color, duration: float = 1.5) -> void:
	if banner_label == null:
		return
	banner_label.text = text
	banner_label.add_theme_color_override("font_color", color)
	banner_label.modulate.a = 1.0
	_banner_time = duration
	banner_label.scale = Vector2.ONE * 1.06
	var tw := create_tween()
	tw.tween_property(banner_label, "scale", Vector2.ONE, 0.18).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func show_scoreboard(value: bool) -> void:
	if scoreboard == null:
		return
	scoreboard.visible = value
	if value:
		_refresh_scoreboard()
		_scoreboard_timer = 0.35


func _refresh_scoreboard() -> void:
	for c in scoreboard_rows.get_children():
		c.queue_free()
	for row in Game.scoreboard_rows():
		var h := UiTheme.hbox(10)
		var role := int(row["role"])
		var name_text := str(row["name"])
		if bool(row["bot"]):
			name_text += "  [AI]"
		var n := UiTheme.text_label(name_text, 16, Config.role_color(role) if role != Config.Role.HELPER else UiTheme.MUTED)
		n.custom_minimum_size = Vector2(300, 0)
		h.add_child(n)
		var r := UiTheme.text_label(Config.role_name(role), 13, Config.role_color(role))
		r.custom_minimum_size = Vector2(140, 0)
		h.add_child(r)
		h.add_child(_value_label(str(int(row["catches"])), 110))
		h.add_child(_value_label(str(int(row["caught"])), 110))
		h.add_child(_value_label("%.1fs" % float(row["hidden"]), 100))
		scoreboard_rows.add_child(h)


func _value_label(text: String, width: int) -> Label:
	var l := UiTheme.text_label(text, 15, UiTheme.TEXT)
	l.custom_minimum_size = Vector2(width, 0)
	return l


func toggle_emote() -> void:
	if emote_panel == null:
		return
	_emote_open = not _emote_open
	emote_panel.visible = _emote_open
	if _emote_open:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	else:
		if Game.state == Config.MatchState.ACTIVE and not Game.paused:
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED


func close_emote() -> void:
	if _emote_open:
		toggle_emote()


# ------------------------------------------------------------------ inner visuals

class Crosshair extends Control:
	func _draw() -> void:
		var c := Vector2(11, 11)
		draw_circle(c, 2.2, Color(1, 1, 1, 0.85))
		draw_arc(c, 7.0, 0, TAU, 24, Color(1, 1, 1, 0.35), 1.5)
		for dir in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
			draw_line(c + dir * 5.0, c + dir * 10.0, Color(1, 1, 1, 0.6), 1.5)


class HintArrow extends Control:
	func _draw() -> void:
		var c := Vector2(70, 70)
		var glow := Color(0.44, 0.66, 1.0, 0.18)
		draw_circle(c, 46, glow)
		var pts := PackedVector2Array([
			c + Vector2(0, -44), c + Vector2(26, 8), c + Vector2(0, -2),
			c + Vector2(-26, 8),
		])
		draw_colored_polygon(pts, Color(0.5, 0.72, 1.0, 0.92))
		draw_polyline(PackedVector2Array([
			c + Vector2(0, -44), c + Vector2(26, 8), c + Vector2(0, -2),
			c + Vector2(-26, 8), c + Vector2(0, -44),
		]), Color(1, 1, 1, 0.8), 2.0)
