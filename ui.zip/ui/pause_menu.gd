class_name PauseMenu
extends Control
## In-match pause / escape overlay with leave confirmation.

var main: Node
var _tag: Label
var _title: Label
var _sub: Label
var _stats: VBoxContainer
var _confirm: PanelContainer
var _leave_button: Button
var _resume_button: Button


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	theme = UiTheme.get_theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	_build()


func _build() -> void:
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.012, 0.025, 0.72)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(shade)
	add_child(UiKit.vignette(0.7))

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var card := UiKit.panel_box(30, Color(0.065, 0.055, 0.085, 0.98), Color(1, 1, 1, 0.14), 20)
	card.custom_minimum_size = Vector2(540, 0)
	center.add_child(card)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 9)
	card.add_child(v)
	_tag = UiKit.tag_heading("PAUSED", UiTheme.GOLD)
	v.add_child(_tag)
	_title = UiTheme.title("TAKE A BREATH", 46)
	v.add_child(_title)
	_sub = UiTheme.muted("", 14)
	_sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_sub)
	v.add_child(UiTheme.separator())

	_stats = VBoxContainer.new()
	_stats.add_theme_constant_override("separation", 4)
	v.add_child(_stats)

	v.add_child(UiKit.spacer_height(4))
	_resume_button = UiTheme.button("RESUME", "PrimaryButton", 54)
	_resume_button.pressed.connect(func(): main.resume_game())
	v.add_child(_resume_button)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var settings := UiTheme.button("SETTINGS", "GhostButton", 44)
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(func(): main.open_settings_from_pause())
	row.add_child(settings)
	var how := UiTheme.button("HOW TO PLAY", "GhostButton", 44)
	how.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	how.pressed.connect(func(): main.open_how_to_from_pause())
	row.add_child(how)
	_leave_button = UiTheme.button("LEAVE MATCH", "DangerButton", 46)
	_leave_button.pressed.connect(func(): _confirm.visible = true)
	v.add_child(_leave_button)
	var hint := UiTheme.muted("Escape resumes. The shame waits for no one.", 11)
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(hint)

	_confirm = UiKit.panel_box(18, Color(0.16, 0.06, 0.09, 0.98), Color(UiTheme.PINK.r, UiTheme.PINK.g, UiTheme.PINK.b, 0.7), 14)
	_confirm.visible = false
	v.add_child(_confirm)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 8)
	_confirm.add_child(cv)
	cv.add_child(UiTheme.text("Leave this match?", 20, UiTheme.TEXT))
	var warn := UiTheme.muted("You will lose your progress and return to the main menu. In LAN games this disconnects you.", 13)
	warn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(warn)
	var confirm_row := HBoxContainer.new()
	confirm_row.add_theme_constant_override("separation", 8)
	cv.add_child(confirm_row)
	var no := UiTheme.button("KEEP PLAYING", "GhostButton", 40)
	no.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	no.pressed.connect(func(): _confirm.visible = false)
	confirm_row.add_child(no)
	var yes := UiTheme.button("YES, LEAVE", "DangerButton", 40)
	yes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	yes.pressed.connect(func(): main.leave_match())
	confirm_row.add_child(yes)


func open() -> void:
	visible = true
	_confirm.visible = false
	_refresh()


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event.is_action_pressed("pause") and not event.is_echo():
		get_viewport().set_input_as_handled()
		if _confirm.visible:
			_confirm.visible = false
		else:
			main.resume_game()


func close() -> void:
	visible = false
	_confirm.visible = false


func _refresh() -> void:
	var online := Net.is_online()
	_tag.text = "MATCH MENU" if online else "PAUSED"
	_tag.add_theme_color_override("font_color", UiTheme.GOLD if not online else UiTheme.PINK)
	_title.text = "THE HUNT CONTINUES" if online else "TAKE A BREATH"
	_sub.text = "Online matches keep running. Your character is standing very still and hoping for the best." if online else "The timer is frozen. Your dignity is not."
	_leave_button.text = "LEAVE MATCH  ·  DISCONNECT" if online else "LEAVE MATCH"
	for child in _stats.get_children():
		child.queue_free()
	var map := Config.map_data(Game.map_id)
	_stats.add_child(UiKit.kv("Map", str(map["name"]), map["accent"], 14))
	_stats.add_child(UiKit.kv("Time remaining", Config.time_string(Game.time_left), UiTheme.TEXT, 14))
	var p := Game.local_player()
	if p:
		_stats.add_child(UiKit.kv("Your role", Config.role_name(p.role), Config.role_color(p.role), 14))
