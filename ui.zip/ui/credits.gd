class_name CreditsScreen
extends GameScreen
## Attribution for every third-party asset used by the game.


func build() -> void:
	add_child(UiKit.left_shade(1250, 0.92))
	add_child(UiKit.vignette(0.45))
	var margin := UiTheme.margin(40)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)
	root.add_child(UiKit.page_header("CREDITS", "Standing on the shoulders of generous, extremely patient artists.", "BACK", func(): main.show_menu_back()))

	var scroll := UiKit.scroll_page(14)
	root.add_child(scroll)
	var body := UiKit.body_of(scroll)

	var hero := UiKit.panel_box(24, Color(0.075, 0.065, 0.1, 0.94), Color(UiTheme.LIME.r, UiTheme.LIME.g, UiTheme.LIME.b, 0.35), 18)
	body.add_child(hero)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 4)
	hero.add_child(hv)
	var title := UiTheme.title("SHAMERUN", 46)
	hv.add_child(title)
	hv.add_child(UiTheme.text("A chaotic 3D party chase built with Godot 4.7.", 16, UiTheme.TEXT))
	hv.add_child(UiTheme.muted("Design, code, level assembly and UI made for this project. Every external asset is credited below.", 14))

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 14)
	body.add_child(columns)
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 14)
	columns.add_child(left)
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 14)
	columns.add_child(right)

	left.add_child(_credit_panel("3D CHARACTERS & FURNITURE", "KayKit by Kay Lousberg", [
		"KayKit Adventurers — five rigged fantasy characters with 76 animations.",
		"KayKit Furniture — sofas, beds, tables, closets, shelves, lamps and clutter.",
		"KayKit Restaurant — kitchen counters, appliances, dishes and cafe seating.",
		"KayKit Prototype — modular walls, floors, doors and stairs.",
		"License: CC0 1.0 Universal (public domain). No attribution required; given gladly.",
		"kaylousberg.com  ·  kaylousberg.itch.io",
	]))

	left.add_child(_credit_panel("TEXTURES & LIGHTING", "Poly Haven", [
		"Wood floor, marble, terracotta, carpet and stucco surface textures.",
		"Studio HDRI used for soft ambient reflections.",
		"License: CC0 1.0 Universal (public domain).",
		"polyhaven.com",
	]))

	left.add_child(_credit_panel("FONTS", "Google Fonts", [
		"Fredoka — SIL Open Font License 1.1.",
		"Luckiest Guy — Apache License 2.0.",
		"fonts.google.com",
	]))

	right.add_child(_credit_panel("MUSIC", "Jamendo — Creative Commons BY 3.0", [
		"“Popcorn And Cotton Candy” — Daniel Bautista.",
		"“playfulness” — Pan:core.",
		"Licensed under Creative Commons Attribution 3.0. Tracks are looped for the menu and matches.",
		"jamendo.com",
	]))

	right.add_child(_credit_panel("SOUND EFFECTS", "Openverse & Freesound", [
		"footstep_wood — morganpurkis — CC BY 4.0.",
		"win — xtrgamr — CC BY 4.0.",
		"splash — Garuda1982 — CC BY 4.0.",
		"lose2 — AidanSounds — CC BY 4.0.",
		"Additional clicks, creaks, impacts, whooshes and sparkles from Openverse and Freesound under CC0 1.0.",
		"openverse.org  ·  freesound.org",
	]))

	right.add_child(_credit_panel("ENGINE & TOOLS", "Godot Engine", [
		"Godot Engine 4.7.2 — MIT License.",
		"Jolt Physics — MIT License.",
		"Built with the Godot editor and the Godot AI add-on.",
		"godotengine.org",
	]))

	right.add_child(_credit_panel("SPECIAL THANKS", "Everyone who playtested", [
		"To the friends who agreed to hide in a virtual closet at 2 a.m.: thank you.",
		"And to whoever keeps slamming the bathroom door — we saw you.",
	]))

	var legal := UiKit.panel_box(18, Color(0.06, 0.05, 0.08, 0.88), Color(1, 1, 1, 0.08), 14)
	body.add_child(legal)
	var lv := VBoxContainer.new()
	lv.add_theme_constant_override("separation", 5)
	legal.add_child(lv)
	lv.add_child(UiKit.tag_heading("LICENSE NOTES", UiTheme.MUTED))
	var t1 := UiTheme.muted("CC0 assets are used without restriction. CC BY assets remain the property of their creators and are used with attribution as required. This game is a non-commercial portfolio project. All trademarks and copyrights belong to their respective owners.", 13)
	t1.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lv.add_child(t1)
	lv.add_child(UiTheme.text_label("ShameRun v%s  ·  Made with far too much coffee." % Config.GAME_VERSION, 12, UiTheme.GOLD))

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	body.add_child(actions)
	var back := UiTheme.button("BACK TO MENU", "PrimaryButton", 48)
	back.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	back.pressed.connect(func(): main.show_menu_back())
	actions.add_child(back)
	var how := UiTheme.button("HOW TO PLAY", "GhostButton", 48)
	how.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	how.pressed.connect(func(): main.show_screen("how_to_play"))
	actions.add_child(how)


func _credit_panel(title_text: String, who: String, lines: Array) -> PanelContainer:
	var p := UiKit.panel_box(18, Color(0.065, 0.055, 0.085, 0.94), Color(1, 1, 1, 0.1), 16)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 4)
	p.add_child(v)
	v.add_child(UiKit.tag_heading(title_text, UiTheme.GOLD))
	var w := UiTheme.text_label(who, 20, UiTheme.TEXT)
	w.add_theme_font_override("font", UiTheme.title_font())
	w.add_theme_font_size_override("font_size", 21)
	v.add_child(w)
	v.add_child(UiTheme.separator())
	for line in lines:
		var l := UiTheme.muted(str(line), 13)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(l)
	return p
