class_name MainMenu
extends GameScreen
## Title screen: primary actions, profile summary and live character/map preview.

var _char_name: Label
var _char_title: Label
var _char_blurb: Label
var _profile_name: Label
var _profile_meta: Label
var _level_label: Label
var _xp_bar: ProgressBar
var _map_buttons: Dictionary = {}
var _map_name: Label


func build() -> void:
	add_child(UiKit.left_shade(680, 0.93))
	add_child(UiKit.vignette(0.45))

	var margin := UiTheme.margin(44)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 28)
	columns.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	margin.add_child(columns)

	var left := VBoxContainer.new()
	left.custom_minimum_size = Vector2(438, 0)
	left.add_theme_constant_override("separation", 7)
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.size_flags_vertical = Control.SIZE_EXPAND_FILL
	columns.add_child(left)

	var kicker := UiTheme.text_label("A CHAOS-FUELLED PARTY CHASE", 12, UiTheme.GOLD)
	kicker.add_theme_constant_override("outline_size", 0)
	left.add_child(kicker)

	var title_box := VBoxContainer.new()
	title_box.add_theme_constant_override("separation", -24)
	left.add_child(title_box)
	var shame := _display_title("SHAME", UiTheme.LIME)
	title_box.add_child(shame)
	var run := _display_title("RUN", UiTheme.TEXT)
	run.add_theme_color_override("font_shadow_color", Color(UiTheme.PINK.r, UiTheme.PINK.g, UiTheme.PINK.b, 0.75))
	title_box.add_child(run)

	var tagline := UiTheme.text_label("RUN.  HIDE.  SHAME.", 16, UiTheme.MUTED)
	tagline.add_theme_constant_override("outline_size", 0)
	left.add_child(tagline)
	left.add_child(UiKit.spacer_height(10))
	left.add_child(UiTheme.separator())
	left.add_child(UiKit.spacer_height(6))

	var solo := UiTheme.button("PLAY SOLO", "PrimaryButton", 54)
	solo.custom_minimum_size = Vector2(200, 54)
solo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	solo.pressed.connect(func(): main.show_screen("solo"))
	left.add_child(solo)

	var online := UiTheme.button("PLAY ONLINE  ·  LAN", "PrimaryButton", 54)
	UiKit.tint_button(online, UiTheme.BLUE)

online.custom_minimum_size = Vector2(200, 54)
online.size_flags_horizontal = Control.SIZE_EXPAND_FILL

online.pressed.connect(func(): main.show_screen("network"))
	left.add_child(online)

	var row1 := UiTheme.hbox(8)
	row1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(row1)
	var characters := UiTheme.button("CHARACTERS", "GhostButton", 46)
	characters.custom_minimum_size = Vector2(0, 46)
	characters.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	characters.pressed.connect(func(): main.show_screen("character"))
	row1.add_child(characters)
	var how := UiTheme.button("HOW TO PLAY", "GhostButton", 46)
	how.custom_minimum_size = Vector2(0, 46)
	how.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	how.pressed.connect(func(): main.show_screen("how_to_play"))
	row1.add_child(how)

	var row2 := UiTheme.hbox(8)
	row2.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_child(row2)
	var settings := UiTheme.button("SETTINGS", "GhostButton", 46)
	settings.custom_minimum_size = Vector2(0, 46)
	settings.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	settings.pressed.connect(func(): main.show_screen("settings"))
	row2.add_child(settings)
	var credits := UiTheme.button("CREDITS", "GhostButton", 46)
	credits.custom_minimum_size = Vector2(0, 46)
	credits.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	credits.pressed.connect(func(): main.show_screen("credits"))
	row2.add_child(credits)

	var quit := UiTheme.button("QUIT", "GhostButton", 38)
	quit.add_theme_color_override("font_color", UiTheme.MUTED.darkened(0.05))
	quit.pressed.connect(func(): main.quit_game())
	left.add_child(quit)

	left.add_child(UiTheme.spacer())

	# Profile strip.
	var profile := UiKit.panel_box(16, Color(0.06, 0.05, 0.08, 0.85), Color(1, 1, 1, 0.12), 16)
	profile.custom_minimum_size = Vector2(0, 120)
	profile.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	profile.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	left.add_child(profile)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 8)
	pv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pv.size_flags_vertical = Control.SIZE_EXPAND_FILL
	profile.add_child(pv)
	var ptop := HBoxContainer.new()
	ptop.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pv.add_child(ptop)
	_profile_name = UiTheme.text_label("PLAYER", 18, UiTheme.TEXT)
	_profile_name.add_theme_color_override("font_color", UiTheme.LIME)
	_profile_name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_profile_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	ptop.add_child(_profile_name)
	var lvl := UiKit.panel_box(8, Color(UiTheme.GOLD.r, UiTheme.GOLD.g, UiTheme.GOLD.b, 0.18), Color(UiTheme.GOLD.r, UiTheme.GOLD.g, UiTheme.GOLD.b, 0.6), 16)
	lvl.custom_minimum_size = Vector2(120, 0)
	lvl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ptop.add_child(lvl)
	_level_label = UiTheme.text_label("LEVEL 1", 11, UiTheme.GOLD)
	_level_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	lvl.add_child(_level_label)
	_profile_meta = UiTheme.muted("0 matches  ·  0 XP", 13)
	_profile_meta.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pv.add_child(_profile_meta)
	_xp_bar = ProgressBar.new()
	_xp_bar.custom_minimum_size = Vector2(0, 10)
	_xp_bar.max_value = 500
	_xp_bar.show_percentage = false
	_xp_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_xp_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pv.add_child(_xp_bar)

	columns.add_child(UiTheme.spacer())

	# Right column: map mood + character card.
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(378, 0)
	right.add_theme_constant_override("separation", 12)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.alignment = BoxContainer.ALIGNMENT_END
	columns.add_child(right)

	var map_head := HBoxContainer.new()
	right.add_child(map_head)
	var map_tag := UiTheme.text_label("PREVIEW A MAP", 11, UiTheme.MUTED)
	map_tag.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	map_head.add_child(map_tag)
	_map_name = UiTheme.text_label("", 11, UiTheme.LIME)
	map_head.add_child(_map_name)

	var map_row := HBoxContainer.new()
	map_row.add_theme_constant_override("separation", 6)
	right.add_child(map_row)
	for m in Config.maps:
		var b := UiTheme.button("%s  %s" % [str(m["icon"]), str(m["name"])], "Chip", 38)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.toggle_mode = true
		b.add_theme_font_size_override("font_size", 12)
		var mid := str(m["id"])
		b.pressed.connect(func(): _select_map(mid))
		map_row.add_child(b)
		_map_buttons[mid] = b

	right.add_child(UiKit.spacer_height(6))

	var card := UiKit.panel_box(20, Color(0.07, 0.06, 0.095, 0.92), Color(1, 1, 1, 0.15), 20)
	card.custom_minimum_size = Vector2(0, 260)
	card.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(card)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 8)
	cv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cv.size_flags_vertical = Control.SIZE_EXPAND_FILL
	card.add_child(cv)
	cv.add_child(UiKit.tag_heading("YOUR LEGEND", UiTheme.GOLD))
	_char_name = UiTheme.text_label("Brunhilda", 32, UiTheme.TEXT)
	_char_name.add_theme_font_override("font", UiTheme.title_font())
	_char_name.add_theme_font_size_override("font_size", 38)
	_char_name.add_theme_color_override("font_color", UiTheme.GOLD)
	cv.add_child(_char_name)
	_char_title = UiTheme.text_label("The Loud", 15, UiTheme.LIME)
	_char_title.add_theme_color_override("font_color", UiTheme.LIME)
	cv.add_child(_char_title)
	_char_blurb = UiTheme.muted("", 14)
	_char_blurb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_char_blurb.custom_minimum_size = Vector2(0, 50)
	_char_blurb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cv.add_child(_char_blurb)
	var change := UiTheme.button("CHANGE CHARACTER", "GhostButton", 42)
	change.custom_minimum_size = Vector2(0, 46)
	change.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	change.pressed.connect(func(): main.show_screen("character"))
	cv.add_child(change)

	var footer := UiTheme.text_label("LAN READY  ·  v%s  ·  Made for shouting at friends" % Config.GAME_VERSION, 11, Color(0.65, 0.63, 0.72, 0.95))
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	footer.add_theme_color_override("font_color", UiTheme.MUTED)
	right.add_child(footer)


func _display_title(text_value: String, color: Color) -> Label:
	var l := UiTheme.text_label(text_value, 104, color)
	l.add_theme_font_override("font", UiTheme.title_font())
	l.add_theme_font_size_override("font_size", 104)
	l.add_theme_constant_override("outline_size", 12)
	l.add_theme_color_override("font_outline_color", Color(0.02, 0.015, 0.03, 0.9))
	l.add_theme_constant_override("shadow_offset_x", 7)
	l.add_theme_constant_override("shadow_offset_y", 7)
	l.add_theme_color_override("font_shadow_color", Color(UiTheme.LIME.r, UiTheme.LIME.g, UiTheme.LIME.b, 0.55) if color == UiTheme.TEXT else Color(UiTheme.PINK.r, UiTheme.PINK.g, UiTheme.PINK.b, 0.6))
	return l


func on_show(_data: Dictionary = {}) -> void:
	_refresh_profile()
	_refresh_character()
	_refresh_map()
	main.set_preview_character(Settings.character_id)
	main.set_preview_map(main.preview_map_id)
	main.play_menu_music()


func _refresh_profile() -> void:
	var level := 1 + int(Settings.total_xp / 500)
	var into := Settings.total_xp % 500
	_profile_name.text = "HELLO, %s" % Settings.player_name.to_upper()
	_level_label.text = "LEVEL %d" % level
	_profile_meta.text = "%d matches  ·  %d XP  ·  %d to next" % [Settings.matches_played, Settings.total_xp, 500 - into]
	_xp_bar.value = into


func _refresh_character() -> void:
	var data := Config.character_data(Settings.character_id)
	_char_name.text = str(data["name"])
	_char_title.text = str(data["title"])
	_char_blurb.text = str(data["blurb"])
	_char_title.add_theme_color_override("font_color", data["color"])


func _refresh_map() -> void:
	var id: String = main.preview_map_id if main else "suburban"
	for key in _map_buttons.keys():
		var b: Button = _map_buttons[key]
		b.button_pressed = key == id
	var data := Config.map_data(id)
	_map_name.text = str(data["name"]).to_upper()
	_map_name.add_theme_color_override("font_color", data["accent"])


func _select_map(id: String) -> void:
	main.set_preview_map(id)
	_refresh_map()
	Audio.play_ui("click")
