class_name SoloSetup
extends GameScreen
## Single-player match configuration.

var _map_buttons: Dictionary = {}
var _map_id := "suburban"
var _bots := 4
var _timer := 300
var _difficulty := 1
var _role := -1
var _summary_map: HBoxContainer
var _summary_bots: HBoxContainer
var _summary_timer: HBoxContainer
var _summary_role: HBoxContainer
var _summary_char: Label
var _start_button: Button
var _char_dot: Label
var _difficulty_buttons: Array = []
var _role_buttons: Array = []


func build() -> void:
	add_child(UiKit.left_shade(1000, 0.9))
	add_child(UiKit.vignette(0.42))
	var margin := UiTheme.margin(42)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)
	root.add_child(UiKit.page_header("PLAY SOLO", "You, some questionable bots, and a house with too many doors.", "BACK", func(): main.show_screen("main_menu")))

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 22)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(columns)

	# ---- map column
	var maps_col := VBoxContainer.new()
	maps_col.custom_minimum_size = Vector2(700, 0)
	maps_col.add_theme_constant_override("separation", 10)
	columns.add_child(maps_col)
	maps_col.add_child(UiKit.tag_heading("CHOOSE YOUR BAD IDEA", UiTheme.GOLD))
	var group := ButtonGroup.new()
	group.allow_unpress = false
	for m in Config.maps:
		var data: Dictionary = m
		var b := Button.new()
		b.theme_type_variation = "CardButton"
		b.custom_minimum_size = Vector2(0, 116)
		b.toggle_mode = true
		b.button_group = group
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		maps_col.add_child(b)
		var box := VBoxContainer.new()
		box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		box.offset_left = 20
		box.offset_right = -20
		box.offset_top = 14
		box.offset_bottom = -14
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_theme_constant_override("separation", 2)
		b.add_child(box)
		var top := HBoxContainer.new()
		top.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(top)
		var icon := UiTheme.text_label(str(data["icon"]), 22, data["accent"])
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top.add_child(icon)
		var nm := UiTheme.text_label("  " + str(data["name"]), 23, UiTheme.TEXT)
		nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top.add_child(nm)
		var meta := UiTheme.text_label("%s  ·  %s" % [str(data["players"]), str(data["size"]).to_upper()], 11, UiTheme.MUTED)
		meta.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top.add_child(meta)
		var tag := UiTheme.text_label(str(data["tag"]), 11, data["accent"])
		tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(tag)
		var desc := UiTheme.muted(str(data["desc"]), 13)
		desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		desc.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(desc)
		var strip := ColorRect.new()
		strip.color = Color(data["accent"].r, data["accent"].g, data["accent"].b, 0.5)
		strip.custom_minimum_size = Vector2(0, 3)
		strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(strip)
		var mid := str(data["id"])
		b.pressed.connect(func(): _select_map(mid))
		_map_buttons[mid] = b

	var tip := UiKit.panel_box(14, Color(0.07, 0.06, 0.09, 0.7), Color(1, 1, 1, 0.08), 12)
	maps_col.add_child(tip)
	var tip_text := UiTheme.muted("Tip: The timer only counts down while the round is live. Hiding is powerful, but the Chaser can search spots one by one.", 13)
	tip_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.add_child(tip_text)

	# ---- settings column
	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 12)
	columns.add_child(right)

	var setup_panel := UiKit.panel_box(20, Color(0.065, 0.055, 0.085, 0.93), Color(1, 1, 1, 0.12), 18)
	setup_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(setup_panel)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 11)
	setup_panel.add_child(sv)
	sv.add_child(UiKit.tag_heading("MATCH SETUP", UiTheme.GOLD))

	sv.add_child(UiKit.stepper_row("Bots", "Fill the house with chaos.", _bots, 1, 9, func(v: int): _bots = v; _refresh_summary(), ""))

	sv.add_child(UiTheme.separator())

	sv.add_child(UiKit.choice_row("Round timer", [
		{"label": "3 MIN", "value": 180},
		{"label": "5 MIN", "value": 300},
		{"label": "8 MIN", "value": 480},
		{"label": "10 MIN", "value": 600},
	], _timer, func(v): _timer = int(v); _refresh_summary()))

	sv.add_child(UiKit.choice_row("Bot brains", [
		{"label": "CHILL", "value": 0, "color": UiTheme.LIME},
		{"label": "NORMAL", "value": 1, "color": UiTheme.GOLD},
		{"label": "CHAOS", "value": 2, "color": UiTheme.PINK},
	], _difficulty, func(v): _difficulty = int(v); _refresh_summary()))

	sv.add_child(UiKit.choice_row("Your role", [
		{"label": "SURPRISE ME", "value": -1},
		{"label": "RUNNER", "value": Config.Role.RUNNER, "color": UiTheme.LIME},
		{"label": "CHASER", "value": Config.Role.CHASER, "color": UiTheme.PINK},
	], _role, func(v): _role = int(v); _refresh_summary()))

	sv.add_child(UiTheme.separator())

	var char_row := HBoxContainer.new()
	char_row.add_theme_constant_override("separation", 10)
	sv.add_child(char_row)
	var ctext := VBoxContainer.new()
	ctext.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	char_row.add_child(ctext)
	ctext.add_child(UiTheme.text("Your character", 16, UiTheme.TEXT))
	_summary_char = UiTheme.muted("Brunhilda · The Loud", 13)
	ctext.add_child(_summary_char)
	_char_dot = UiTheme.text_label("●", 26, UiTheme.LIME)
	char_row.add_child(_char_dot)
	var change := UiTheme.button("CHANGE", "GhostButton", 36)
	change.custom_minimum_size = Vector2(100, 36)
	change.pressed.connect(func(): main.show_screen("character"))
	char_row.add_child(change)

	sv.add_child(UiTheme.separator())
	sv.add_child(UiKit.tag_heading("READY?", UiTheme.LIME))
	_summary_map = UiKit.kv("Map", "Suburban House", UiTheme.TEXT, 14)
	sv.add_child(_summary_map)
	_summary_bots = UiKit.kv("Players", "You + 4 bots", UiTheme.TEXT, 14)
	sv.add_child(_summary_bots)
	_summary_timer = UiKit.kv("Timer", "5:00", UiTheme.TEXT, 14)
	sv.add_child(_summary_timer)
	_summary_role = UiKit.kv("Role", "Surprise me", UiTheme.TEXT, 14)
	sv.add_child(_summary_role)

	sv.add_child(UiTheme.spacer())

	_start_button = UiTheme.button("START THE SHAME", "PrimaryButton", 56)
	_start_button.pressed.connect(_start)
	sv.add_child(_start_button)

	var help := UiTheme.button("HOW TO PLAY", "GhostButton", 40)
	help.pressed.connect(func(): main.show_screen("how_to_play"))
	sv.add_child(help)


func on_show(_data: Dictionary = {}) -> void:
	_map_id = main.preview_map_id if main else "suburban"
	_select_map(_map_id)
	_refresh_character()
	_refresh_summary()
	main.set_preview_map(_map_id)
	main.play_menu_music()


func _select_map(id: String) -> void:
	_map_id = id
	for key in _map_buttons.keys():
		var b: Button = _map_buttons[key]
		b.button_pressed = key == id
	if main:
		main.set_preview_map(id)
	_refresh_summary()


func _refresh_character() -> void:
	var data := Config.character_data(Settings.character_id)
	_summary_char.text = "%s · %s" % [str(data["name"]), str(data["title"])]
	_char_dot.add_theme_color_override("font_color", data["color"])


func _refresh_summary() -> void:
	var map := Config.map_data(_map_id)
	_summary_map.get_child(1).text = str(map["name"])
	_summary_bots.get_child(1).text = "You + %d bot%s" % [_bots, "" if _bots == 1 else "s"]
	_summary_timer.get_child(1).text = Config.time_string(_timer)
	var role_text: String
	var role_color: Color
	match _role:
		Config.Role.RUNNER:
			role_text = "Runner"
			role_color = UiTheme.LIME
		Config.Role.CHASER:
			role_text = "Chaser"
			role_color = UiTheme.PINK
		_:
			role_text = "Surprise me"
			role_color = UiTheme.GOLD
	_summary_role.get_child(1).text = role_text
	_summary_role.get_child(1).add_theme_color_override("font_color", role_color)
	var diff: String = ["Chill", "Normal", "Chaos"][_difficulty]
	_start_button.text = "START  ·  %s  ·  %s" % [str(map["name"]).to_upper(), diff.to_upper()]


func _start() -> void:
	var swap: float = [0.22, 0.30, 0.42][_difficulty]
	main.start_solo({
		"map": _map_id,
		"bots": _bots,
		"timer": float(_timer),
		"difficulty": _difficulty,
		"role": _role,
		"swap_chance": swap,
	})
