class_name HowToPlay
extends GameScreen
## Rules, controls and prop primer.


func build() -> void:
	add_child(UiKit.left_shade(1150, 0.92))
	add_child(UiKit.vignette(0.45))
	var margin := UiTheme.margin(40)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	margin.add_child(root)
	root.add_child(UiKit.page_header("HOW TO PLAY", "One Chaser. Everyone else is a problem to be solved.", "BACK", func(): main.show_menu_back()))

	var scroll := UiKit.scroll_page(14)
	root.add_child(scroll)
	var body := UiKit.body_of(scroll)

	var roles := HBoxContainer.new()
	roles.add_theme_constant_override("separation", 12)
	body.add_child(roles)
	roles.add_child(_role_card("RUNNER", "SURVIVE", UiTheme.LIME, "●", [
		"Stay alive until the timer hits zero.",
		"Sprint, crouch and break line of sight.",
		"Hide in closets, under beds and inside cabinets.",
		"Throw props to slow the Chaser down.",
		"If caught, you may swap roles — or become a Helper.",
	]))
	roles.add_child(_role_card("CHASER", "CATCH EVERYONE", UiTheme.PINK, "▲", [
		"Tag Runners with [F] when they are close.",
		"Search hiding spots one at a time. Empty spots waste time.",
		"Use [Q] Sense to reveal nearby Runners briefly.",
		"Caught Runners may become the new Chaser.",
		"A catch locks you in place for a moment. Choose wisely.",
	]))
	roles.add_child(_role_card("HELPER", "CAUSE TROUBLE", UiTheme.BLUE, "✦", [
		"Fly through walls and watch the chaos.",
		"Send a hint to the Chaser every 30 seconds.",
		"Your hint points toward the nearest Runner.",
		"You cannot be caught and cannot win alone.",
		"Emotes are free. Use them irresponsibly.",
	]))

	var middle := HBoxContainer.new()
	middle.add_theme_constant_override("separation", 14)
	body.add_child(middle)

	var controls := UiKit.panel_box(18)
	controls.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	middle.add_child(controls)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 9)
	controls.add_child(cv)
	cv.add_child(UiKit.section("CONTROLS", "Default bindings. Change them in Settings."))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	grid.add_theme_constant_override("v_separation", 5)
	cv.add_child(grid)
	for action in Config.ACTION_LABELS.keys():
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		grid.add_child(row)
		var key := UiKit.keycap(Config.key_name_for_action(action))
		key.custom_minimum_size = Vector2(66, 0)
		row.add_child(key)
		var lbl := UiTheme.text(str(Config.ACTION_LABELS[action]), 14, UiTheme.TEXT)
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(lbl)
	var mouse_row := HBoxContainer.new()
	mouse_row.add_theme_constant_override("separation", 8)
	grid.add_child(mouse_row)
	var mouse_key := UiKit.keycap("LMB")
	mouse_key.custom_minimum_size = Vector2(66, 0)
	mouse_row.add_child(mouse_key)
	mouse_row.add_child(UiTheme.text("Throw held prop", 14, UiTheme.TEXT))

	var props := UiKit.panel_box(18)
	props.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	middle.add_child(props)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 7)
	props.add_child(pv)
	pv.add_child(UiKit.section("THE TOY BOX", "Everything is a weapon if you commit."))
	pv.add_child(_prop_row("Water Bottle", "Throw it to leave a slippery puddle.", UiTheme.BLUE))
	pv.add_child(_prop_row("Banana Peel", "Drop a trap behind you. Classic.", UiTheme.GOLD))
	pv.add_child(_prop_row("Ball", "Bounces loudly. Great distraction.", UiTheme.LIME))
	pv.add_child(_prop_row("Frying Pan", "A direct hit stuns the target.", UiTheme.PINK))
	pv.add_child(_prop_row("Doors", "Slam them in someone's face. Briefly.", UiTheme.PURPLE))
	pv.add_child(_prop_row("Light Switches", "Plunge a room into darkness.", UiTheme.GOLD))
	pv.add_child(_prop_row("Hiding Spots", "Closets, beds, cabinets. Search takes time.", UiTheme.LIME))
	pv.add_child(_prop_row("Noisy Props", "Vases and lamps make a very convincing scream.", UiTheme.MUTED))

	var rules := UiKit.panel_box(18, Color(0.075, 0.065, 0.1, 0.9), Color(1, 1, 1, 0.09), 14)
	body.add_child(rules)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 7)
	rules.add_child(rv)
	rv.add_child(UiKit.section("THE SHORT VERSION", ""))
	var line1 := UiTheme.text("Runners win if at least one is still free when the timer ends. Chasers win by catching every Runner. When a Runner is caught there is a 30% chance the roles swap — the caught Runner becomes the Chaser, and the hunt continues.", 15, UiTheme.TEXT)
	line1.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rv.add_child(line1)
	var line2 := UiTheme.muted("If a catch does not swap roles, the caught Runner becomes a Spectator-Helper and starts feeding hints to the Chaser. Being caught is not the end. It is a career change.", 14)
	line2.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rv.add_child(line2)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	body.add_child(actions)
	var solo := UiTheme.button("PLAY SOLO", "PrimaryButton", 50)
	solo.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	solo.pressed.connect(func(): main.show_screen("solo"))
	actions.add_child(solo)
	var online := UiTheme.button("PLAY ONLINE", "GhostButton", 50)
	online.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	online.pressed.connect(func(): main.show_screen("network"))
	actions.add_child(online)


func _role_card(title_text: String, subtitle: String, color: Color, icon: String, lines: Array) -> PanelContainer:
	var p := UiKit.panel_box(18, Color(0.065, 0.055, 0.085, 0.94), Color(color.r, color.g, color.b, 0.45), 16)
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 5)
	p.add_child(v)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	v.add_child(head)
	head.add_child(UiTheme.text_label(icon, 22, color))
	var titles := VBoxContainer.new()
	titles.add_theme_constant_override("separation", -2)
	head.add_child(titles)
	var t := UiTheme.text_label(title_text, 22, color)
	t.add_theme_font_override("font", UiTheme.title_font())
	t.add_theme_font_size_override("font_size", 24)
	titles.add_child(t)
	titles.add_child(UiTheme.text_label(subtitle, 10, UiTheme.MUTED))
	v.add_child(UiTheme.separator())
	for line in lines:
		var l := UiTheme.text("·  " + str(line), 13, UiTheme.TEXT)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		v.add_child(l)
	return p


func _prop_row(name_text: String, desc: String, color: Color) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	h.add_child(UiTheme.text_label("■", 11, color))
	var n := UiTheme.text_label(name_text, 13, UiTheme.TEXT)
	n.custom_minimum_size = Vector2(118, 0)
	h.add_child(n)
	var d := UiTheme.muted(desc, 13)
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	d.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(d)
	return h
