class_name CharacterSelect
extends GameScreen
## Character roster with live 3D preview.

var _buttons: Dictionary = {}
var _name: Label
var _title: Label
var _blurb: Label
var _vibe: Label
var _color_bar: ColorRect
var _role_hint: Label
var _selected := "barbarian"


func build() -> void:
	add_child(UiKit.left_shade(900, 0.9))
	add_child(UiKit.vignette(0.4))
	var margin := UiTheme.margin(44)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 16)
	margin.add_child(root)
	root.add_child(UiKit.page_header("CHARACTERS", "Five legends. One deeply questionable evening.", "BACK", func(): main.show_screen("main_menu")))

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 24)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(columns)

	var grid_panel := UiKit.panel_box(18, Color(0.06, 0.05, 0.08, 0.8), Color(1, 1, 1, 0.1), 18)
	grid_panel.custom_minimum_size = Vector2(720, 0)
	columns.add_child(grid_panel)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	grid_panel.add_child(grid)

	var group := ButtonGroup.new()
	group.allow_unpress = false
	for c in Config.characters:
		var data: Dictionary = c
		var b := Button.new()
		b.theme_type_variation = "CardButton"
		b.custom_minimum_size = Vector2(328, 132)
		b.toggle_mode = true
		b.button_group = group
		b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
		grid.add_child(b)
		var box := VBoxContainer.new()
		box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		box.offset_left = 16
		box.offset_right = -16
		box.offset_top = 12
		box.offset_bottom = -12
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_theme_constant_override("separation", 2)
		b.add_child(box)
		var top := HBoxContainer.new()
		top.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(top)
		var nm := UiTheme.text_label(str(data["name"]), 20, UiTheme.TEXT)
		nm.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top.add_child(nm)
		var dot := UiTheme.text_label("●", 16, data["color"])
		dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
		top.add_child(dot)
		var ti := UiTheme.text_label(str(data["title"]), 13, data["color"])
		ti.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(ti)
		var bl := UiTheme.muted(str(data["blurb"]), 12)
		bl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		bl.custom_minimum_size = Vector2(0, 44)
		bl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(bl)
		var strip := ColorRect.new()
		strip.color = Color(data["color"].r, data["color"].g, data["color"].b, 0.55)
		strip.custom_minimum_size = Vector2(0, 3)
		strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(strip)
		var cid := str(data["id"])
		b.pressed.connect(func(): _select(cid))
		_buttons[cid] = b

	var right := VBoxContainer.new()
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	right.add_theme_constant_override("separation", 10)
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	columns.add_child(right)

	var card := UiKit.panel_box(26, Color(0.07, 0.06, 0.095, 0.92), Color(1, 1, 1, 0.12), 20)
	right.add_child(card)
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 6)
	card.add_child(cv)
	cv.add_child(UiKit.tag_heading("NOW SHOWING", UiTheme.GOLD))
	_name = UiTheme.text_label("Brunhilda", 46, UiTheme.TEXT)
	_name.add_theme_font_override("font", UiTheme.title_font())
	_name.add_theme_font_size_override("font_size", 52)
	cv.add_child(_name)
	_title = UiTheme.text_label("The Loud", 18, UiTheme.LIME)
	cv.add_child(_title)
	_color_bar = ColorRect.new()
	_color_bar.custom_minimum_size = Vector2(0, 4)
	cv.add_child(_color_bar)
	_blurb = UiTheme.text("", 16, UiTheme.TEXT)
	_blurb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_blurb.custom_minimum_size = Vector2(0, 64)
	cv.add_child(_blurb)
	cv.add_child(UiTheme.separator())
	_vibe = UiTheme.muted("", 14)
	cv.add_child(_vibe)
	_role_hint = UiTheme.muted("", 13)
	_role_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	cv.add_child(_role_hint)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	right.add_child(actions)
	var random_btn := UiTheme.button("SURPRISE ME", "GhostButton", 48)
	random_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	random_btn.pressed.connect(_randomize)
	actions.add_child(random_btn)
	var choose := UiTheme.button("LOCK IT IN", "PrimaryButton", 48)
	choose.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	choose.pressed.connect(func(): main.show_screen("main_menu"))
	actions.add_child(choose)

	var note := UiTheme.muted("Your character is cosmetic. Your shame is personal.", 12)
	note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	right.add_child(note)


func on_show(_data: Dictionary = {}) -> void:
	_selected = Settings.character_id
	_select(_selected)


func _select(id: String) -> void:
	_selected = id
	var data := Config.character_data(id)
	for key in _buttons.keys():
		var b: Button = _buttons[key]
		b.button_pressed = key == id
	_name.text = str(data["name"])
	_name.add_theme_color_override("font_color", data["color"].lightened(0.2))
	_title.text = str(data["title"])
	_title.add_theme_color_override("font_color", data["color"])
	_color_bar.color = data["color"]
	_blurb.text = str(data["blurb"])
	_vibe.text = "VIBE  ·  " + str(_vibes().get(id, "Unpredictable"))
	_role_hint.text = str(_role_hints().get(id, "No one is safe."))
	Settings.set_value("character_id", id)
	if Net.is_online():
		Net.set_character(id)
	if main:
		main.set_preview_character(id)


func _randomize() -> void:
	var pick: Dictionary = Config.characters[randi_range(0, Config.characters.size() - 1)]
	_select(str(pick["id"]))


func _vibes() -> Dictionary:
	return {
		"barbarian": "LOUD  ·  LOUDER  ·  APOLOGETIC LATER",
		"knight": "HONOURABLE  ·  POLITE  ·  SURPRISINGLY SLOW",
		"mage": "MYSTERIOUS  ·  UNLICENSED  ·  SLIGHTLY ON FIRE",
		"rogue": "SNEAKY  ·  QUICK  ·  TOO PLEASED WITH THEMSELF",
		"rogue_hooded": "DRAMATIC  ·  ELUSIVE  ·  DEFINITELY NOT A PHASE",
	}


func _role_hints() -> Dictionary:
	return {
		"barbarian": "Best enjoyed sprinting directly at the problem while screaming.",
		"knight": "A natural Chaser. Will feel bad about it afterwards.",
		"mage": "Excellent at hiding. Cannot resist announcing it.",
		"rogue": "Built for closets, corners and deeply unfair escapes.",
		"rogue_hooded": "The silhouette does most of the work.",
	}
