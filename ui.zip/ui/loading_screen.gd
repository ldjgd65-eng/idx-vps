class_name LoadingScreen
extends Control
## Full-screen loading curtain used while a map is generated.

var _map_name: Label
var _status: Label
var _tip: Label
var _icon: Label
var _bar: ProgressBar
var _t := 0.0
var _status_base := "Building"


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	theme = UiTheme.get_theme()
	visible = false
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build()


func _build() -> void:
	var bg := ColorRect.new()
	bg.color = Color(0.035, 0.03, 0.05, 1.0)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	add_child(UiKit.vignette(0.7))

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var card := UiKit.panel_box(34, Color(0.07, 0.06, 0.09, 0.97), Color(UiTheme.LIME.r, UiTheme.LIME.g, UiTheme.LIME.b, 0.3), 20)
	card.custom_minimum_size = Vector2(660, 0)
	center.add_child(card)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	card.add_child(v)
	v.add_child(UiKit.tag_heading("BUILDING THE SCENE OF THE CRIME", UiTheme.LIME))
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 12)
	v.add_child(head)
	_icon = UiTheme.text_label("⌂", 40, UiTheme.GOLD)
	head.add_child(_icon)
	_map_name = UiTheme.text("Suburban House", 42, UiTheme.TEXT)
	_map_name.add_theme_font_override("font", UiTheme.title_font())
	_map_name.add_theme_font_size_override("font_size", 44)
	head.add_child(_map_name)
	_status = UiTheme.text("Building...", 16, UiTheme.MUTED)
	v.add_child(_status)
	_bar = ProgressBar.new()
	_bar.custom_minimum_size = Vector2(0, 10)
	_bar.show_percentage = false
	_bar.max_value = 100.0
	v.add_child(_bar)
	v.add_child(UiKit.spacer_height(6))
	v.add_child(UiTheme.separator())
	_tip = UiTheme.muted("", 14)
	_tip.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(_tip)
	var foot := UiTheme.text_label("ShameRun  ·  please do not trip over the furniture", 11, Color(0.5, 0.48, 0.56))
	v.add_child(foot)


func show_loading(map_id: String, status: String = "") -> void:
	_t = 0.0
	visible = true
	var data := Config.map_data(map_id)
	_map_name.text = str(data["name"])
	_icon.text = str(data["icon"])
	_icon.add_theme_color_override("font_color", data["accent"])
	var md := MapData.get_map(map_id)
	_tip.text = str(md.get("tutorial", ""))
	_status.text = status if not status.is_empty() else "Building rooms, hiding spots and terrible decisions..."
	_status_base = _status.text
	_bar.value = 0.0


func set_status(text: String) -> void:
	if visible:
		_status_base = text
		_status.text = text


func hide_loading() -> void:
	visible = false


func _process(delta: float) -> void:
	if not visible:
		return
	_t += delta
	_bar.value = 50.0 + sin(_t * 1.6) * 42.0
	var dots := int(_t * 3.0) % 4
	_status.text = _status_base.rstrip(".") + ".".repeat(dots)
