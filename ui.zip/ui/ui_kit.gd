class_name UiKit
## Small composition helpers shared by the menu screens.

static func scroll_page(separation: int = 16) -> ScrollContainer:
	var sc := ScrollContainer.new()
	sc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var body := VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", separation)
	sc.add_child(body)
	sc.set_meta("body", body)
	return sc


static func body_of(scroll: ScrollContainer) -> VBoxContainer:
	return scroll.get_meta("body") as VBoxContainer


static func page_header(title_text: String, subtitle_text: String = "", back_text: String = "", back_cb: Callable = Callable()) -> VBoxContainer:
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 6)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 18)
	root.add_child(top)
	var titles := VBoxContainer.new()
	titles.add_theme_constant_override("separation", 0)
	titles.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(titles)
	var t := UiTheme.title(title_text, 50)
	titles.add_child(t)
	if not subtitle_text.is_empty():
		var s := UiTheme.text(subtitle_text, 16, UiTheme.MUTED)
		s.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		titles.add_child(s)
	if not back_text.is_empty():
		var b := UiTheme.button(back_text, "GhostButton", 44)
		b.custom_minimum_size = Vector2(130, 44)
		b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		if back_cb.is_valid():
			b.pressed.connect(back_cb)
		top.add_child(b)
	root.add_child(UiTheme.separator())
	return root


static func panel_box(padding: int = 22, bg: Color = UiTheme.PANEL, border: Color = UiTheme.LINE, radius: int = 16) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := UiTheme.panel(bg, border, radius, 1)
	sb.content_margin_left = padding
	sb.content_margin_right = padding
	sb.content_margin_top = padding
	sb.content_margin_bottom = padding
	sb.shadow_size = 8
	p.add_theme_stylebox_override("panel", sb)
	return p


static func section(title_text: String, subtitle_text: String = "") -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	var h := UiTheme.text_label(title_text, 22, UiTheme.TEXT)
	h.add_theme_font_override("font", UiTheme.body_font())
	v.add_child(h)
	if not subtitle_text.is_empty():
		v.add_child(UiTheme.muted(subtitle_text, 14))
	return v


static func kv(label_text: String, value_text: String, value_color: Color = UiTheme.TEXT, size: int = 16) -> HBoxContainer:
	var h := UiTheme.hbox(8)
	var l := UiTheme.text(label_text, size, UiTheme.MUTED)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(l)
	var v := UiTheme.text_label(value_text, size, value_color)
	v.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	h.add_child(v)
	return h


static func slider_row(title_text: String, minv: float, maxv: float, step: float, value: float, fmt: Callable, on_change: Callable) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 3)
	var head := HBoxContainer.new()
	head.add_theme_constant_override("separation", 8)
	v.add_child(head)
	var l := UiTheme.text(title_text, 16, UiTheme.TEXT)
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(l)
	var val := UiTheme.text_label(str(fmt.call(value)) if fmt.is_valid() else str(value), 14, UiTheme.LIME)
	head.add_child(val)
	var s := HSlider.new()
	s.min_value = minv
	s.max_value = maxv
	s.step = step
	s.value = value
	s.custom_minimum_size = Vector2(0, 24)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_child(s)
	s.value_changed.connect(func(nv: float):
		val.text = str(fmt.call(nv)) if fmt.is_valid() else str(nv)
		if on_change.is_valid():
			on_change.call(nv)
	)
	v.set_meta("slider", s)
	v.set_meta("value_label", val)
	return v


static func toggle_row(title_text: String, desc_text: String, value: bool, on_toggle: Callable) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	var texts := VBoxContainer.new()
	texts.add_theme_constant_override("separation", 1)
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(texts)
	texts.add_child(UiTheme.text(title_text, 16, UiTheme.TEXT))
	if not desc_text.is_empty():
		var d := UiTheme.muted(desc_text, 13)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		texts.add_child(d)
	var c := CheckButton.new()
	c.button_pressed = value
	c.focus_mode = Control.FOCUS_ALL
	c.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(c)
	c.toggled.connect(func(v: bool):
		if on_toggle.is_valid():
			on_toggle.call(v)
	)
	h.set_meta("check", c)
	return h


static func stepper_row(title_text: String, desc_text: String, value: int, minv: int, maxv: int, on_change: Callable, suffix: String = "") -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var texts := VBoxContainer.new()
	texts.add_theme_constant_override("separation", 1)
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(texts)
	texts.add_child(UiTheme.text(title_text, 16, UiTheme.TEXT))
	if not desc_text.is_empty():
		texts.add_child(UiTheme.muted(desc_text, 13))
	var minus := UiTheme.button("−", "GhostButton", 40)
	minus.custom_minimum_size = Vector2(42, 40)
	h.add_child(minus)
	var val := UiTheme.text_label(str(value) + suffix, 18, UiTheme.LIME)
	val.custom_minimum_size = Vector2(56, 0)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(val)
	var plus := UiTheme.button("+", "GhostButton", 40)
	plus.custom_minimum_size = Vector2(42, 40)
	h.add_child(plus)
	var state := {"v": value}
	var apply := func(delta: int):
		state["v"] = clampi(int(state["v"]) + delta, minv, maxv)
		val.text = str(state["v"]) + suffix
		if on_change.is_valid():
			on_change.call(int(state["v"]))
	minus.pressed.connect(func(): apply.call(-1))
	plus.pressed.connect(func(): apply.call(1))
	h.set_meta("value_label", val)
	h.set_meta("get_value", func(): return int(state["v"]))
	return h


static func choice_row(title_text: String, options: Array, selected_value: Variant, on_select: Callable) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 7)
	v.add_child(UiTheme.text(title_text, 16, UiTheme.TEXT))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	var group := ButtonGroup.new()
	group.allow_unpress = false
	var buttons: Array = []
	for opt in options:
		var o: Dictionary = opt
		var b := UiTheme.button(str(o.get("label", "?")), "Chip", 38)
		b.toggle_mode = true
		b.button_group = group
		b.custom_minimum_size = Vector2(0, 38)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.button_pressed = (o.get("value", null) == selected_value)
		if o.has("color"):
			b.add_theme_color_override("font_pressed_color", o["color"])
		var value: Variant = o.get("value", null)
		b.pressed.connect(func():
			if on_select.is_valid():
				on_select.call(value)
		)
		row.add_child(b)
		buttons.append(b)
	v.set_meta("buttons", buttons)
	return v


static func tint_button(b: Button, color: Color) -> void:
	b.add_theme_stylebox_override("normal", UiTheme.button_style(color, color.darkened(0.18), 12))
	b.add_theme_stylebox_override("hover", UiTheme.button_style(color.lightened(0.14), Color.WHITE, 12))
	b.add_theme_stylebox_override("pressed", UiTheme.button_style(color.darkened(0.12), Color.WHITE, 12))
	b.add_theme_stylebox_override("focus", UiTheme.focus_style(Color.WHITE, 12))
	b.add_theme_color_override("font_color", UiTheme.DARK_TEXT)
	b.add_theme_color_override("font_hover_color", UiTheme.DARK_TEXT)
	b.add_theme_color_override("font_pressed_color", UiTheme.DARK_TEXT)


static func keycap(text_value: String) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1, 1, 1, 0.08)
	sb.border_color = Color(1, 1, 1, 0.18)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(6)
	sb.content_margin_left = 8
	sb.content_margin_right = 8
	sb.content_margin_top = 2
	sb.content_margin_bottom = 2
	p.add_theme_stylebox_override("panel", sb)
	var l := UiTheme.text_label(text_value, 12, UiTheme.TEXT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	return p


static func left_shade(width: int = 620, alpha: float = 0.92) -> TextureRect:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	g.colors = PackedColorArray([
		Color(0.035, 0.03, 0.05, alpha),
		Color(0.035, 0.03, 0.05, alpha * 0.78),
		Color(0.035, 0.03, 0.05, 0.0),
	])
	var tex := GradientTexture2D.new()
	tex.gradient = g
	tex.fill_from = Vector2(0, 0)
	tex.fill_to = Vector2(1, 0)
	tex.width = 256
	tex.height = 4
	var tr := TextureRect.new()
	tr.texture = tex
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.anchor_left = 0.0
	tr.anchor_top = 0.0
	tr.anchor_right = 0.0
	tr.anchor_bottom = 1.0
	tr.offset_right = width
	return tr


static func vignette(alpha: float = 0.55) -> TextureRect:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.62, 1.0])
	g.colors = PackedColorArray([
		Color(0.02, 0.015, 0.03, 0.0),
		Color(0.02, 0.015, 0.03, alpha * 0.25),
		Color(0.02, 0.015, 0.03, alpha),
	])
	var tex := GradientTexture2D.new()
	tex.gradient = g
	tex.fill = GradientTexture2D.FILL_RADIAL
	tex.fill_from = Vector2(0.5, 0.45)
	tex.fill_to = Vector2(1.05, 0.55)
	tex.width = 256
	tex.height = 256
	var tr := TextureRect.new()
	tr.texture = tex
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	return tr


static func spacer_height(height: int) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, height)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


static func tag_heading(text_value: String, color: Color = UiTheme.GOLD) -> Label:
	var l := UiTheme.text_label(text_value.to_upper(), 12, color)
	l.add_theme_constant_override("outline_size", 0)
	return l
