class_name LobbyScreen
extends GameScreen
## LAN lobby: roster, map vote, readiness and host controls.

var _roster: VBoxContainer
var _map_buttons: Dictionary = {}
var _map_title: Label
var _map_desc: Label
var _count_label: Label
var _status: Label
var _start_button: Button
var _ready_button: Button
var _add_bot_button: Button
var _remove_bot_button: Button
var _address: Label
var _char_name: Label
var _char_title: Label
var _host_box: VBoxContainer


func build() -> void:
	add_child(UiKit.left_shade(1050, 0.9))
	add_child(UiKit.vignette(0.42))
	var margin := UiTheme.margin(40)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 13)
	margin.add_child(root)
	root.add_child(UiKit.page_header("LOBBY", "Everyone in the same room, pretending to be strategic.", "LEAVE", func(): main.leave_network()))

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 20)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(columns)

	# ---- roster
	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 8)
	columns.add_child(left)
	var head := HBoxContainer.new()
	left.add_child(head)
	var hl := UiTheme.text("WHO IS COMING", 17, UiTheme.TEXT)
	hl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(hl)
	_count_label = UiTheme.text_label("0 / 10", 13, UiTheme.MUTED)
	head.add_child(_count_label)

	var roster_panel := UiKit.panel_box(12, Color(0.055, 0.048, 0.072, 0.92), Color(1, 1, 1, 0.1), 16)
	roster_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	left.add_child(roster_panel)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	roster_panel.add_child(scroll)
	_roster = VBoxContainer.new()
	_roster.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_roster.add_theme_constant_override("separation", 7)
	scroll.add_child(_roster)

	# ---- controls
	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(560, 0)
	right.add_theme_constant_override("separation", 10)
	columns.add_child(right)

	var map_panel := UiKit.panel_box(18, Color(0.065, 0.055, 0.085, 0.94), Color(1, 1, 1, 0.11), 16)
	right.add_child(map_panel)
	var mv := VBoxContainer.new()
	mv.add_theme_constant_override("separation", 8)
	map_panel.add_child(mv)
	mv.add_child(UiKit.tag_heading("THE VENUE", UiTheme.GOLD))
	_map_title = UiTheme.text("Suburban House", 26, UiTheme.TEXT)
	mv.add_child(_map_title)
	_map_desc = UiTheme.muted("", 13)
	_map_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_map_desc.custom_minimum_size = Vector2(0, 34)
	mv.add_child(_map_desc)
	var chips := HBoxContainer.new()
	chips.add_theme_constant_override("separation", 6)
	mv.add_child(chips)
	var group := ButtonGroup.new()
	group.allow_unpress = false
	for m in Config.maps:
		var data: Dictionary = m
		var b := UiTheme.button("%s  %s" % [str(data["icon"]), str(data["name"])], "Chip", 38)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.toggle_mode = true
		b.button_group = group
		b.add_theme_font_size_override("font_size", 12)
		var mid := str(data["id"])
		b.pressed.connect(func(): _pick_map(mid))
		chips.add_child(b)
		_map_buttons[mid] = b

	var char_panel := UiKit.panel_box(14, Color(0.065, 0.055, 0.085, 0.9), Color(1, 1, 1, 0.09), 14)
	right.add_child(char_panel)
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 10)
	char_panel.add_child(ch)
	var ctext := VBoxContainer.new()
	ctext.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ch.add_child(ctext)
	ctext.add_child(UiKit.tag_heading("YOUR LEGEND", UiTheme.MUTED))
	_char_name = UiTheme.text("Brunhilda", 20, UiTheme.TEXT)
	ctext.add_child(_char_name)
	_char_title = UiTheme.muted("The Loud", 12)
	ctext.add_child(_char_title)
	var prev := UiTheme.button("‹", "GhostButton", 38)
	prev.custom_minimum_size = Vector2(44, 38)
	prev.pressed.connect(func(): _cycle_character(-1))
	ch.add_child(prev)
	var nxt := UiTheme.button("›", "GhostButton", 38)
	nxt.custom_minimum_size = Vector2(44, 38)
	nxt.pressed.connect(func(): _cycle_character(1))
	ch.add_child(nxt)

	_host_box = VBoxContainer.new()
	_host_box.add_theme_constant_override("separation", 8)
	right.add_child(_host_box)
	_add_bot_button = UiTheme.button("+ ADD A BOT", "GhostButton", 40)
	_add_bot_button.pressed.connect(func(): Net.add_bot(); _refresh())
	_host_box.add_child(_add_bot_button)
	_remove_bot_button = UiTheme.button("− REMOVE LAST BOT", "GhostButton", 36)
	_remove_bot_button.pressed.connect(func(): Net.remove_bot(); _refresh())
	_host_box.add_child(_remove_bot_button)

	var address_panel := UiKit.panel_box(11, Color(0.08, 0.07, 0.105, 0.8), Color(1, 1, 1, 0.07), 10)
	right.add_child(address_panel)
	var ap := VBoxContainer.new()
	address_panel.add_child(ap)
	ap.add_child(UiTheme.text_label("INVITE ADDRESS", 10, UiTheme.MUTED))
	_address = UiTheme.text_label("", 15, UiTheme.GOLD)
	_address.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	ap.add_child(_address)

	right.add_child(UiTheme.spacer())

	_ready_button = UiTheme.button("I'M READY", "PrimaryButton", 48)
	_ready_button.pressed.connect(_toggle_ready)
	right.add_child(_ready_button)

	_start_button = UiTheme.button("START MATCH", "PrimaryButton", 56)
	_start_button.pressed.connect(func(): main.begin_host_match())
	right.add_child(_start_button)

	_status = UiTheme.text_label("", 12, UiTheme.MUTED)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right.add_child(_status)

	Net.lobby_changed.connect(_refresh)
	Net.server_disconnected.connect(func(): _on_disconnected(""))
	Net.connection_failed.connect(_on_disconnected)


func on_show(_data: Dictionary = {}) -> void:
	main.set_preview_map(Net.lobby_map)
	main.set_preview_character(Settings.character_id)
	main.play_menu_music()
	_refresh()


func _refresh() -> void:
	if _roster == null:
		return
	var is_host := Net.is_hosting()
	var ids := Net.players.keys()
	ids.sort_custom(_sort_ids)
	_count_label.text = "%d / %d" % [ids.size(), Net.MAX_PLAYERS]

	for child in _roster.get_children():
		child.queue_free()
	for id in ids:
		_roster.add_child(_player_row(int(id), Net.players[id], is_host))

	var map_data := Config.map_data(Net.lobby_map)
	_map_title.text = str(map_data["name"])
	_map_title.add_theme_color_override("font_color", map_data["accent"])
	_map_desc.text = str(map_data["desc"])
	for key in _map_buttons.keys():
		var b: Button = _map_buttons[key]
		b.button_pressed = key == Net.lobby_map
		b.disabled = not is_host
	_map_title.add_theme_color_override("font_color", map_data["accent"])

	_host_box.visible = is_host
	_start_button.visible = is_host
	_ready_button.visible = not is_host
	if is_host:
		_add_bot_button.disabled = ids.size() >= Net.MAX_PLAYERS
		_remove_bot_button.disabled = not _has_bot(ids)
	else:
		var me: Dictionary = Net.players.get(Net.my_id(), {})
		_ready_button.text = "✓ READY — CLICK TO UNREADY" if bool(me.get("ready", false)) else "I'M READY"
		_ready_button.theme_type_variation = "GhostButton" if bool(me.get("ready", false)) else "PrimaryButton"

	_address.text = "Port %d  ·  %s" % [Net.host_port, "   ".join(Net.local_addresses())] if is_host else "Connected to host"
	if is_host:
		var ready := _all_ready(ids)
		var enough := ids.size() >= 2
		_start_button.disabled = not (ready and enough)
		if not enough:
			_status.text = "Add a bot or wait for another player."
		elif not ready:
			_status.text = "Waiting for every human to ready up."
		else:
			_status.text = "All set. Start when you are ready."
		_status.add_theme_color_override("font_color", UiTheme.LIME if ready and enough else UiTheme.MUTED)
	else:
		_status.text = "Waiting for the host to start the match."
		_status.add_theme_color_override("font_color", UiTheme.MUTED)

	_refresh_character()


func _player_row(id: int, info: Dictionary, host_view: bool) -> PanelContainer:
	var p := PanelContainer.new()
	var is_bot := bool(info.get("bot", false))
	var is_self := id == Net.my_id()
	var accent := UiTheme.MUTED
	var char_data := Config.character_data(str(info.get("character", "barbarian")))
	accent = char_data["color"]
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.085, 0.075, 0.105, 0.95)
	sb.border_color = Color(accent.r, accent.g, accent.b, 0.5) if is_self else Color(1, 1, 1, 0.07)
	sb.set_border_width_all(2 if is_self else 1)
	sb.set_corner_radius_all(12)
	sb.content_margin_left = 13
	sb.content_margin_right = 13
	sb.content_margin_top = 10
	sb.content_margin_bottom = 10
	p.add_theme_stylebox_override("panel", sb)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 11)
	p.add_child(h)
	var dot := UiTheme.text_label("●", 20, accent)
	h.add_child(dot)
	var texts := VBoxContainer.new()
	texts.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	texts.add_theme_constant_override("separation", 0)
	h.add_child(texts)
	var name_row := HBoxContainer.new()
	name_row.add_theme_constant_override("separation", 7)
	texts.add_child(name_row)
	var nm := UiTheme.text_label(str(info.get("name", "Player")), 17, UiTheme.TEXT)
	name_row.add_child(nm)
	if is_self:
		name_row.add_child(UiTheme.pill("YOU", UiTheme.LIME))
	if bool(info.get("host", false)):
		name_row.add_child(UiTheme.pill("HOST", UiTheme.GOLD))
	if is_bot:
		name_row.add_child(UiTheme.pill("BOT", UiTheme.BLUE))
	var meta := UiTheme.muted("%s · %s" % [str(char_data["name"]), str(char_data["title"])], 12)
	texts.add_child(meta)
	if bool(info.get("ready", false)):
		h.add_child(UiTheme.pill("READY", UiTheme.LIME))
	else:
		h.add_child(UiTheme.pill("NOT READY", UiTheme.MUTED, 0.1))
	if host_view and not is_self and not is_bot:
		var kick := UiTheme.button("KICK", "DangerButton", 32)
		kick.custom_minimum_size = Vector2(72, 32)
		kick.add_theme_font_size_override("font_size", 12)
		kick.pressed.connect(func(): Net.kick(id); _refresh())
		h.add_child(kick)
	return p


func _sort_ids(a: Variant, b: Variant) -> bool:
	if int(a) == 1:
		return true
	if int(b) == 1:
		return false
	return int(a) < int(b)


func _has_bot(ids: Array) -> bool:
	for id in ids:
		if bool(Net.players[id].get("bot", false)):
			return true
	return false


func _all_ready(ids: Array) -> bool:
	for id in ids:
		var info: Dictionary = Net.players[id]
		if bool(info.get("bot", false)):
			continue
		if not bool(info.get("ready", false)):
			return false
	return true


func _pick_map(id: String) -> void:
	if not Net.is_hosting():
		return
	Net.set_map(id)
	main.set_preview_map(id)
	_refresh()


func _toggle_ready() -> void:
	var me: Dictionary = Net.players.get(Net.my_id(), {})
	Net.set_ready(not bool(me.get("ready", false)))
	_refresh()


func _refresh_character() -> void:
	var data := Config.character_data(Settings.character_id)
	_char_name.text = str(data["name"])
	_char_name.add_theme_color_override("font_color", data["color"])
	_char_title.text = str(data["title"])


func _cycle_character(dir: int) -> void:
	var ids: Array = []
	for c in Config.characters:
		ids.append(str(c["id"]))
	var idx := ids.find(Settings.character_id)
	idx = (idx + dir + ids.size()) % ids.size()
	Settings.set_value("character_id", str(ids[idx]))
	Net.set_character(str(ids[idx]))
	main.set_preview_character(str(ids[idx]))
	_refresh_character()
	_refresh()


func _on_disconnected(_reason: String = "") -> void:
	if _status:
		_status.text = "Connection lost. Returning to the main menu."
		_status.add_theme_color_override("font_color", UiTheme.PINK)
