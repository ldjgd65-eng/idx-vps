class_name UiTheme
## Central visual language for every ShameRun screen.

const BG := Color(0.04, 0.03, 0.06, 1.0)
const PANEL := Color(0.09, 0.08, 0.12, 0.95)
const PANEL_SOFT := Color(0.14, 0.12, 0.17, 0.92)
const LINE := Color(0.28, 0.24, 0.34, 0.85)
const TEXT := Color(0.94, 0.93, 0.96)
const MUTED := Color(0.66, 0.63, 0.72)
const LIME := Color(0.45, 1.0, 0.65)
const PINK := Color(1.0, 0.32, 0.48)
const GOLD := Color(1.0, 0.78, 0.31)
const BLUE := Color(0.38, 0.64, 0.92)
const PURPLE := Color(0.7, 0.52, 0.95)
const DARK_TEXT := Color(0.06, 0.07, 0.08)

static var _body_font: Font
static var _title_font: Font
static var _theme: Theme


static func body_font() -> Font:
	if _body_font == null:
		_body_font = load("res://assets/fonts/Fredoka.ttf")
	return _body_font


static func title_font() -> Font:
	if _title_font == null:
		_title_font = load("res://assets/fonts/LuckiestGuy.ttf")
	return _title_font


static func get_theme() -> Theme:
	if _theme == null:
		_theme = build()
	return _theme


static func build() -> Theme:
	var t := Theme.new()
	t.default_font = body_font()
	t.default_font_size = 17

	# ---- base label
	t.set_color("font_color", "Label", TEXT)
	t.set_font("font", "Label", body_font())
	t.set_font_size("font_size", "Label", 17)
	t.set_constant("outline_size", "Label", 0)

	# ---- label variations
	_label_variation(t, "Title", title_font(), 74, TEXT, 10, Color(0.03, 0.02, 0.05, 0.85))
	_label_variation(t, "H1", title_font(), 44, TEXT, 6, Color(0.03, 0.02, 0.05, 0.8))
	_label_variation(t, "H2", body_font(), 27, TEXT, 0, Color.TRANSPARENT)
	_label_variation(t, "H3", body_font(), 20, TEXT, 0, Color.TRANSPARENT)
	_label_variation(t, "Muted", body_font(), 15, MUTED, 0, Color.TRANSPARENT)
	_label_variation(t, "Tiny", body_font(), 12, MUTED, 0, Color.TRANSPARENT)
	_label_variation(t, "Tag", body_font(), 12, GOLD, 0, Color.TRANSPARENT)
	_label_variation(t, "Lime", body_font(), 17, LIME, 0, Color.TRANSPARENT)
	_label_variation(t, "Pink", body_font(), 17, PINK, 0, Color.TRANSPARENT)
	_label_variation(t, "Gold", body_font(), 17, GOLD, 0, Color.TRANSPARENT)

	# ---- panels
	t.set_stylebox("panel", "PanelContainer", panel(PANEL, LINE, 18, 1))
	t.set_stylebox("panel", "Panel", panel(PANEL, LINE, 18, 1))
	t.set_stylebox("panel", "ScrollContainer", StyleBoxEmpty.new())

	# ---- base button
	t.set_font("font", "Button", body_font())
	t.set_font_size("font_size", "Button", 18)
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", TEXT)
	t.set_color("font_pressed_color", "Button", TEXT)
	t.set_color("font_disabled_color", "Button", Color(0.5, 0.48, 0.55))
	t.set_stylebox("normal", "Button", button_style(PANEL_SOFT, LINE, 12))
	t.set_stylebox("hover", "Button", button_style(Color(0.18, 0.15, 0.23), Color.LIME.darkened(0.25), 12))
	t.set_stylebox("pressed", "Button", button_style(Color(0.12, 0.1, 0.16), LIME, 12))
	t.set_stylebox("focus", "Button", focus_style(LIME, 12))
	t.set_stylebox("disabled", "Button", button_style(Color(0.09, 0.08, 0.11, 0.7), Color(0.25, 0.23, 0.27), 12))

	# ---- primary button
	_variation(t, "PrimaryButton")
	t.set_stylebox("normal", "PrimaryButton", button_style(LIME, LIME.darkened(0.2), 12))
	t.set_stylebox("hover", "PrimaryButton", button_style(LIME.lightened(0.15), Color.WHITE, 12))
	t.set_stylebox("pressed", "PrimaryButton", button_style(LIME.darkened(0.1), Color.WHITE, 12))
	t.set_stylebox("focus", "PrimaryButton", focus_style(Color.WHITE, 12))
	t.set_stylebox("disabled", "PrimaryButton", button_style(Color(0.22, 0.28, 0.24, 0.7), Color(0.3, 0.35, 0.32), 12))
	for k in ["font_color", "font_hover_color", "font_pressed_color"]:
		t.set_color(k, "PrimaryButton", DARK_TEXT)
	t.set_color("font_disabled_color", "PrimaryButton", Color(0.5, 0.55, 0.52))
	t.set_font("font", "PrimaryButton", body_font())
	t.set_font_size("font_size", "PrimaryButton", 19)

	# ---- danger button
	_variation(t, "DangerButton")
	t.set_stylebox("normal", "DangerButton", button_style(Color(0.32, 0.09, 0.15), PINK.darkened(0.1), 12))
	t.set_stylebox("hover", "DangerButton", button_style(Color(0.45, 0.12, 0.2), PINK, 12))
	t.set_stylebox("pressed", "DangerButton", button_style(Color(0.5, 0.13, 0.22), PINK.lightened(0.1), 12))
	t.set_stylebox("focus", "DangerButton", focus_style(PINK, 12))
	t.set_color("font_color", "DangerButton", Color(1.0, 0.88, 0.9))
	t.set_color("font_hover_color", "DangerButton", Color.WHITE)
	t.set_font("font", "DangerButton", body_font())
	t.set_font_size("font_size", "DangerButton", 18)

	# ---- ghost button
	_variation(t, "GhostButton")
	t.set_stylebox("normal", "GhostButton", button_style(Color(0, 0, 0, 0), Color(0.32, 0.29, 0.38, 0.8), 10, 1))
	t.set_stylebox("hover", "GhostButton", button_style(Color(1, 1, 1, 0.08), Color(0.55, 0.5, 0.64), 10, 1))
	t.set_stylebox("pressed", "GhostButton", button_style(Color(1, 1, 1, 0.12), LIME, 10, 1))
	t.set_stylebox("focus", "GhostButton", focus_style(LIME, 10))
	t.set_color("font_color", "GhostButton", MUTED)
	t.set_color("font_hover_color", "GhostButton", TEXT)
	t.set_font("font", "GhostButton", body_font())
	t.set_font_size("font_size", "GhostButton", 16)

	# ---- card button
	_variation(t, "CardButton")
	t.set_stylebox("normal", "CardButton", card_style(PANEL_SOFT, LINE))
	t.set_stylebox("hover", "CardButton", card_style(Color(0.16, 0.13, 0.2, 0.96), Color(0.5, 0.46, 0.6)))
	t.set_stylebox("pressed", "CardButton", card_style(Color(0.18, 0.15, 0.23, 0.98), LIME))
	t.set_stylebox("focus", "CardButton", focus_style(LIME, 14))
	t.set_color("font_color", "CardButton", TEXT)
	t.set_color("font_hover_color", "CardButton", TEXT)
	t.set_font("font", "CardButton", body_font())
	t.set_font_size("font_size", "CardButton", 17)

	# ---- chip
	_variation(t, "Chip")
	t.set_stylebox("normal", "Chip", button_style(Color(0.11, 0.095, 0.14), LINE, 22, 1))
	t.set_stylebox("hover", "Chip", button_style(Color(0.16, 0.14, 0.2), Color(0.5, 0.46, 0.6), 22, 1))
	t.set_stylebox("pressed", "Chip", button_style(Color(0.2, 0.26, 0.21), LIME, 22, 2))
	t.set_stylebox("focus", "Chip", focus_style(LIME, 22))
	t.set_color("font_color", "Chip", MUTED)
	t.set_color("font_hover_color", "Chip", TEXT)
	t.set_color("font_pressed_color", "Chip", LIME)
	t.set_font("font", "Chip", body_font())
	t.set_font_size("font_size", "Chip", 15)

	# ---- line edit
	t.set_stylebox("normal", "LineEdit", button_style(Color(0.07, 0.06, 0.09), LINE, 10))
	t.set_stylebox("focus", "LineEdit", button_style(Color(0.08, 0.07, 0.1), LIME, 10, 2))
	t.set_color("font_color", "LineEdit", TEXT)
	t.set_color("font_placeholder_color", "LineEdit", MUTED.darkened(0.2))
	t.set_font("font", "LineEdit", body_font())
	t.set_font_size("font_size", "LineEdit", 17)
	t.set_constant("minimum_character_width", "LineEdit", 4)

	# ---- option button
	t.set_stylebox("normal", "OptionButton", button_style(Color(0.07, 0.06, 0.09), LINE, 10))
	t.set_stylebox("hover", "OptionButton", button_style(Color(0.12, 0.1, 0.15), Color(0.5, 0.46, 0.6), 10))
	t.set_stylebox("pressed", "OptionButton", button_style(Color(0.12, 0.1, 0.15), LIME, 10))
	t.set_stylebox("focus", "OptionButton", focus_style(LIME, 10))
	t.set_color("font_color", "OptionButton", TEXT)
	t.set_font("font", "OptionButton", body_font())
	t.set_font_size("font_size", "OptionButton", 16)
	t.set_stylebox("panel", "PopupMenu", panel(Color(0.08, 0.07, 0.11), LINE, 10, 1))
	t.set_color("font_color", "PopupMenu", TEXT)
	t.set_font("font", "PopupMenu", body_font())

	# ---- slider
	var slider := StyleBoxFlat.new()
	slider.bg_color = Color(0.16, 0.14, 0.2)
	slider.set_corner_radius_all(4)
	slider.content_margin_top = 3
	slider.content_margin_bottom = 3
	t.set_stylebox("slider", "HSlider", slider)
	var grabber := StyleBoxFlat.new()
	grabber.bg_color = LIME
	grabber.set_corner_radius_all(8)
	grabber.content_margin_left = 9
	grabber.content_margin_right = 9
	grabber.content_margin_top = 9
	grabber.content_margin_bottom = 9
	t.set_stylebox("grabber_area", "HSlider", grabber)
	t.set_stylebox("grabber_area_highlight", "HSlider", grabber)

	# ---- check
	t.set_stylebox("normal", "CheckButton", button_style(Color(0, 0, 0, 0), Color(0, 0, 0, 0), 8))
	t.set_color("font_color", "CheckButton", TEXT)
	t.set_color("font_pressed_color", "CheckButton", LIME)
	t.set_font("font", "CheckButton", body_font())
	t.set_font_size("font_size", "CheckButton", 16)

	# ---- progress
	var pb_bg := StyleBoxFlat.new()
	pb_bg.bg_color = Color(0.12, 0.1, 0.15, 0.9)
	pb_bg.set_corner_radius_all(6)
	t.set_stylebox("background", "ProgressBar", pb_bg)
	var pb_fill := StyleBoxFlat.new()
	pb_fill.bg_color = LIME
	pb_fill.set_corner_radius_all(6)
	t.set_stylebox("fill", "ProgressBar", pb_fill)

	# ---- scrollbar
	var scroll := StyleBoxFlat.new()
	scroll.bg_color = Color(0.3, 0.27, 0.36, 0.8)
	scroll.set_corner_radius_all(4)
	t.set_stylebox("grabber", "VScrollBar", scroll)
	t.set_stylebox("grabber_highlight", "VScrollBar", scroll)
	t.set_stylebox("grabber_pressed", "VScrollBar", scroll)

	# ---- rich text
	t.set_font("normal_font", "RichTextLabel", body_font())
	t.set_font_size("normal_font_size", "RichTextLabel", 17)
	t.set_color("default_color", "RichTextLabel", TEXT)
	t.set_font("bold_font", "RichTextLabel", body_font())
	t.set_font_size("bold_font_size", "RichTextLabel", 17)
	t.set_color("font_selected_color", "RichTextLabel", TEXT)
	return t


static func _label_variation(t: Theme, name: String, font: Font, size: int, color: Color, outline: int, outline_color: Color) -> void:
	t.set_type_variation(name, "Label")
	t.set_font("font", name, font)
	t.set_font_size("font_size", name, size)
	t.set_color("font_color", name, color)
	if outline > 0:
		t.set_constant("outline_size", name, outline)
		t.set_color("font_outline_color", name, outline_color)


static func _variation(t: Theme, name: String) -> void:
	t.set_type_variation(name, "Button")


static func panel(bg: Color, border: Color, radius: int = 16, border_width: int = 1) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_width)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 18
	sb.content_margin_bottom = 18
	sb.shadow_color = Color(0, 0, 0, 0.35)
	sb.shadow_size = 12
	return sb


static func button_style(bg: Color, border: Color, radius: int = 12, border_width: int = 1) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(border_width)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 22
	sb.content_margin_right = 22
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	return sb


static func card_style(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(14)
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 14
	sb.content_margin_bottom = 14
	return sb


static func focus_style(color: Color, radius: int = 12) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0, 0, 0, 0)
	sb.border_color = color
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(radius)
	sb.draw_center = false
	return sb


static func title(text: String, size: int = 74) -> Label:
	var l := Label.new()
	l.text = text
	l.theme_type_variation = "Title" if size >= 60 else "H1"
	if size < 60 and size >= 34:
		l.theme_type_variation = "H1"
	l.add_theme_font_override("font", title_font())
	l.add_theme_font_size_override("font_size", size)
	return l


static func heading(text: String, size: int = 27) -> Label:
	var l := Label.new()
	l.text = text
	l.theme_type_variation = "H2" if size >= 24 else "H3"
	l.add_theme_font_size_override("font_size", size)
	return l


static func text(text: String, size: int = 17, color: Color = TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", body_font())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func muted(text: String, size: int = 15) -> Label:
	return UiTheme.text(text, size, MUTED)


static func tag(text: String, color: Color = GOLD) -> Label:
	var l := text_label(text, 12, color)
	l.add_theme_constant_override("outline_size", 0)
	return l


static func text_label(value: String, size: int, color: Color) -> Label:
	var l := Label.new()
	l.text = value
	l.add_theme_font_override("font", body_font())
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


static func button(text_value: String, variant: String = "", min_height: float = 48.0) -> Button:
	var b := Button.new()
	b.text = text_value
	b.custom_minimum_size = Vector2(0, min_height)
	b.focus_mode = Control.FOCUS_ALL
	if not variant.is_empty():
		b.theme_type_variation = variant
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	b.pressed.connect(func(): Audio.play_ui("click"))
	return b


static func icon_button(symbol: String, tooltip: String = "") -> Button:
	var b := button(symbol, "GhostButton", 40)
	b.custom_minimum_size = Vector2(44, 40)
	b.tooltip_text = tooltip
	return b


static func card(title_text: String, body_text: String, accent: Color = LIME) -> Button:
	var b := Button.new()
	b.theme_type_variation = "CardButton"
	b.custom_minimum_size = Vector2(0, 92)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	var box := VBoxContainer.new()
	box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 18
	box.offset_right = -18
	box.offset_top = 12
	box.offset_bottom = -12
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 2)
	var t := text_label(title_text, 19, TEXT)
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(t)
	var d := text_label(body_text, 13, MUTED)
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	d.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(d)
	b.add_child(box)
	b.pressed.connect(func(): Audio.play_ui("click"))
	return b


static func vbox(separation: int = 10) -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", separation)
	return v


static func hbox(separation: int = 10) -> HBoxContainer:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", separation)
	return h


static func spacer(expand: bool = true) -> Control:
	var c := Control.new()
	if expand:
		c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		c.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return c


static func margin(amount: int = 24) -> MarginContainer:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", amount)
	m.add_theme_constant_override("margin_right", amount)
	m.add_theme_constant_override("margin_top", amount)
	m.add_theme_constant_override("margin_bottom", amount)
	return m


static func separator() -> HSeparator:
	var s := HSeparator.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1, 1, 1, 0.08)
	sb.content_margin_top = 1
	sb.content_margin_bottom = 1
	s.add_theme_stylebox_override("separator", sb)
	return s


static func pill(text_value: String, color: Color, bg_alpha: float = 0.16) -> PanelContainer:
	var p := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(color.r, color.g, color.b, bg_alpha)
	sb.border_color = Color(color.r, color.g, color.b, 0.55)
	sb.set_border_width_all(1)
	sb.set_corner_radius_all(20)
	sb.content_margin_left = 12
	sb.content_margin_right = 12
	sb.content_margin_top = 4
	sb.content_margin_bottom = 4
	p.add_theme_stylebox_override("panel", sb)
	var l := text_label(text_value, 12, color)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	p.add_child(l)
	return p
