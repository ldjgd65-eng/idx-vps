class_name NetworkMenu
extends GameScreen
## LAN host / join screen with discovery.

var _name_edit: LineEdit
var _host_port: LineEdit
var _max_players := 8
var _join_ip: LineEdit
var _join_port: LineEdit
var _status: Label
var _server_list: VBoxContainer
var _scan_button: Button
var _host_button: Button
var _join_button: Button
var _address_label: Label
var _empty_hint: Label
var _scanning := false


func build() -> void:
	add_child(UiKit.left_shade(1100, 0.9))
	add_child(UiKit.vignette(0.42))
	var margin := UiTheme.margin(42)
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(margin)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 14)
	margin.add_child(root)
	root.add_child(UiKit.page_header("PLAY ONLINE", "Same Wi-Fi. Same chaos. No servers, no accounts, no excuses.", "BACK", func(): main.show_screen("main_menu")))

	var identity := UiKit.panel_box(16, Color(0.065, 0.055, 0.085, 0.9), Color(1, 1, 1, 0.1), 14)
	root.add_child(identity)
	var ih := HBoxContainer.new()
	ih.add_theme_constant_override("separation", 16)
	identity.add_child(ih)
	var label_box := VBoxContainer.new()
	label_box.custom_minimum_size = Vector2(180, 0)
	label_box.add_child(UiTheme.text("Your display name", 16, UiTheme.TEXT))
	label_box.add_child(UiTheme.muted("Visible to everyone in the lobby.", 12))
	ih.add_child(label_box)
	_name_edit = LineEdit.new()
	_name_edit.placeholder_text = "Player name"
	_name_edit.max_length = 18
	_name_edit.custom_minimum_size = Vector2(260, 44)
	_name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_name_edit.text_changed.connect(func(t: String):
		var clean := t.strip_edges().substr(0, 18)
		if not clean.is_empty():
			Settings.set_value("player_name", clean)
			if Net.is_online():
				Net.set_player_name(clean)
	)
	ih.add_child(_name_edit)
	var profile := UiTheme.muted("", 12)
	ih.add_child(profile)

	var columns := HBoxContainer.new()
	columns.add_theme_constant_override("separation", 22)
	columns.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(columns)

	# ---- host
	var host := UiKit.panel_box(24, Color(0.06, 0.05, 0.08, 0.94), Color(1, 1, 1, 0.12), 18)
	host.custom_minimum_size = Vector2(560, 0)
	host.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(host)
	var hv := VBoxContainer.new()
	hv.add_theme_constant_override("separation", 12)
	host.add_child(hv)
	hv.add_child(UiKit.tag_heading("HOST A GAME", UiTheme.LIME))
	var htitle := UiTheme.text("Be the reason everyone is late for dinner.", 24, UiTheme.TEXT)
	htitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hv.add_child(htitle)
	hv.add_child(UiTheme.muted("Your PC runs the match. Everyone on the same network can join with your IP address, or find you automatically with LAN scan.", 14))
	hv.add_child(UiTheme.separator())

	var port_row := HBoxContainer.new()
	port_row.add_theme_constant_override("separation", 12)
	hv.add_child(port_row)
	var pl := VBoxContainer.new()
	pl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	port_row.add_child(pl)
	pl.add_child(UiTheme.text("Port", 16, UiTheme.TEXT))
	pl.add_child(UiTheme.muted("Default is fine unless it is already in use.", 12))
	_host_port = LineEdit.new()
	_host_port.text = str(Net.DEFAULT_PORT)
	_host_port.custom_minimum_size = Vector2(120, 42)
	port_row.add_child(_host_port)

	hv.add_child(UiKit.stepper_row("Max players", "Humans and bots combined.", _max_players, 2, Net.MAX_PLAYERS, func(v: int): _max_players = v, ""))

	var addresses := UiKit.panel_box(12, Color(0.08, 0.07, 0.105, 0.8), Color(1, 1, 1, 0.08), 10)
	hv.add_child(addresses)
	var av := VBoxContainer.new()
	addresses.add_child(av)
	av.add_child(UiTheme.text_label("YOUR LAN ADDRESS", 10, UiTheme.MUTED))
	_address_label = UiTheme.text_label("Checking...", 18, UiTheme.GOLD)
	_address_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	av.add_child(_address_label)

	hv.add_child(UiTheme.spacer())
	_host_button = UiTheme.button("HOST GAME", "PrimaryButton", 56)
	_host_button.pressed.connect(_host)
	hv.add_child(_host_button)
	var firewall := UiTheme.muted("If friends cannot join, allow ShameRun through Windows Firewall (Private networks).", 12)
	firewall.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hv.add_child(firewall)

	# ---- join
	var join := UiKit.panel_box(24, Color(0.06, 0.05, 0.08, 0.94), Color(1, 1, 1, 0.12), 18)
	join.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	columns.add_child(join)
	var jv := VBoxContainer.new()
	jv.add_theme_constant_override("separation", 11)
	join.add_child(jv)
	jv.add_child(UiKit.tag_heading("JOIN A GAME", UiTheme.BLUE))
	var jtitle := UiTheme.text("Someone else has the good snacks.", 24, UiTheme.TEXT)
	jtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	jv.add_child(jtitle)
	jv.add_child(UiTheme.muted("Enter the host's address, or scan the local network.", 14))
	jv.add_child(UiTheme.separator())

	var ip_row := HBoxContainer.new()
	ip_row.add_theme_constant_override("separation", 10)
	jv.add_child(ip_row)
	var ip_box := VBoxContainer.new()
	ip_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ip_row.add_child(ip_box)
	ip_box.add_child(UiTheme.text("Host IP", 16, UiTheme.TEXT))
	_join_ip = LineEdit.new()
	_join_ip.placeholder_text = "192.168.1.42"
	_join_ip.text = "127.0.0.1"
	_join_ip.custom_minimum_size = Vector2(0, 42)
	ip_box.add_child(_join_ip)
	var port_box := VBoxContainer.new()
	port_box.custom_minimum_size = Vector2(100, 0)
	ip_row.add_child(port_box)
	port_box.add_child(UiTheme.text("Port", 16, UiTheme.TEXT))
	_join_port = LineEdit.new()
	_join_port.text = str(Net.DEFAULT_PORT)
	_join_port.custom_minimum_size = Vector2(100, 42)
	port_box.add_child(_join_port)

	_join_button = UiTheme.button("JOIN GAME", "PrimaryButton", 50)
	UiKit.tint_button(_join_button, UiTheme.BLUE)
	_join_button.pressed.connect(_join)
	jv.add_child(_join_button)

	jv.add_child(UiTheme.separator())
	var scan_head := HBoxContainer.new()
	jv.add_child(scan_head)
	var sl := UiTheme.text("Games on your network", 17, UiTheme.TEXT)
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scan_head.add_child(sl)
	_scan_button = UiTheme.button("SCAN", "GhostButton", 34)
	_scan_button.custom_minimum_size = Vector2(100, 34)
	_scan_button.pressed.connect(_scan)
	scan_head.add_child(_scan_button)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 190)
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	jv.add_child(scroll)
	_server_list = VBoxContainer.new()
	_server_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_server_list.add_theme_constant_override("separation", 7)
	scroll.add_child(_server_list)
	var empty := UiTheme.muted("No games found yet. Press SCAN while the host is waiting in their lobby.", 12)
	empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	empty.name = "EmptyHint"
	_empty_hint = empty
	_server_list.add_child(empty)

	_status = UiTheme.text_label("", 13, UiTheme.MUTED)
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(_status)

	Net.connection_failed.connect(_on_failed)
	Net.connection_succeeded.connect(_on_connected)
	Net.discovery_finished.connect(_on_discovery)


func on_show(_data: Dictionary = {}) -> void:
	_name_edit.text = Settings.player_name
	_address_label.text = _addresses_text()
	_status.text = "Ready. Host a game or join one."
	_status.add_theme_color_override("font_color", UiTheme.MUTED)
	main.play_menu_music()
	if Net.is_online():
		if Game.state == Config.MatchState.LOBBY:
			main.show_screen("lobby")


func _addresses_text() -> String:
	var addrs := Net.local_addresses()
	if addrs.is_empty():
		return "No LAN address detected. Use 127.0.0.1 for this PC."
	return "   ·   ".join(addrs)


func _host() -> void:
	var port := int(_host_port.text)
	if port <= 0 or port > 65535:
		port = Net.DEFAULT_PORT
	_status.text = "Opening port %d..." % port
	_status.add_theme_color_override("font_color", UiTheme.GOLD)
	if main.host_game(port, _max_players):
		_status.text = "Lobby open on port %d." % port
		_status.add_theme_color_override("font_color", UiTheme.LIME)
		main.show_screen("lobby")
	else:
		_status.text = "Could not host on port %d. Try another port." % port
		_status.add_theme_color_override("font_color", UiTheme.PINK)


func _join() -> void:
	var ip := _join_ip.text.strip_edges()
	if ip.is_empty():
		ip = "127.0.0.1"
	var port := int(_join_port.text)
	if port <= 0 or port > 65535:
		port = Net.DEFAULT_PORT
	_status.text = "Connecting to %s:%d..." % [ip, port]
	_status.add_theme_color_override("font_color", UiTheme.GOLD)
	_join_button.disabled = true
	main.join_game(ip, port)


func _scan() -> void:
	if _scanning:
		return
	_scanning = true
	_scan_button.text = "SCANNING..."
	_scan_button.disabled = true
	_status.text = "Listening for LAN beacons..."
	_status.add_theme_color_override("font_color", UiTheme.GOLD)
	var found: Array = await Net.scan_lan(1.8)
	_scanning = false
	_scan_button.text = "SCAN"
	_scan_button.disabled = false
	_on_discovery(found)


func _on_discovery(servers: Array) -> void:
	for child in _server_list.get_children():
		if child.name != "EmptyHint":
			child.queue_free()
	if servers.is_empty():
		_status.text = "No games found. Ask the host for their IP address."
		_status.add_theme_color_override("font_color", UiTheme.MUTED)
		if _empty_hint:
			_empty_hint.visible = true
		return
	if _empty_hint:
		_empty_hint.visible = false
	_status.text = "%d game%s found." % [servers.size(), "" if servers.size() == 1 else "s"]
	_status.add_theme_color_override("font_color", UiTheme.LIME)
	for entry in servers:
		var s: Dictionary = entry
		var b := UiTheme.button("", "CardButton", 62)
		b.custom_minimum_size = Vector2(0, 62)
		_server_list.add_child(b)
		var box := VBoxContainer.new()
		box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		box.offset_left = 14
		box.offset_right = -14
		box.offset_top = 8
		box.offset_bottom = -8
		box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_theme_constant_override("separation", 0)
		b.add_child(box)
		var nm := UiTheme.text_label("%s  ·  %s" % [str(s.get("name", "Host")), str(Config.map_data(str(s.get("map", "suburban")))["name"])], 16, UiTheme.TEXT)
		nm.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(nm)
		var addr := UiTheme.muted("%s:%d" % [str(s.get("ip", "?")), int(s.get("port", Net.DEFAULT_PORT))], 12)
		addr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		box.add_child(addr)
		var ip := str(s.get("ip", "127.0.0.1"))
		var port := int(s.get("port", Net.DEFAULT_PORT))
		b.pressed.connect(_join_to.bind(ip, port))


func _join_to(ip: String, port: int) -> void:
	_join_ip.text = ip
	_join_port.text = str(port)
	_join()


func _on_failed(reason: String) -> void:
	_join_button.disabled = false
	_status.text = reason
	_status.add_theme_color_override("font_color", UiTheme.PINK)


func _on_connected() -> void:
	_join_button.disabled = false
	_status.text = "Connected."
	_status.add_theme_color_override("font_color", UiTheme.LIME)
