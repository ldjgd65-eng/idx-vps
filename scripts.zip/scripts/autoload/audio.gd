extends Node
## Central audio routing, music crossfades and pooled SFX playback.

signal caption_shown(text: String)

const AUDIO_DIR := "res://assets/audio"
const MUSIC_MENU := "music_menu"
const MUSIC_GAME := "music_game"

var streams: Dictionary = {}
var _sfx_pool: Array[AudioStreamPlayer] = []
var _sfx_index := 0
var _music_a: AudioStreamPlayer
var _music_b: AudioStreamPlayer
var _music_active: AudioStreamPlayer
var _current_music := ""
var _music_tween: Tween


func _ready() -> void:
	_ensure_buses()
	_load_streams()
	_build_players()


func _ensure_buses() -> void:
	if AudioServer.get_bus_index("Music") == -1:
		AudioServer.add_bus()
		var i := AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, "Music")
		AudioServer.set_bus_send(i, "Master")
	if AudioServer.get_bus_index("SFX") == -1:
		AudioServer.add_bus()
		var i := AudioServer.bus_count - 1
		AudioServer.set_bus_name(i, "SFX")
		AudioServer.set_bus_send(i, "Master")
	apply_volumes()


func _load_streams() -> void:
	var files := DirAccess.get_files_at(AUDIO_DIR)
	for f in files:
		var ext := f.get_extension().to_lower()
		if ext in ["import", "uid"]:
			continue
		var key := f.get_basename()
		var path := AUDIO_DIR + "/" + f
		if ResourceLoader.exists(path):
			var res := load(path)
			if res is AudioStream:
				streams[key] = res
	if streams.has(MUSIC_MENU) and streams[MUSIC_MENU] is AudioStreamMP3:
		streams[MUSIC_MENU].loop = true
	if streams.has(MUSIC_GAME) and streams[MUSIC_GAME] is AudioStreamMP3:
		streams[MUSIC_GAME].loop = true


func _build_players() -> void:
	_music_a = AudioStreamPlayer.new()
	_music_a.bus = "Music"
	_music_a.volume_db = -80.0
	add_child(_music_a)
	_music_b = AudioStreamPlayer.new()
	_music_b.bus = "Music"
	_music_b.volume_db = -80.0
	add_child(_music_b)
	_music_active = _music_a
	for i in 14:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_sfx_pool.append(p)


func apply_volumes() -> void:
	var m := AudioServer.get_bus_index("Master")
	if m >= 0:
		AudioServer.set_bus_volume_db(m, linear_to_db(maxf(0.0001, Settings.master_volume)))
	var mu := AudioServer.get_bus_index("Music")
	if mu >= 0:
		AudioServer.set_bus_volume_db(mu, linear_to_db(maxf(0.0001, Settings.music_volume)))
	var s := AudioServer.get_bus_index("SFX")
	if s >= 0:
		AudioServer.set_bus_volume_db(s, linear_to_db(maxf(0.0001, Settings.sfx_volume)))


func play_music(track: String, fade: float = 1.2) -> void:
	if _current_music == track and _music_active.playing:
		return
	if not streams.has(track):
		return
	_current_music = track
	var incoming: AudioStreamPlayer = _music_b if _music_active == _music_a else _music_a
	var outgoing: AudioStreamPlayer = _music_active
	incoming.stream = streams[track]
	incoming.volume_db = -60.0
	incoming.play()
	_music_active = incoming
	if _music_tween and _music_tween.is_valid():
		_music_tween.kill()
	_music_tween = create_tween()
	_music_tween.set_parallel(true)
	_music_tween.tween_property(incoming, "volume_db", -4.0, fade)
	if outgoing.playing:
		_music_tween.tween_property(outgoing, "volume_db", -60.0, fade)
		_music_tween.chain().tween_callback(outgoing.stop)


func stop_music(fade: float = 0.8) -> void:
	_current_music = ""
	if _music_tween and _music_tween.is_valid():
		_music_tween.kill()
	_music_tween = create_tween()
	_music_tween.tween_property(_music_active, "volume_db", -60.0, fade)
	_music_tween.tween_callback(_music_active.stop)


func play_sfx(sound_name: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not streams.has(sound_name):
		return
	var p := _sfx_pool[_sfx_index]
	_sfx_index = (_sfx_index + 1) % _sfx_pool.size()
	p.stream = streams[sound_name]
	p.volume_db = volume_db
	p.pitch_scale = clampf(pitch, 0.4, 2.2)
	p.play()


func play_ui(sound_name: String = "click") -> void:
	play_sfx(sound_name, -6.0, randf_range(0.97, 1.03))


func play_3d(sound_name: String, pos: Vector3, volume_db: float = 0.0, max_distance: float = 24.0) -> void:
	if not streams.has(sound_name):
		return
	var root := get_tree().current_scene
	if root == null:
		return
	var p := AudioStreamPlayer3D.new()
	p.stream = streams[sound_name]
	p.bus = "SFX"
	p.position = pos
	p.volume_db = volume_db
	p.max_distance = max_distance
	p.unit_size = 4.0
	p.attenuation_model = AudioStreamPlayer3D.ATTENUATION_INVERSE_DISTANCE
	p.pitch_scale = randf_range(0.95, 1.06)
	root.add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


func caption(text: String) -> void:
	if Settings.captions:
		caption_shown.emit(text)
