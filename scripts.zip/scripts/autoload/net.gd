extends Node
## LAN networking: host/join lifecycle, lobby roster and discovery beacon.

signal lobby_changed
signal peer_joined(id: int)
signal peer_left(id: int)
signal connection_succeeded
signal connection_failed(reason: String)
signal server_disconnected
signal discovery_finished(servers: Array)

const DEFAULT_PORT := 7777
const MAX_PLAYERS := 10
const BEACON_PORT := 47778
const BEACON_INTERVAL := 1.0
const PROTOCOL := "SHAMERUN1"

var players: Dictionary = {}
var lobby_map: String = "suburban"
var is_discovering := false
var host_port := DEFAULT_PORT

var _beacon_timer := 0.0
var _beacon_sender: PacketPeerUDP
var _discovery_socket: PacketPeerUDP
var _discovered: Dictionary = {}


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)


func _process(delta: float) -> void:
	if is_hosting():
		_beacon_timer -= delta
		if _beacon_timer <= 0.0:
			_beacon_timer = BEACON_INTERVAL
			_send_beacon()
	if is_discovering and _discovery_socket:
		while _discovery_socket.get_available_packet_count() > 0:
			var pkt := _discovery_socket.get_packet()
			var ip := _discovery_socket.get_packet_ip()
			var txt := pkt.get_string_from_utf8()
			var parts := txt.split("|")
			if parts.size() >= 4 and parts[0] == PROTOCOL:
				var port := int(parts[2])
				var key := "%s:%d" % [ip, port]
				_discovered[key] = {
					"ip": ip, "port": port, "name": parts[1], "map": parts[3],
				}


func is_online() -> bool:
	return multiplayer.multiplayer_peer is ENetMultiplayerPeer


func is_hosting() -> bool:
	return is_online() and multiplayer.is_server()


func my_id() -> int:
	if is_online():
		return multiplayer.get_unique_id()
	return 1


func host_game(port: int = DEFAULT_PORT, max_players: int = MAX_PLAYERS) -> bool:
	leave(false)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, clampi(max_players, 2, MAX_PLAYERS))
	if err != OK:
		connection_failed.emit("Could not open port %d. Is another game hosting?" % port)
		return false
	multiplayer.multiplayer_peer = peer
	host_port = port
	players.clear()
	players[1] = {
		"name": Settings.player_name,
		"character": Settings.character_id,
		"ready": true,
		"host": true,
		"bot": false,
		"role": Config.Role.LOBBY,
	}
	_beacon_sender = PacketPeerUDP.new()
	_beacon_sender.set_broadcast_enabled(true)
	_beacon_timer = 0.0
	lobby_changed.emit()
	return true


func join_game(ip: String, port: int = DEFAULT_PORT) -> bool:
	leave(false)
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), port)
	if err != OK:
		connection_failed.emit("Could not reach %s:%d." % [ip, port])
		return false
	multiplayer.multiplayer_peer = peer
	return true


func leave(notify_game: bool = true) -> void:
	if _beacon_sender:
		_beacon_sender.close()
		_beacon_sender = null
	if is_online():
		multiplayer.multiplayer_peer.close()
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	players.clear()
	lobby_map = "suburban"
	if notify_game:
		lobby_changed.emit()


func set_ready(value: bool) -> void:
	if is_hosting():
		if players.has(1):
			players[1]["ready"] = value
		_broadcast_lobby()
	elif is_online():
		rpc_id(1, "_request_ready", value)


func set_character(character_id: String) -> void:
	if is_hosting():
		if players.has(1):
			players[1]["character"] = character_id
		_broadcast_lobby()
	elif is_online():
		rpc_id(1, "_request_character", character_id)


func set_map(map_id: String) -> void:
	if is_hosting():
		lobby_map = map_id
		_broadcast_lobby()


func set_player_name(new_name: String) -> void:
	if is_hosting():
		if players.has(1):
			players[1]["name"] = new_name
		_broadcast_lobby()
	elif is_online():
		rpc_id(1, "_request_name", new_name)


func add_bot(character_id: String = "") -> void:
	if not is_hosting():
		return
	if players.size() >= MAX_PLAYERS:
		return
	var id := _next_bot_id()
	var cid := character_id if not character_id.is_empty() else Config.random_bot_character()
	players[id] = {
		"name": Config.random_bot_name(), "character": cid,
		"ready": true, "host": false, "bot": true, "role": Config.Role.LOBBY,
	}
	_broadcast_lobby()


func remove_bot() -> void:
	if not is_hosting():
		return
	var ids := players.keys()
	ids.sort()
	for i in range(ids.size() - 1, -1, -1):
		if players[ids[i]].get("bot", false):
			players.erase(ids[i])
			break
	_broadcast_lobby()


func kick(id: int) -> void:
	if not is_hosting() or id == 1:
		return
	if players.has(id):
		players.erase(id)
	if multiplayer.multiplayer_peer is ENetMultiplayerPeer:
		var peer := multiplayer.multiplayer_peer as ENetMultiplayerPeer
		var p := peer.get_peer(id)
		if p:
			p.disconnect_peer()
	_broadcast_lobby()


func set_lobby_role(id: int, role: int) -> void:
	if players.has(id):
		players[id]["role"] = role


func human_count() -> int:
	var n := 0
	for id in players:
		if not players[id].get("bot", false):
			n += 1
	return n


func _next_bot_id() -> int:
	var id := 1000
	while players.has(id):
		id += 1
	return id


func _send_beacon() -> void:
	if _beacon_sender == null:
		return
	var port := host_port
	var msg := "%s|%s|%d|%s" % [PROTOCOL, Settings.player_name, port, lobby_map]
	_beacon_sender.set_dest_address("255.255.255.255", BEACON_PORT)
	_beacon_sender.put_packet(msg.to_utf8_buffer())


func scan_lan(duration: float = 1.6) -> Array:
	if is_discovering:
		return _discovered.values()
	_discovered.clear()
	_discovery_socket = PacketPeerUDP.new()
	_discovery_socket.set_broadcast_enabled(true)
	var err := _discovery_socket.bind(BEACON_PORT)
	if err != OK:
		_discovery_socket = null
		discovery_finished.emit([])
		return []
	is_discovering = true
	await get_tree().create_timer(duration).timeout
	is_discovering = false
	if _discovery_socket:
		_discovery_socket.close()
		_discovery_socket = null
	var list: Array = _discovered.values()
	discovery_finished.emit(list)
	return list


func local_addresses() -> Array:
	var out: Array = []
	for ip in IP.get_local_addresses():
		if ip.contains(".") and not ip.begins_with("127.") and not ip.begins_with("169.254"):
			out.append(ip)
	return out


func refresh_lobby() -> void:
	if is_hosting():
		_broadcast_lobby()


func _broadcast_lobby() -> void:
	if not is_hosting():
		return
	_sync_lobby.rpc(players.duplicate(true), lobby_map)
	lobby_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _sync_lobby(roster: Dictionary, map_id: String) -> void:
	players = roster
	lobby_map = map_id
	lobby_changed.emit()


@rpc("any_peer", "call_remote", "reliable")
func _submit_identity(info: Dictionary) -> void:
	if not is_hosting():
		return
	var id := multiplayer.get_remote_sender_id()
	if id <= 0:
		return
	var nm := str(info.get("name", "Player")).strip_edges()
	if nm.length() > 18:
		nm = nm.substr(0, 18)
	var cid := str(info.get("character", "barbarian"))
	players[id] = {
		"name": nm if not nm.is_empty() else "Player", "character": cid,
		"ready": false, "host": false, "bot": false, "role": Config.Role.LOBBY,
	}
	_broadcast_lobby()
	peer_joined.emit(id)


@rpc("any_peer", "call_remote", "reliable")
func _request_ready(value: bool) -> void:
	if not is_hosting():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		players[id]["ready"] = value
		_broadcast_lobby()


@rpc("any_peer", "call_remote", "reliable")
func _request_character(character_id: String) -> void:
	if not is_hosting():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		players[id]["character"] = character_id
		_broadcast_lobby()


@rpc("any_peer", "call_remote", "reliable")
func _request_name(new_name: String) -> void:
	if not is_hosting():
		return
	var id := multiplayer.get_remote_sender_id()
	if players.has(id):
		var nm := new_name.strip_edges().substr(0, 18)
		if not nm.is_empty():
			players[id]["name"] = nm
		_broadcast_lobby()


func _on_peer_connected(id: int) -> void:
	if is_hosting():
		peer_joined.emit(id)


func _on_peer_disconnected(id: int) -> void:
	if is_hosting():
		players.erase(id)
		_broadcast_lobby()
	peer_left.emit(id)


func _on_connected_to_server() -> void:
	connection_succeeded.emit()
	rpc_id(1, "_submit_identity", {
		"name": Settings.player_name, "character": Settings.character_id,
	})


func _on_connection_failed() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	connection_failed.emit("Connection failed. Check the IP and that the host is running.")


func _on_server_disconnected() -> void:
	multiplayer.multiplayer_peer = OfflineMultiplayerPeer.new()
	players.clear()
	server_disconnected.emit()
