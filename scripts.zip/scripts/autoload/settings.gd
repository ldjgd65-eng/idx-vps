extends Node
## Persistent user preferences: audio, display, accessibility, controls.

signal setting_changed(key: String, value: Variant)

const SAVE_PATH := "user://shamerun_settings.cfg"

var player_name: String = ""
var character_id: String = "barbarian"
var master_volume: float = 0.9
var music_volume: float = 0.55
var sfx_volume: float = 0.9
var sensitivity: float = 1.0
var invert_y: bool = false
var fov: float = 76.0
var camera_shake: float = 1.0
var captions: bool = true
var ui_scale: float = 1.0
var fullscreen: bool = false
var vsync: bool = true
var shadows: bool = true
var show_fps: bool = false
var bindings: Dictionary = {}
var total_xp: int = 0
var matches_played: int = 0

var _loaded := false


func _ready() -> void:
	bindings = Config.DEFAULT_BINDINGS.duplicate()
	load_settings()
	if player_name.is_empty():
		player_name = "Player %03d" % randi_range(1, 999)
	apply_all(false)


func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) != OK:
		_loaded = true
		return
	player_name = str(cf.get_value("profile", "player_name", player_name))
	character_id = str(cf.get_value("profile", "character", character_id))
	total_xp = int(cf.get_value("profile", "xp", 0))
	matches_played = int(cf.get_value("profile", "matches", 0))
	master_volume = float(cf.get_value("audio", "master", master_volume))
	music_volume = float(cf.get_value("audio", "music", music_volume))
	sfx_volume = float(cf.get_value("audio", "sfx", sfx_volume))
	sensitivity = float(cf.get_value("controls", "sensitivity", sensitivity))
	invert_y = bool(cf.get_value("controls", "invert_y", invert_y))
	bindings = cf.get_value("controls", "bindings", bindings)
	if not (bindings is Dictionary) or bindings.is_empty():
		bindings = Config.DEFAULT_BINDINGS.duplicate()
	fov = float(cf.get_value("video", "fov", fov))
	camera_shake = float(cf.get_value("video", "shake", camera_shake))
	captions = bool(cf.get_value("access", "captions", captions))
	ui_scale = float(cf.get_value("access", "ui_scale", ui_scale))
	fullscreen = bool(cf.get_value("video", "fullscreen", fullscreen))
	vsync = bool(cf.get_value("video", "vsync", vsync))
	shadows = bool(cf.get_value("video", "shadows", shadows))
	show_fps = bool(cf.get_value("video", "show_fps", show_fps))
	_loaded = true


func save_settings() -> void:
	var cf := ConfigFile.new()
	cf.set_value("profile", "player_name", player_name)
	cf.set_value("profile", "character", character_id)
	cf.set_value("profile", "xp", total_xp)
	cf.set_value("profile", "matches", matches_played)
	cf.set_value("audio", "master", master_volume)
	cf.set_value("audio", "music", music_volume)
	cf.set_value("audio", "sfx", sfx_volume)
	cf.set_value("controls", "sensitivity", sensitivity)
	cf.set_value("controls", "invert_y", invert_y)
	cf.set_value("controls", "bindings", bindings)
	cf.set_value("video", "fov", fov)
	cf.set_value("video", "shake", camera_shake)
	cf.set_value("video", "fullscreen", fullscreen)
	cf.set_value("video", "vsync", vsync)
	cf.set_value("video", "shadows", shadows)
	cf.set_value("video", "show_fps", show_fps)
	cf.set_value("access", "captions", captions)
	cf.set_value("access", "ui_scale", ui_scale)
	cf.save(SAVE_PATH)


func set_value(key: String, value: Variant, persist: bool = true) -> void:
	set(key, value)
	if persist:
		save_settings()
	setting_changed.emit(key, value)
	match key:
		"master_volume", "music_volume", "sfx_volume":
			Audio.apply_volumes()
		"fullscreen":
			apply_display()
		"vsync":
			apply_vsync()
		"ui_scale":
			apply_ui_scale()
		"fov", "sensitivity", "invert_y", "camera_shake", "captions", "shadows":
			pass


func set_binding(action: String, keycode: int) -> void:
	bindings[action] = keycode
	Config.setup_input(bindings)
	save_settings()
	setting_changed.emit("bindings", bindings)


func reset_bindings() -> void:
	bindings = Config.DEFAULT_BINDINGS.duplicate()
	Config.setup_input(bindings)
	save_settings()
	setting_changed.emit("bindings", bindings)


func add_match_result(xp: int) -> void:
	total_xp += maxi(0, xp)
	matches_played += 1
	save_settings()


func apply_all(with_save: bool = true) -> void:
	apply_display()
	apply_vsync()
	apply_ui_scale()
	if with_save:
		save_settings()


func apply_display() -> void:
	if DisplayServer.get_name() == "headless":
		return
	var mode := DisplayServer.WINDOW_MODE_FULLSCREEN if fullscreen else DisplayServer.WINDOW_MODE_WINDOWED
	DisplayServer.window_set_mode(mode)


func apply_vsync() -> void:
	if DisplayServer.get_name() == "headless":
		return
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED if vsync else DisplayServer.VSYNC_DISABLED)


func apply_ui_scale() -> void:
	var win := get_window()
	if win:
		win.content_scale_factor = clampf(ui_scale, 0.75, 1.35)
