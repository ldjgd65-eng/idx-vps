extends Node
## Global constants, character/map catalog and input bindings.

const GAME_NAME := "ShameRun"
const GAME_VERSION := "1.0.0"

enum Role { RUNNER, CHASER, HELPER, LOBBY }
enum MatchState { MENU, LOBBY, PREPARING, COUNTDOWN, ACTIVE, RESOLVING, RESULTS }

const ROLE_NAMES := ["RUNNER", "CHASER", "HELPER", "LOBBY"]
const ROLE_COLORS := [
	Color(0.45, 0.95, 0.62),
	Color(1.0, 0.38, 0.32),
	Color(0.55, 0.72, 1.0),
	Color(0.7, 0.7, 0.7),
]
const ROLE_ICONS := ["●", "▲", "✦", "·"]

const DEFAULT_BINDINGS := {
	"move_forward": KEY_W,
	"move_back": KEY_S,
	"move_left": KEY_A,
	"move_right": KEY_D,
	"sprint": KEY_SHIFT,
	"crouch": KEY_CTRL,
	"jump": KEY_SPACE,
	"interact": KEY_E,
	"catch": KEY_F,
	"drop": KEY_G,
	"sense": KEY_Q,
	"emote": KEY_C,
	"pause": KEY_ESCAPE,
	"scoreboard": KEY_TAB,
}

const ACTION_LABELS := {
	"move_forward": "Move Forward",
	"move_back": "Move Back",
	"move_left": "Move Left",
	"move_right": "Move Right",
	"sprint": "Sprint",
	"crouch": "Crouch / Sneak",
	"jump": "Jump",
	"interact": "Interact / Hide",
	"catch": "Catch (Chaser)",
	"drop": "Drop Prop",
	"sense": "Sense / Reveal Hint",
	"emote": "Emote Wheel",
	"pause": "Pause",
	"scoreboard": "Scoreboard",
}

var characters: Array = []
var maps: Array = []
var bot_names: Array = [
	"Sir Tripsalot", "Lady Oops", "Captain Clumsy", "Baron von Bumble",
	"Mx. Mishap", "Duke Dizzy", "Countess Clatter", "Professor Panic",
	"Tiny Trouble", "Wobbly Wendy", "Sneaky Pete", "Madame Mayhem",
	"Lord Lurk", "Pickle Pete", "Noodle", "Gloop",
]

var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	_rng.randomize()
	_build_catalog()
	setup_input()


func _build_catalog() -> void:
	characters = [
		{
			"id": "barbarian", "name": "Brunhilda", "title": "The Loud",
			"path": "res://assets/characters/gltf/Barbarian.glb",
			"color": Color(1.0, 0.55, 0.22), "scale": 0.92,
			"blurb": "Announces every plan at full volume. Somehow still wins.",
		},
		{
			"id": "knight", "name": "Sir Reginald", "title": "The Honourable",
			"path": "res://assets/characters/gltf/Knight.glb",
			"color": Color(0.42, 0.68, 1.0), "scale": 0.94,
			"blurb": "Will absolutely stop to apologise after catching you.",
		},
		{
			"id": "mage", "name": "Wizzle", "title": "The Unlicensed",
			"path": "res://assets/characters/gltf/Mage.glb",
			"color": Color(0.72, 0.5, 1.0), "scale": 0.92,
			"blurb": "Casts 'Hide Very Well' which is just crouching.",
		},
		{
			"id": "rogue", "name": "Slink", "title": "The Subtle",
			"path": "res://assets/characters/gltf/Rogue.glb",
			"color": Color(0.4, 0.9, 0.55), "scale": 0.9,
			"blurb": "Professional hider. Amateur at everything else.",
		},
		{
			"id": "rogue_hooded", "name": "Shadow", "title": "The Mysterious",
			"path": "res://assets/characters/gltf/Rogue_Hooded.glb",
			"color": Color(0.85, 0.35, 0.45), "scale": 0.9,
			"blurb": "No one knows their name. They keep telling everyone.",
		},
	]
	maps = [
		{
			"id": "suburban", "name": "Suburban House", "tag": "HOME SWEET HOME",
			"desc": "A cosy family home with thin walls, loud floors and far too many closets.",
			"players": "2–8", "size": "Medium", "accent": Color(0.45, 0.9, 0.62),
			"icon": "⌂",
		},
		{
			"id": "mansion", "name": "The Mansion", "tag": "OLD MONEY, NEW PANIC",
			"desc": "Marble halls, endless side rooms and a very judgmental portrait gallery.",
			"players": "4–10", "size": "Large", "accent": Color(0.95, 0.72, 0.35),
			"icon": "♜",
		},
		{
			"id": "apartment", "name": "Apartment 4B", "tag": "CLOSE QUARTERS",
			"desc": "Tight corridors, thin ceilings and neighbours who have heard everything.",
			"players": "2–6", "size": "Compact", "accent": Color(0.55, 0.72, 1.0),
			"icon": "▤",
		},
	]


func character_data(id: String) -> Dictionary:
	for c in characters:
		if c["id"] == id:
			return c
	return characters[0]


func map_data(id: String) -> Dictionary:
	for m in maps:
		if m["id"] == id:
			return m
	return maps[0]


func role_name(role: int) -> String:
	return ROLE_NAMES[clampi(role, 0, ROLE_NAMES.size() - 1)]


func role_color(role: int) -> Color:
	return ROLE_COLORS[clampi(role, 0, ROLE_COLORS.size() - 1)]


func role_icon(role: int) -> String:
	return ROLE_ICONS[clampi(role, 0, ROLE_ICONS.size() - 1)]


func time_string(seconds: float) -> String:
	var s := maxi(0, int(ceil(seconds)))
	return "%d:%02d" % [int(s / 60), int(s % 60)]


func random_bot_name() -> String:
	return bot_names[_rng.randi_range(0, bot_names.size() - 1)]


func random_bot_character() -> String:
	return characters[_rng.randi_range(0, characters.size() - 1)]["id"]


func setup_input(bindings: Dictionary = {}) -> void:
	var keys := bindings.duplicate()
	if keys.is_empty():
		keys = DEFAULT_BINDINGS.duplicate()
	for action in keys.keys():
		if InputMap.has_action(action):
			InputMap.erase_action(action)
		InputMap.add_action(action, 0.2)
		var ev := InputEventKey.new()
		ev.physical_keycode = int(keys[action])
		InputMap.action_add_event(action, ev)
	# Mouse throw is intentionally fixed.
	if InputMap.has_action("throw"):
		InputMap.erase_action("throw")
	InputMap.add_action("throw", 0.2)
	var mb := InputEventMouseButton.new()
	mb.button_index = MOUSE_BUTTON_LEFT
	InputMap.action_add_event("throw", mb)


func key_name_for_action(action: String) -> String:
	var events := InputMap.action_get_events(action)
	for e in events:
		if e is InputEventKey:
			return OS.get_keycode_string(e.physical_keycode)
		if e is InputEventMouseButton:
			return "Mouse " + str(e.button_index)
	return "—"
