extends Node
## Authoritative match manager: roster, roles, timer, catches, props, results and network sync.

signal state_changed(new_state: int)
signal countdown_changed(value: float)
signal timer_changed(time_left: float)
signal match_event(text: String, color: Color)
signal match_ended(result: Dictionary)
signal local_player_ready(player: Player)
signal local_role_changed(role: int)
signal hint_ping(direction: Vector3, distance_text: String)
signal sense_ping(ids: Array)
signal scoreboard_changed(visible_now: bool)
signal loading_text(text: String)
signal roster_changed

const COUNTDOWN_TIME := 5.0
const DEFAULT_TIME := 300.0
const SWAP_CHANCE := 0.30
const NET_RATE_MS := 45
const SERVER_SYNC_MS := 55
const CATCH_RANGE := 3.35
const CATCH_SERVER_CD := 2.0

var state: int = Config.MatchState.MENU
var paused := false
var map_id := "suburban"
var world_root: Node3D
var map: MapBuilder
var players: Dictionary = {}
var local_peer_id := 1
var match_time := DEFAULT_TIME
var time_left := DEFAULT_TIME
var countdown := 0.0
var is_solo := true
var solo_config: Dictionary = {}

var swap_chance := SWAP_CHANCE
var bot_difficulty := 1
var match_settings: Dictionary = {}

var _rng := RandomNumberGenerator.new()
var _last_report_ms := 0
var _server_sync_ms := 0
var _last_second := -1
var _net_positions: Dictionary = {}
var _server_catch_cd: Dictionary = {}
var _catch_lock: Dictionary = {}
var _pickups_by_id: Dictionary = {}
var _pickup_respawn: Dictionary = {}
var _projectiles: Dictionary = {}
var _traps: Dictionary = {}
var _bots: Dictionary = {}
var _stats: Dictionary = {}
var _pending_ready: Dictionary = {}
var _expected_clients := 0
var _spawns: Array = []
var _last_noise: Dictionary = {}
var _match_token := 0
var _loading := false
var _hint_by_chaser: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_rng.randomize()
	Net.peer_left.connect(_on_peer_left)
	Net.server_disconnected.connect(_on_server_disconnected)
	Net.connection_failed.connect(_on_connection_failed)


# =============================================================== public API

func is_authority() -> bool:
	if not Net.is_online():
		return true
	return multiplayer.is_server()


func local_player() -> Player:
	return players.get(local_peer_id)


func get_player(id: int) -> Player:
	return players.get(id)


func active_runners() -> Array:
	var out: Array = []
	for p in players.values():
		if is_instance_valid(p) and p.role == Config.Role.RUNNER and p.alive:
			out.append(p)
	return out


func active_chasers() -> Array:
	var out: Array = []
	for p in players.values():
		if is_instance_valid(p) and p.role == Config.Role.CHASER:
			out.append(p)
	return out


func scoreboard_rows() -> Array:
	var rows: Array = []
	for id in _stats.keys():
		var st: Dictionary = _stats[id]
		var p: Player = players.get(id)
		rows.append({
			"id": id, "name": str(st.get("name", "Player")),
			"role": p.role if p and is_instance_valid(p) else int(st.get("role", 0)),
			"catches": int(st.get("catches", 0)),
			"caught": int(st.get("caught", 0)),
			"hidden": float(st.get("hidden_time", 0.0)),
			"props": int(st.get("props", 0)),
			"bot": bool(st.get("bot", false)),
		})
	rows.sort_custom(func(a, b):
		if int(a["role"]) != int(b["role"]):
			return int(a["role"]) < int(b["role"])
		return str(a["name"]) < str(b["name"])
	)
	return rows


func start_solo(config: Dictionary) -> void:
	if Net.is_online():
		Net.leave(false)
	is_solo = true
	local_peer_id = 1
	_match_token += 1
	solo_config = config.duplicate(true)
	match_settings = config.duplicate(true)
	map_id = str(config.get("map", "suburban"))
	match_time = float(config.get("timer", DEFAULT_TIME))
	swap_chance = float(config.get("swap_chance", SWAP_CHANCE))
	bot_difficulty = int(config.get("difficulty", 1))
	var roster: Array = []
	roster.append({
		"id": 1, "name": Settings.player_name, "character": Settings.character_id,
		"bot": false, "preferred": int(config.get("role", -1)),
	})
	var bot_count := clampi(int(config.get("bots", 4)), 1, 9)
	var used_names: Array = []
	for i in bot_count:
		var nm := Config.random_bot_name()
		var guard := 0
		while nm in used_names and guard < 24:
			nm = Config.random_bot_name()
			guard += 1
		used_names.append(nm)
		roster.append({
			"id": 1000 + i, "name": nm, "character": Config.random_bot_character(),
			"bot": true, "preferred": -1,
		})
	match_settings["roster"] = roster
	_prepare_local_match(roster)


func host_start_match() -> void:
	if not Net.is_online() or not multiplayer.is_server():
		return
	is_solo = false
	local_peer_id = 1
	var roster: Array = []
	for id in Net.players.keys():
		var info: Dictionary = Net.players[id]
		roster.append({
			"id": int(id), "name": str(info.get("name", "Player")),
			"character": str(info.get("character", "barbarian")),
			"bot": bool(info.get("bot", false)),
			"preferred": int(info.get("role", Config.Role.LOBBY)),
		})
	match_settings = {
		"map": Net.lobby_map,
		"timer": DEFAULT_TIME,
		"swap_chance": SWAP_CHANCE,
		"roster": roster,
		"difficulty": 1,
	}
	map_id = Net.lobby_map
	match_time = DEFAULT_TIME
	swap_chance = SWAP_CHANCE
	bot_difficulty = 1
	_expected_clients = 0
	for id in Net.players.keys():
		if int(id) != 1 and not bool(Net.players[id].get("bot", false)):
			_expected_clients += 1
	_pending_ready.clear()
	_match_token += 1
	var token := _match_token
	_prepare_rpc.rpc(token, map_id, match_time, swap_chance)
	await _prepare_local_match(roster)
	if token != _match_token:
		return
	await _wait_for_clients(token)
	if token != _match_token:
		return
	_spawn_and_start(roster)


func request_rematch() -> void:
	if is_solo:
		start_solo(solo_config)
	elif is_authority():
		host_start_match()


func return_to_menu() -> void:
	_match_token += 1
	paused = false
	_cleanup_world()
	state = Config.MatchState.MENU
	state_changed.emit(state)
	if Net.is_online():
		_return_menu_rpc.rpc()
		await get_tree().create_timer(0.12).timeout
		Net.leave(false)
	roster_changed.emit()


func return_to_lobby() -> void:
	if not Net.is_online():
		return_to_menu()
		return
	_match_token += 1
	paused = false
	_cleanup_world()
	state = Config.MatchState.LOBBY
	state_changed.emit(state)
	_return_lobby_rpc.rpc()
	if multiplayer.is_server():
		for id in Net.players.keys():
			Net.players[id]["role"] = Config.Role.LOBBY
			if int(id) != 1:
				Net.players[id]["ready"] = bool(Net.players[id].get("bot", false))
		Net.refresh_lobby()
	roster_changed.emit()


func pause_game(value: bool) -> void:
	if not is_solo:
		return
	paused = value
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if value else Input.MOUSE_MODE_CAPTURED


# =============================================================== match setup

func _prepare_local_match(roster: Array) -> void:
	var token := _match_token
	print("PREPARE_LOCAL map=", map_id, " roster=", roster.size())
	paused = false
	state = Config.MatchState.PREPARING
	state_changed.emit(state)
	loading_text.emit("Building %s..." % Config.map_data(map_id)["name"])
	_cleanup_world()
	if world_root == null:
		push_error("Game.world_root is not set")
		return
	map = MapBuilder.new()
	world_root.add_child(map)
	await map.build(map_id)
	if token != _match_token:
		return
	_collect_pickups()
	loading_text.emit("Ready")
	roster_changed.emit()


func _wait_for_clients(token: int) -> void:
	var waited := 0.0
	while _pending_ready.size() < _expected_clients and waited < 12.0:
		await get_tree().create_timer(0.1).timeout
		waited += 0.1
		if token != _match_token:
			return


func _spawn_and_start(roster: Array) -> void:
	_spawns = _build_spawns(roster)
	_apply_spawns(_spawns)
	_spawn_all_rpc.rpc(_spawns, match_time, swap_chance)
	state = Config.MatchState.COUNTDOWN
	state_changed.emit(state)
	countdown = COUNTDOWN_TIME
	countdown_changed.emit(countdown)
	_set_state_rpc.rpc(Config.MatchState.COUNTDOWN)
	_countdown_rpc.rpc(COUNTDOWN_TIME)


func _build_spawns(roster: Array) -> Array:
	var points: Array = []
	if map:
		points = map.spawn_points.duplicate()
	if points.is_empty():
		for i in roster.size():
			points.append(Vector3(2.0 + i * 1.2, 0.05, 2.0))
	_shuffle(points)
	var roles := _assign_roles(roster)
	var spawns: Array = []
	var used: Array = []
	for i in roster.size():
		var info: Dictionary = roster[i]
		var id := int(info["id"])
		var chosen: Vector3 = points[i % points.size()]
		if i < points.size():
			var best := chosen
			var best_score := -1.0
			for cand in points:
				if cand in used:
					continue
				var score := 999.0
				for u in used:
					score = minf(score, cand.distance_to(u))
				if score > best_score:
					best_score = score
					best = cand
			chosen = best
		used.append(chosen)
		spawns.append({
			"id": id, "name": str(info.get("name", "Player")),
			"character": str(info.get("character", "barbarian")),
			"bot": bool(info.get("bot", false)),
			"role": int(roles.get(id, Config.Role.RUNNER)),
			"pos": chosen + Vector3(0, 0.08, 0),
		})
	return spawns


func _assign_roles(roster: Array) -> Dictionary:
	var n := roster.size()
	var chaser_count := maxi(1, int(ceil(n / 4.0)))
	if n <= 1:
		chaser_count = 1
	var out: Dictionary = {}
	var preferred_chasers: Array = []
	var preferred_runners: Array = []
	var neutral: Array = []
	for info in roster:
		var pref := int(info.get("preferred", -1))
		if pref == Config.Role.CHASER:
			preferred_chasers.append(int(info["id"]))
		elif pref == Config.Role.RUNNER:
			preferred_runners.append(int(info["id"]))
		else:
			neutral.append(int(info["id"]))
	_shuffle(preferred_chasers)
	_shuffle(neutral)
	_shuffle(preferred_runners)
	for id in preferred_chasers:
		if out.size() < chaser_count:
			out[id] = Config.Role.CHASER
	for id in neutral:
		if out.size() < chaser_count:
			out[id] = Config.Role.CHASER
	for id in preferred_runners:
		if out.size() < chaser_count:
			out[id] = Config.Role.CHASER
	for info in roster:
		var id := int(info["id"])
		if not out.has(id):
			out[id] = Config.Role.RUNNER
	return out


func _apply_spawns(spawns: Array) -> void:
	_clear_players()
	_net_positions.clear()
	_stats.clear()
	_server_catch_cd.clear()
	_catch_lock.clear()
	_bots.clear()
	for entry in spawns:
		var id := int(entry["id"])
		var bot := bool(entry.get("bot", false))
		var p := Player.new()
		p.configure(id, str(entry["name"]), str(entry["character"]), bot, id == local_peer_id)
		p.position = entry["pos"]
		world_root.add_child(p)
		p.set_role(int(entry["role"]))
		players[id] = p
		_stats[id] = {
			"catches": 0, "caught": 0, "props": 0, "slips": 0,
			"hidden_time": 0.0, "survived": 0.0, "role": int(entry["role"]),
			"name": str(entry["name"]), "character": str(entry["character"]),
			"bot": bot,
		}
		if bot:
			var brain := BotBrain.new()
			brain.name = "Bot_%d" % id
			world_root.add_child(brain)
			brain.setup(p, self, map)
			_bots[id] = brain
		if id == local_peer_id:
			local_player_ready.emit(p)
			local_role_changed.emit(p.role)
	roster_changed.emit()


func _collect_pickups() -> void:
	_pickups_by_id.clear()
	_projectiles.clear()
	_traps.clear()
	if map == null:
		return
	for id in map.pickups.keys():
		var pk: PropPickup = map.pickups[id]
		_pickups_by_id[id] = pk


# =============================================================== process

func _process(delta: float) -> void:
	if state == Config.MatchState.MENU or state == Config.MatchState.LOBBY:
		return
	if paused:
		return
	if is_authority():
		_server_tick(delta)
	else:
		_client_tick(delta)


func _server_tick(delta: float) -> void:
	match _match_state():
		Config.MatchState.COUNTDOWN:
			countdown = maxf(0.0, countdown - delta)
			countdown_changed.emit(countdown)
			if countdown <= 0.0:
				state = Config.MatchState.ACTIVE
				state_changed.emit(state)
				_set_state_rpc.rpc(Config.MatchState.ACTIVE)
				_broadcast_event("RUN!", Config.ROLE_COLORS[0])
				Audio.play_sfx("countdown", -4.0, 1.1)
				time_left = match_time
				timer_changed.emit(time_left)
				_sync_timer_rpc.rpc(time_left)
		Config.MatchState.ACTIVE:
			time_left = maxf(0.0, time_left - delta)
			var sec := int(ceil(time_left))
			if sec != _last_second:
				_last_second = sec
				timer_changed.emit(time_left)
				_sync_timer_rpc.rpc(time_left)
			_track_stats(delta)
			_sync_bots(delta)
			if time_left <= 0.0:
				_end_match("runners")
			elif active_runners().is_empty():
				_end_match("chasers")


func _client_tick(delta: float) -> void:
	if state == Config.MatchState.COUNTDOWN:
		countdown = maxf(0.0, countdown - delta)
		countdown_changed.emit(countdown)


func _match_state() -> int:
	return state


func _track_stats(delta: float) -> void:
	for id in _stats.keys():
		var st: Dictionary = _stats[id]
		var p: Player = players.get(id)
		if p == null or not is_instance_valid(p):
			continue
		st["role"] = p.role
		if p.role == Config.Role.RUNNER and p.alive:
			st["survived"] = float(st["survived"]) + delta
			if p.hidden:
				st["hidden_time"] = float(st["hidden_time"]) + delta


func _sync_bots(delta: float) -> void:
	if not Net.is_online():
		return
	_server_sync_ms += int(delta * 1000.0)
	if _server_sync_ms < SERVER_SYNC_MS:
		return
	_server_sync_ms = 0
	for id in _bots.keys():
		var p: Player = players.get(id)
		if p and is_instance_valid(p):
			_net_state_rpc.rpc(id, p.net_state())


# =============================================================== networking state

func report_local_state(p: Player) -> void:
	if p == null or not is_instance_valid(p):
		return
	if paused:
		return
	var now := Time.get_ticks_msec()
	if now - _last_report_ms < NET_RATE_MS:
		return
	_last_report_ms = now
	var st := p.net_state()
	if not Net.is_online():
		return
	if multiplayer.is_server():
		_net_positions[p.peer_id] = st
		_net_state_rpc.rpc(p.peer_id, st)
	else:
		_net_report_rpc.rpc_id(1, p.peer_id, st)


@rpc("any_peer", "call_remote", "unreliable_ordered")
func _net_report_rpc(id: int, st: Dictionary) -> void:
	if not multiplayer.is_server():
		return
	if multiplayer.get_remote_sender_id() != id:
		return
	var p: Player = players.get(id)
	if p == null or not is_instance_valid(p):
		return
	var pos: Vector3 = st.get("pos", p.global_position)
	var old: Dictionary = _net_positions.get(id, {})
	if old.has("pos"):
		var max_move := 22.0
		if pos.distance_to(old["pos"]) > max_move:
			pos = old["pos"]
	st["pos"] = pos
	_net_positions[id] = st
	_net_state_rpc.rpc(id, st)


@rpc("authority", "call_remote", "unreliable_ordered")
func _net_state_rpc(id: int, st: Dictionary) -> void:
	if id == local_peer_id:
		return
	var p: Player = players.get(id)
	if p == null or not is_instance_valid(p):
		return
	p.apply_net_state(
		st.get("pos", p.global_position), float(st.get("yaw", 0.0)),
		str(st.get("anim", "Idle")), bool(st.get("hidden", false)),
		bool(st.get("sprint", false))
	)


func _auth_position(id: int) -> Vector3:
	var p: Player = players.get(id)
	if p == null or not is_instance_valid(p):
		return Vector3.ZERO
	if is_solo or p.is_bot or id == 1:
		return p.global_position
	var st: Dictionary = _net_positions.get(id, {})
	if st.has("pos"):
		return st["pos"]
	return p.global_position


func _auth_hidden(id: int) -> bool:
	var p: Player = players.get(id)
	if p == null:
		return false
	if is_solo or p.is_bot or id == 1:
		return p.hidden
	var st: Dictionary = _net_positions.get(id, {})
	return bool(st.get("hidden", p.hidden))


func _server_los(a: Vector3, b: Vector3) -> bool:
	if world_root == null:
		return true
	var space := world_root.get_world_3d().direct_space_state
	if space == null:
		return true
	var q := PhysicsRayQueryParameters3D.create(a + Vector3(0, 1.2, 0), b + Vector3(0, 1.2, 0), 1)
	var hit := space.intersect_ray(q)
	return hit.is_empty()


# =============================================================== RPC: match lifecycle

@rpc("authority", "call_remote", "reliable")
func _prepare_rpc(token: int, id: String, timer: float, swap: float) -> void:
	if multiplayer.is_server():
		return
	is_solo = false
	local_peer_id = Net.my_id()
	map_id = id
	match_time = timer
	time_left = timer
	swap_chance = swap
	_match_token = token
	state = Config.MatchState.PREPARING
	state_changed.emit(state)
	loading_text.emit("Loading %s..." % Config.map_data(id)["name"])
	_cleanup_world()
	if world_root == null:
		return
	map = MapBuilder.new()
	world_root.add_child(map)
	await map.build(id)
	if token != _match_token:
		return
	_collect_pickups()
	_client_ready_rpc.rpc_id(1, token)


@rpc("any_peer", "call_remote", "reliable")
func _client_ready_rpc(token: int) -> void:
	if not multiplayer.is_server() or token != _match_token:
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender > 0:
		_pending_ready[sender] = true


@rpc("authority", "call_remote", "reliable")
func _spawn_all_rpc(spawns: Array, timer: float, swap: float) -> void:
	if multiplayer.is_server():
		return
	match_time = timer
	time_left = timer
	swap_chance = swap
	local_peer_id = Net.my_id()
	_apply_spawns(spawns)
	state = Config.MatchState.COUNTDOWN
	state_changed.emit(state)


@rpc("authority", "call_remote", "reliable")
func _set_state_rpc(new_state: int) -> void:
	if multiplayer.is_server():
		return
	state = new_state
	state_changed.emit(state)


@rpc("authority", "call_remote", "reliable")
func _countdown_rpc(value: float) -> void:
	if multiplayer.is_server():
		return
	countdown = value
	countdown_changed.emit(value)


@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_timer_rpc(value: float) -> void:
	if multiplayer.is_server():
		return
	time_left = value
	timer_changed.emit(value)


@rpc("authority", "call_remote", "reliable")
func _return_menu_rpc() -> void:
	if multiplayer.is_server():
		return
	paused = false
	_cleanup_world()
	state = Config.MatchState.MENU
	state_changed.emit(state)
	Net.leave(false)
	roster_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _return_lobby_rpc() -> void:
	if multiplayer.is_server():
		return
	paused = false
	_cleanup_world()
	state = Config.MatchState.LOBBY
	state_changed.emit(state)
	roster_changed.emit()


@rpc("authority", "call_remote", "reliable")
func _results_rpc(result: Dictionary) -> void:
	if multiplayer.is_server():
		return
	state = Config.MatchState.RESULTS
	state_changed.emit(state)
	Settings.add_match_result(int(result.get("local_xp", 0)))
	match_ended.emit(result)


# =============================================================== RPC: roles and catch

@rpc("authority", "call_remote", "reliable")
func _role_rpc(id: int, role: int) -> void:
	var p: Player = players.get(id)
	if p == null or not is_instance_valid(p):
		return
	p.set_role(role)
	if id == local_peer_id:
		local_role_changed.emit(role)
	if role == Config.Role.HELPER:
		p.set_frozen(false)


func _apply_role(id: int, role: int) -> void:
	var p: Player = players.get(id)
	if p == null:
		return
	p.set_role(role)
	if id == local_peer_id:
		local_role_changed.emit(role)
	if role == Config.Role.HELPER:
		p.set_frozen(false)
	if Net.is_online():
		_role_rpc.rpc(id, role)


func request_catch(peer_id: int, target_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_catch_rpc.rpc_id(1, peer_id, target_id)
		return
	_resolve_catch(peer_id, target_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_catch_rpc(peer_id: int, target_id: int) -> void:
	if not multiplayer.is_server():
		return
	if multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_catch(peer_id, target_id)


func _resolve_catch(chaser_id: int, target_id: int) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	var chaser: Player = players.get(chaser_id)
	var target: Player = players.get(target_id)
	if chaser == null or target == null or not is_instance_valid(chaser) or not is_instance_valid(target):
		return
	if chaser.role != Config.Role.CHASER or target.role != Config.Role.RUNNER or not target.alive:
		return
	if _auth_hidden(target_id):
		return
	if _catch_lock.has(target_id):
		return
	var now := Time.get_ticks_msec() / 1000.0
	if now - float(_server_catch_cd.get(chaser_id, -99.0)) < CATCH_SERVER_CD:
		return
	var a := _auth_position(chaser_id)
	var b := _auth_position(target_id)
	if a.distance_to(b) > CATCH_RANGE:
		return
	if not _server_los(a, b):
		return
	_server_catch_cd[chaser_id] = now
	_catch_lock[target_id] = now
	_stats[chaser_id]["catches"] = int(_stats[chaser_id]["catches"]) + 1
	_stats[target_id]["caught"] = int(_stats[target_id]["caught"]) + 1
	var swap := _rng.randf() < swap_chance
	target.play_caught(swap)
	chaser.play_caught(false)
	if swap:
		_apply_role(target_id, Config.Role.CHASER)
		target.catch_cd = 2.2
		_server_catch_cd[target_id] = now
		_broadcast_event("%s caught %s — ROLE SWAP!" % [chaser.display_name, target.display_name], Color(1.0, 0.62, 0.2))
		Audio.play_sfx("swap_chime", -3.0, 0.85)
		_flash_rpc.rpc(target_id, Color(1.0, 0.7, 0.2))
	else:
		_apply_role(target_id, Config.Role.HELPER)
		_broadcast_event("%s caught %s — now a Helper" % [chaser.display_name, target.display_name], Config.ROLE_COLORS[2])
		Audio.play_sfx("catch_keys", -3.0, 1.0)
		_flash_rpc.rpc(target_id, Config.ROLE_COLORS[2])
	_flash_rpc.rpc(chaser_id, Color(1.0, 0.4, 0.3))
	get_tree().create_timer(0.35).timeout.connect(func():
		_catch_lock.erase(target_id)
	)
	if Net.is_online():
		_catch_event_rpc.rpc(chaser_id, target_id, swap)
	_check_win()


@rpc("authority", "call_remote", "reliable")
func _catch_event_rpc(chaser_id: int, target_id: int, swap: bool) -> void:
	var chaser: Player = players.get(chaser_id)
	var target: Player = players.get(target_id)
	if chaser and is_instance_valid(chaser):
		chaser.play_caught(false)
	if target and is_instance_valid(target):
		target.play_caught(swap)


@rpc("authority", "call_remote", "reliable")
func _flash_rpc(id: int, color: Color) -> void:
	var p: Player = players.get(id)
	if p and is_instance_valid(p):
		p._shake_time = 0.45
	if id == local_peer_id:
		match_event.emit("", color)


func _check_win() -> void:
	if state != Config.MatchState.ACTIVE:
		return
	if active_runners().is_empty():
		_end_match("chasers")


# =============================================================== RPC: hiding

func request_hide(spot_id: String, peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_hide_rpc.rpc_id(1, spot_id, peer_id)
		return
	_resolve_hide(spot_id, peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_hide_rpc(spot_id: String, peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_hide(spot_id, peer_id)


func _resolve_hide(spot_id: String, peer_id: int) -> void:
	if state != Config.MatchState.ACTIVE or map == null:
		return
	var p: Player = players.get(peer_id)
	var spot: HidingSpot = map.hiding_spots.get(spot_id)
	if p == null or spot == null or not is_instance_valid(spot):
		return
	if p.role != Config.Role.RUNNER or p.hidden or spot.occupant_id != 0:
		return
	if _auth_position(peer_id).distance_to(spot.exit_position) > 3.4:
		return
	spot.set_occupant(peer_id)
	p.set_hidden_state(true, spot)
	if Net.is_online():
		_hide_state_rpc.rpc(spot_id, peer_id, true)
	_broadcast_event("%s is hiding" % p.display_name, Config.ROLE_COLORS[0].darkened(0.1))


func request_leave_hide(peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_leave_rpc.rpc_id(1, peer_id)
		return
	_resolve_leave(peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_leave_rpc(peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_leave(peer_id)


func _resolve_leave(peer_id: int) -> void:
	var p: Player = players.get(peer_id)
	if p == null or not p.hidden:
		return
	var spot: HidingSpot = p.hiding_spot
	if spot and is_instance_valid(spot):
		spot.set_occupant(0)
		if Net.is_online():
			_hide_state_rpc.rpc(spot.spot_id, 0, false)
	p.set_hidden_state(false)
	if Net.is_online():
		_hide_state_rpc.rpc("", peer_id, false)


@rpc("authority", "call_remote", "reliable")
func _hide_state_rpc(spot_id: String, peer_id: int, inside: bool) -> void:
	if map == null:
		return
	var spot: HidingSpot = map.hiding_spots.get(spot_id)
	if spot and is_instance_valid(spot):
		spot.set_occupant(peer_id if inside else 0)
	var p: Player = players.get(peer_id)
	if p == null or not is_instance_valid(p):
		return
	if inside:
		p.set_hidden_state(true, spot)
	else:
		p.set_hidden_state(false)


func request_search(spot_id: String, peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_search_rpc.rpc_id(1, spot_id, peer_id)
		return
	_resolve_search(spot_id, peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_search_rpc(spot_id: String, peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_search(spot_id, peer_id)


func _resolve_search(spot_id: String, peer_id: int) -> void:
	if state != Config.MatchState.ACTIVE or map == null:
		return
	var p: Player = players.get(peer_id)
	var spot: HidingSpot = map.hiding_spots.get(spot_id)
	if p == null or spot == null or p.role != Config.Role.CHASER:
		return
	if _auth_position(peer_id).distance_to(spot.exit_position) > 3.8:
		return
	if spot.occupant_id != 0:
		var victim: Player = players.get(spot.occupant_id)
		spot.set_occupant(0)
		if victim and is_instance_valid(victim):
			victim.set_hidden_state(false)
			victim.apply_stun(0.85, spot.global_position, 0.0)
			_broadcast_event("%s found %s!" % [p.display_name, victim.display_name], Color(1.0, 0.55, 0.3))
			Audio.play_sfx("gasp", -3.0, 1.0)
			if Net.is_online():
				_hide_state_rpc.rpc(spot_id, victim.peer_id, false)
				_search_result_rpc.rpc(peer_id, true)
		else:
			if Net.is_online():
				_search_result_rpc.rpc(peer_id, false)
	else:
		if Net.is_online():
			_search_result_rpc.rpc(peer_id, false)
		Audio.play_3d("creak", spot.global_position, -8.0, 12.0)


@rpc("authority", "call_remote", "reliable")
func _search_result_rpc(chaser_id: int, found: bool) -> void:
	if chaser_id == local_peer_id:
		match_event.emit("FOUND SOMEONE!" if found else "Empty...", Color(1.0, 0.55, 0.3) if found else Color(0.7, 0.7, 0.75))


# =============================================================== RPC: abilities

func request_sense(peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_sense_rpc.rpc_id(1, peer_id)
		return
	_resolve_sense(peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_sense_rpc(peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_sense(peer_id)


func _resolve_sense(peer_id: int) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	var chaser: Player = players.get(peer_id)
	if chaser == null or chaser.role != Config.Role.CHASER:
		return
	var origin := _auth_position(peer_id)
	var ids: Array = []
	for p in players.values():
		if p.role != Config.Role.RUNNER or not p.alive or p.hidden:
			continue
		if origin.distance_to(_auth_position(p.peer_id)) <= 16.0:
			ids.append(p.peer_id)
	if Net.is_online():
		_sense_result_rpc.rpc(peer_id, ids)
	if peer_id == local_peer_id:
		_apply_sense(ids)
	Audio.play_sfx("sparkle", -4.0, 1.15)
	if ids.is_empty():
		_broadcast_event("%s senses nothing nearby." % chaser.display_name, Color(0.7, 0.75, 0.85))


@rpc("authority", "call_remote", "reliable")
func _sense_result_rpc(chaser_id: int, ids: Array) -> void:
	if chaser_id != local_peer_id:
		return
	_apply_sense(ids)


func _apply_sense(ids: Array) -> void:
	for id in ids:
		var p: Player = players.get(id)
		if p and is_instance_valid(p):
			p.set_sense_marker(true, 3.2)
	sense_ping.emit(ids)
	if ids.is_empty():
		match_event.emit("No runners nearby...", Color(0.7, 0.75, 0.85))
	else:
		match_event.emit("%d runner%s nearby!" % [ids.size(), "" if ids.size() == 1 else "s"], Color(1.0, 0.55, 0.35))


func request_hint(peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_hint_rpc.rpc_id(1, peer_id)
		return
	_resolve_hint(peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_hint_rpc(peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_hint(peer_id)


func _resolve_hint(peer_id: int) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	var helper: Player = players.get(peer_id)
	if helper == null or helper.role != Config.Role.HELPER:
		return
	var chasers := active_chasers()
	if chasers.is_empty():
		return
	var chaser: Player = chasers[0]
	var best: Player = null
	var best_d := 1e9
	for p in players.values():
		if p.role != Config.Role.RUNNER or not p.alive:
			continue
		var d := _auth_position(chaser.peer_id).distance_to(_auth_position(p.peer_id))
		if d < best_d:
			best_d = d
			best = p
	if best == null:
		return
	var dir := (_auth_position(best.peer_id) - _auth_position(chaser.peer_id))
	dir.y = 0.0
	if dir.length() < 0.01:
		dir = Vector3.FORWARD
	dir = dir.normalized()
	var dist_text := "very close" if best_d < 8.0 else ("nearby" if best_d < 20.0 else "across the house")
	_hint_by_chaser[chaser.peer_id] = Time.get_ticks_msec()
	if Net.is_online():
		_hint_rpc.rpc(chaser.peer_id, dir, dist_text, helper.display_name)
	if chaser.peer_id == local_peer_id:
		hint_ping.emit(dir, dist_text)
		match_event.emit("Helper hint: %s — %s" % [dist_text, helper.display_name], Config.ROLE_COLORS[2])
	_broadcast_event("%s sent a hint to %s" % [helper.display_name, chaser.display_name], Config.ROLE_COLORS[2].darkened(0.15))


@rpc("authority", "call_remote", "reliable")
func _hint_rpc(chaser_id: int, dir: Vector3, dist_text: String, helper_name: String) -> void:
	if chaser_id != local_peer_id:
		return
	hint_ping.emit(dir, dist_text)
	match_event.emit("Helper hint: %s — %s" % [dist_text, helper_name], Config.ROLE_COLORS[2])


func broadcast_emote(peer_id: int, emote_name: String) -> void:
	if not is_authority():
		if Net.is_online():
			_emote_request_rpc.rpc_id(1, peer_id, emote_name)
		return
	_do_emote(peer_id, emote_name)
	if Net.is_online():
		_emote_rpc.rpc(peer_id, emote_name)


@rpc("any_peer", "call_remote", "reliable")
func _emote_request_rpc(peer_id: int, emote_name: String) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_do_emote(peer_id, emote_name)
	_emote_rpc.rpc(peer_id, emote_name)


@rpc("authority", "call_remote", "reliable")
func _emote_rpc(peer_id: int, emote_name: String) -> void:
	_do_emote(peer_id, emote_name)


func _do_emote(peer_id: int, emote_name: String) -> void:
	var p: Player = players.get(peer_id)
	if p and is_instance_valid(p):
		p.play_emote_visual(emote_name)


# =============================================================== RPC: props

func request_pickup(pickup_id: String, peer_id: int) -> void:
	if not is_authority():
		if Net.is_online():
			_request_pickup_rpc.rpc_id(1, pickup_id, peer_id)
		return
	_resolve_pickup(pickup_id, peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_pickup_rpc(pickup_id: String, peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_pickup(pickup_id, peer_id)


func _resolve_pickup(pickup_id: String, peer_id: int) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	var p: Player = players.get(peer_id)
	var pk: PropPickup = _pickups_by_id.get(pickup_id)
	if p == null or pk == null or not is_instance_valid(pk):
		return
	if p.role == Config.Role.HELPER or not p.held_prop.is_empty() or pk.is_held:
		return
	if _auth_position(peer_id).distance_to(pk.global_position) > 3.2:
		return
	pk.set_held(true)
	p.set_held(pk.kind, pickup_id)
	if Net.is_online():
		_pickup_state_rpc.rpc(pickup_id, peer_id, true)
	Audio.play_sfx("click", -8.0, 1.25)
	_broadcast_event("%s grabbed the %s" % [p.display_name, pk.kind], Color(0.9, 0.85, 0.7))


@rpc("authority", "call_remote", "reliable")
func _pickup_state_rpc(pickup_id: String, peer_id: int, held: bool) -> void:
	var pk: PropPickup = _pickups_by_id.get(pickup_id)
	if pk and is_instance_valid(pk):
		pk.set_held(held)
	var p: Player = players.get(peer_id)
	if p and is_instance_valid(p):
		if held and pk:
			p.set_held(pk.kind, pickup_id)
		else:
			p.clear_held()


func request_throw(peer_id: int, kind: String, origin: Vector3, dir: Vector3) -> void:
	if not is_authority():
		if Net.is_online():
			_request_throw_rpc.rpc_id(1, peer_id, kind, origin, dir)
		return
	_resolve_throw(peer_id, kind, origin, dir)


@rpc("any_peer", "call_remote", "reliable")
func _request_throw_rpc(peer_id: int, kind: String, origin: Vector3, dir: Vector3) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_throw(peer_id, kind, origin, dir)


func _resolve_throw(peer_id: int, kind: String, origin: Vector3, dir: Vector3) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	var p: Player = players.get(peer_id)
	if p == null or p.role == Config.Role.HELPER:
		return
	if dir.length() < 0.01:
		dir = -p.visual_root.global_transform.basis.z
	dir = dir.normalized()
	var held_id := p.held_prop_id
	_consume_held(p, held_id)
	if _stats.has(peer_id):
		_stats[peer_id]["props"] = int(_stats[peer_id]["props"]) + 1
	if kind == "banana":
		_spawn_trap_at(origin + dir * 2.2 + Vector3(0, -1.0, 0), "banana")
		Audio.play_sfx("throw_swing", -8.0, 1.1)
	elif kind == "bottle":
		_spawn_trap_at(origin + dir * 2.6 + Vector3(0, -1.0, 0), "puddle")
		Audio.play_sfx("splash", -4.0, 1.0)
	else:
		_spawn_projectile(kind, peer_id, origin + dir * 0.6, dir, 15.0 if kind == "pan" else 18.0)
		Audio.play_sfx("throw_swing", -7.0, 1.0)
	if Net.is_online():
		_drop_visual_rpc.rpc(peer_id)
	_broadcast_event("%s threw a %s" % [p.display_name, kind], Color(0.95, 0.8, 0.55))


func request_drop(peer_id: int, kind: String, pos: Vector3) -> void:
	if not is_authority():
		if Net.is_online():
			_request_drop_rpc.rpc_id(1, peer_id, kind, pos)
		return
	_resolve_drop(peer_id, kind, pos)


@rpc("any_peer", "call_remote", "reliable")
func _request_drop_rpc(peer_id: int, kind: String, pos: Vector3) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_drop(peer_id, kind, pos)


func _resolve_drop(peer_id: int, kind: String, pos: Vector3) -> void:
	var p: Player = players.get(peer_id)
	if p == null:
		return
	var held_id := p.held_prop_id
	_consume_held(p, held_id, false)
	if kind == "banana":
		_spawn_trap_at(pos + Vector3(0, -0.3, 0), "banana")
	elif kind == "bottle":
		_spawn_trap_at(pos + Vector3(0, -0.3, 0), "puddle")
	else:
		_return_pickup(held_id, pos)
	if Net.is_online():
		_drop_visual_rpc.rpc(peer_id)


@rpc("authority", "call_remote", "reliable")
func _drop_visual_rpc(peer_id: int) -> void:
	var p: Player = players.get(peer_id)
	if p and is_instance_valid(p):
		p.clear_held()


func _consume_held(p: Player, held_id: String, schedule: bool = true) -> void:
	p.clear_held()
	if held_id.is_empty():
		return
	var pk: PropPickup = _pickups_by_id.get(held_id)
	if pk and is_instance_valid(pk):
		pk.set_held(true)
		pk.visible = false
		if schedule:
			_schedule_pickup_respawn(held_id, pk.home_position, 10.0)


func _schedule_pickup_respawn(pickup_id: String, pos: Vector3, delay: float) -> void:
	if _pickup_respawn.has(pickup_id):
		return
	_pickup_respawn[pickup_id] = true
	get_tree().create_timer(delay).timeout.connect(func():
		_pickup_respawn.erase(pickup_id)
		_return_pickup(pickup_id, pos)
	)


func _return_pickup(pickup_id: String, pos: Vector3) -> void:
	var pk: PropPickup = _pickups_by_id.get(pickup_id)
	if pk == null or not is_instance_valid(pk):
		return
	pk.global_position = pos + Vector3(0, 0.05, 0)
	pk.set_held(false)
	if Net.is_online():
		_pickup_respawn_rpc.rpc(pickup_id, pos)


@rpc("authority", "call_remote", "reliable")
func _pickup_respawn_rpc(pickup_id: String, pos: Vector3) -> void:
	var pk: PropPickup = _pickups_by_id.get(pickup_id)
	if pk and is_instance_valid(pk):
		pk.global_position = pos + Vector3(0, 0.05, 0)
		pk.set_held(false)


func _spawn_projectile(kind: String, owner_id: int, origin: Vector3, dir: Vector3, speed: float) -> void:
	var id := "proj_%d_%d" % [Time.get_ticks_msec(), _rng.randi_range(0, 999)]
	var proj := ThrownProp.new()
	proj.position = origin
	world_root.add_child(proj)
	proj.setup(id, kind, owner_id, dir, speed)
	_projectiles[id] = proj
	if Net.is_online():
		_spawn_projectile_rpc.rpc(id, kind, owner_id, origin, dir, speed)


@rpc("authority", "call_remote", "reliable")
func _spawn_projectile_rpc(id: String, kind: String, owner_id: int, origin: Vector3, dir: Vector3, speed: float) -> void:
	var proj := ThrownProp.new()
	proj.position = origin
	world_root.add_child(proj)
	proj.setup(id, kind, owner_id, dir, speed)
	_projectiles[id] = proj


func sync_projectile(id: String, pos: Vector3, rot: Vector3) -> void:
	if Net.is_online():
		_sync_projectile_rpc.rpc(id, pos, rot)


@rpc("authority", "call_remote", "unreliable_ordered")
func _sync_projectile_rpc(id: String, pos: Vector3, rot: Vector3) -> void:
	var proj: ThrownProp = _projectiles.get(id)
	if proj and is_instance_valid(proj):
		proj.global_position = pos
		proj.global_rotation = rot


func despawn_projectile(id: String) -> void:
	var proj: ThrownProp = _projectiles.get(id)
	if proj and is_instance_valid(proj):
		proj.queue_free()
	_projectiles.erase(id)
	if Net.is_online():
		_despawn_projectile_rpc.rpc(id)


@rpc("authority", "call_remote", "reliable")
func _despawn_projectile_rpc(id: String) -> void:
	var proj: ThrownProp = _projectiles.get(id)
	if proj and is_instance_valid(proj):
		proj.queue_free()
	_projectiles.erase(id)


func _spawn_trap_at(pos: Vector3, kind: String) -> void:
	var id := "trap_%d_%d" % [Time.get_ticks_msec(), _rng.randi_range(0, 999)]
	var trap := SlipTrap.new()
	trap.position = Vector3(pos.x, 0.03, pos.z)
	world_root.add_child(trap)
	trap.setup(id, kind)
	_traps[id] = trap
	if Net.is_online():
		_spawn_trap_rpc.rpc(id, kind, pos)


@rpc("authority", "call_remote", "reliable")
func _spawn_trap_rpc(id: String, kind: String, pos: Vector3) -> void:
	var trap := SlipTrap.new()
	trap.position = Vector3(pos.x, 0.03, pos.z)
	world_root.add_child(trap)
	trap.setup(id, kind)
	_traps[id] = trap


func remove_trap(id: String) -> void:
	var trap: SlipTrap = _traps.get(id)
	if trap and is_instance_valid(trap):
		trap.queue_free()
	_traps.erase(id)
	if Net.is_online():
		_remove_trap_rpc.rpc(id)


@rpc("authority", "call_remote", "reliable")
func _remove_trap_rpc(id: String) -> void:
	var trap: SlipTrap = _traps.get(id)
	if trap and is_instance_valid(trap):
		trap.queue_free()
	_traps.erase(id)


func despawn_noisy(id: String) -> void:
	if map:
		map.pickups.erase(id)


# =============================================================== RPC: doors and lights

func request_door_action(door_id: String, action: String) -> void:
	if not is_authority():
		if Net.is_online():
			_request_door_rpc.rpc_id(1, door_id, action, local_peer_id)
		return
	_resolve_door(door_id, action, local_peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_door_rpc(door_id: String, action: String, peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_door(door_id, action, peer_id)

func _resolve_door(door_id: String, action: String, peer_id: int) -> void:
	if map == null or not map.doors.has(door_id):
		return
	var door: GameDoor = map.doors[door_id]
	if door == null or not is_instance_valid(door):
		return
	var p: Player = players.get(peer_id)
	if p and _auth_position(peer_id).distance_to(door.global_position) > 4.0:
		return
	var out := action
	if action == "force":
		if p == null or p.role != Config.Role.CHASER:
			return
		out = "force_open"
		_broadcast_event("%s forced a door open!" % p.display_name, Color(1.0, 0.5, 0.35))
		if Net.is_online():
			_door_force_rpc.rpc(door_id)
	elif action == "close_lock":
		if p == null or p.role != Config.Role.RUNNER:
			return
		_broadcast_event("%s locked a door" % p.display_name, Config.ROLE_COLORS[0].darkened(0.1))
	door.apply_state(out)
	if Net.is_online():
		_door_state_rpc.rpc(door_id, out)


@rpc("authority", "call_remote", "reliable")
func _door_state_rpc(door_id: String, out: String) -> void:
	if map == null:
		return
	var door: GameDoor = map.doors.get(door_id)
	if door and is_instance_valid(door):
		door.apply_state(out)


@rpc("authority", "call_remote", "reliable")
func _door_force_rpc(door_id: String) -> void:
	if map == null:
		return
	var door: GameDoor = map.doors.get(door_id)
	if door and is_instance_valid(door):
		door.begin_force_visual()
		Audio.play_3d("wood_impact", door.global_position, -3.0, 18.0)


func request_light_toggle(switch_id: String) -> void:
	if not is_authority():
		if Net.is_online():
			_request_light_rpc.rpc_id(1, switch_id, local_peer_id)
		return
	_resolve_light(switch_id, local_peer_id)


@rpc("any_peer", "call_remote", "reliable")
func _request_light_rpc(switch_id: String, peer_id: int) -> void:
	if not multiplayer.is_server() or multiplayer.get_remote_sender_id() != peer_id:
		return
	_resolve_light(switch_id, peer_id)


func _resolve_light(switch_id: String, peer_id: int) -> void:
	if map == null or not map.light_switches.has(switch_id):
		return
	var sw: LightSwitch = map.light_switches[switch_id]
	if sw == null or not is_instance_valid(sw):
		return
	var p: Player = players.get(peer_id)
	if p and _auth_position(peer_id).distance_to(sw.global_position) > 3.2:
		return
	sw.set_on(not sw.is_on)
	_apply_room_lights(sw.room_id, sw.is_on)
	if Net.is_online():
		_light_state_rpc.rpc(sw.room_id, sw.is_on)
	if p:
		_broadcast_event("%s turned the lights %s" % [p.display_name, "on" if sw.is_on else "off"], Color(0.85, 0.82, 0.6))


@rpc("authority", "call_remote", "reliable")
func _light_state_rpc(room_id: String, on: bool) -> void:
	if map == null:
		return
	for sw in map.light_switches.values():
		if sw.room_id == room_id:
			sw.set_on(on)
	_apply_room_lights(room_id, on)


func _apply_room_lights(room_id: String, on: bool) -> void:
	if map == null or not map.room_lights.has(room_id):
		return
	for entry in map.room_lights[room_id]:
		var light: OmniLight3D = entry["light"]
		if light and is_instance_valid(light):
			light.light_energy = float(entry.get("base", 1.0)) if on else 0.0
		var bulb: Node3D = entry.get("bulb")
		if bulb and is_instance_valid(bulb) and bulb is MeshInstance3D:
			bulb.visible = on


# =============================================================== noise and events

func emit_noise(pos: Vector3, radius: float, room_id: String, text: String) -> void:
	if not is_authority():
		return
	_last_noise = {"pos": pos, "time": Time.get_ticks_msec() / 1000.0, "radius": radius, "room": room_id}
	if Net.is_online():
		_noise_rpc.rpc(pos, text)
	match_event.emit(text, Color(1.0, 0.75, 0.4))


@rpc("authority", "call_remote", "reliable")
func _noise_rpc(pos: Vector3, text: String) -> void:
	_last_noise = {"pos": pos, "time": Time.get_ticks_msec() / 1000.0, "radius": 15.0, "room": ""}
	match_event.emit(text, Color(1.0, 0.75, 0.4))


func last_noise() -> Dictionary:
	return _last_noise


func notify_event(text: String, color: Color) -> void:
	if text.is_empty():
		return
	match_event.emit(text, color)


func _broadcast_event(text: String, color: Color) -> void:
	match_event.emit(text, color)
	if Net.is_online():
		_event_rpc.rpc(text, color)


@rpc("authority", "call_remote", "reliable")
func _event_rpc(text: String, color: Color) -> void:
	match_event.emit(text, color)


# =============================================================== results

func _end_match(winner: String) -> void:
	if state != Config.MatchState.ACTIVE:
		return
	state = Config.MatchState.RESOLVING
	state_changed.emit(state)
	_set_state_rpc.rpc(Config.MatchState.RESOLVING)
	_broadcast_event("Runners win!" if winner == "runners" else "Chasers win!", Config.ROLE_COLORS[0] if winner == "runners" else Config.ROLE_COLORS[1])
	Audio.play_sfx("win" if winner == "runners" else "lose", -3.0, 1.0)
	for p in players.values():
		if is_instance_valid(p):
			p.set_frozen(true)
	var result := _build_results(winner)
	get_tree().create_timer(1.4).timeout.connect(func():
		if state == Config.MatchState.RESOLVING:
			state = Config.MatchState.RESULTS
			state_changed.emit(state)
			match_ended.emit(result)
			if Net.is_online():
				_results_rpc.rpc(result)
	)


func _build_results(winner: String) -> Dictionary:
	var rows: Array = []
	var best_catcher := {"name": "—", "value": 0}
	var best_hider := {"name": "—", "value": 0.0}
	var best_clumsy := {"name": "—", "value": 0}
	var best_thrower := {"name": "—", "value": 0}
	for id in _stats.keys():
		var st: Dictionary = _stats[id]
		var role := int(st["role"])
		var catches := int(st["catches"])
		var survived := float(st["survived"])
		var hidden := float(st["hidden_time"])
		var props := int(st["props"])
		var slips := int(st["slips"])
		var won := (winner == "runners" and role == Config.Role.RUNNER) or (winner == "chasers" and role == Config.Role.CHASER)
		var xp := 35 + catches * 30 + int(survived * 0.6) + props * 4
		if won:
			xp += 110
		rows.append({
			"id": id, "name": str(st["name"]), "role": role, "character": str(st["character"]),
			"catches": catches, "caught": int(st["caught"]), "survived": survived,
			"hidden": hidden, "props": props, "slips": slips, "xp": xp,
			"bot": bool(st["bot"]), "won": won,
		})
		if catches > int(best_catcher["value"]):
			best_catcher = {"name": str(st["name"]), "value": catches}
		if hidden > float(best_hider["value"]):
			best_hider = {"name": str(st["name"]), "value": hidden}
		if slips > int(best_clumsy["value"]):
			best_clumsy = {"name": str(st["name"]), "value": slips}
		if props > int(best_thrower["value"]):
			best_thrower = {"name": str(st["name"]), "value": props}
	rows.sort_custom(func(a, b): return int(a["xp"]) > int(b["xp"]))
	var highlights: Array = []
	if int(best_catcher["value"]) > 0:
		highlights.append("Most Catches: %s (%d)" % [best_catcher["name"], int(best_catcher["value"])])
	if float(best_hider["value"]) > 1.0:
		highlights.append("Longest Hide: %s (%.1fs)" % [best_hider["name"], float(best_hider["value"])])
	if int(best_thrower["value"]) > 0:
		highlights.append("Prop Chucker: %s (%d thrown)" % [best_thrower["name"], int(best_thrower["value"])])
	if int(best_clumsy["value"]) > 0:
		highlights.append("Most Clumsy: %s (%d slips)" % [best_clumsy["name"], int(best_clumsy["value"])])
	if highlights.is_empty():
		highlights.append("A perfectly sensible round. Suspicious.")
	var local_row: Dictionary = {}
	for r in rows:
		if int(r["id"]) == local_peer_id:
			local_row = r
	if not local_row.is_empty():
		Settings.add_match_result(int(local_row["xp"]))
	return {
		"winner": winner,
		"map": map_id,
		"map_name": Config.map_data(map_id)["name"],
		"time_left": time_left,
		"rows": rows,
		"highlights": highlights,
		"local_xp": int(local_row.get("xp", 0)),
		"local_won": bool(local_row.get("won", false)),
	}


# =============================================================== disconnect

func _on_peer_left(id: int) -> void:
	if not is_authority() or state == Config.MatchState.MENU:
		return
	if players.has(id):
		var p: Player = players[id]
		if p and is_instance_valid(p):
			if p.hidden and p.hiding_spot and is_instance_valid(p.hiding_spot):
				p.hiding_spot.set_occupant(0)
			p.queue_free()
		players.erase(id)
		_net_positions.erase(id)
		_bots.erase(id)
		_stats.erase(id)
		if Net.is_online():
			_remove_player_rpc.rpc(id)
		_broadcast_event("A player disconnected.", Color(0.7, 0.72, 0.78))
		if state == Config.MatchState.ACTIVE:
			if active_runners().is_empty():
				_end_match("chasers")
			elif active_chasers().is_empty() and not active_runners().is_empty():
				var runners := active_runners()
				var promoted: Player = runners[_rng.randi_range(0, runners.size() - 1)]
				_apply_role(promoted.peer_id, Config.Role.CHASER)
				_broadcast_event("%s is now the Chaser!" % promoted.display_name, Config.ROLE_COLORS[1])


@rpc("authority", "call_remote", "reliable")
func _remove_player_rpc(id: int) -> void:
	var p: Player = players.get(id)
	if p and is_instance_valid(p):
		p.queue_free()
	players.erase(id)
	_net_positions.erase(id)
	_bots.erase(id)
	_stats.erase(id)


func _on_server_disconnected() -> void:
	if state == Config.MatchState.MENU:
		return
	paused = false
	_cleanup_world()
	state = Config.MatchState.MENU
	state_changed.emit(state)
	match_event.emit("Host disconnected.", Color(1.0, 0.45, 0.4))
	roster_changed.emit()


func _on_connection_failed(reason: String) -> void:
	match_event.emit(reason, Color(1.0, 0.45, 0.4))


# =============================================================== cleanup

func _clear_players() -> void:
	for p in players.values():
		if is_instance_valid(p):
			p.queue_free()
	players.clear()
	for b in _bots.values():
		if is_instance_valid(b):
			b.queue_free()
	_bots.clear()


func _cleanup_world() -> void:
	_clear_players()
	_projectiles.clear()
	_traps.clear()
	_pickups_by_id.clear()
	_pickup_respawn.clear()
	_net_positions.clear()
	_stats.clear()
	_server_catch_cd.clear()
	_catch_lock.clear()
	if map and is_instance_valid(map):
		map.queue_free()
	map = null
	if world_root:
		for child in world_root.get_children():
			if not child.is_queued_for_deletion():
				child.queue_free()


func _shuffle(arr: Array) -> void:
	for i in range(arr.size() - 1, 0, -1):
		var j := _rng.randi_range(0, i)
		var tmp = arr[i]
		arr[i] = arr[j]
		arr[j] = tmp
