class_name BotBrain
extends Node
## Server-side AI. Bots use the exact same Player action API as humans.

var player: Player
var game: Node
var map: MapBuilder

var _think_accum := 0.0
var _path := PackedVector3Array()
var _path_index := 0
var _repath_accum := 0.0
var _target_pos := Vector3.ZERO
var _wander_target := Vector3.ZERO
var _stuck_accum := 0.0
var _last_pos := Vector3.ZERO
var _search_accum := 0.0
var _sense_accum := 0.0
var _hide_cooldown := 0.0
var _leave_cooldown := 0.0
var _prop_accum := 0.0
var _aim_target: Player = null
var _rng := RandomNumberGenerator.new()

const VIEW_RANGE := 15.0
const CHASE_SPRINT_RANGE := 11.0
const FLEE_RANGE := 13.0
const HIDE_RANGE := 2.9


func setup(p: Player, g: Node, m: MapBuilder) -> void:
	player = p
	game = g
	map = m
	_rng.randomize()
	_last_pos = p.global_position
	_wander_target = p.global_position
	set_physics_process(true)


func _physics_process(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		queue_free()
		return
	if game == null or game.state != Config.MatchState.ACTIVE or game.paused:
		player.bot_move = Vector3.ZERO
		player.bot_sprint = false
		player.bot_crouch = false
		return
	if player.role == Config.Role.HELPER:
		_helper_tick(delta)
		return
	_think_accum += delta
	_repath_accum += delta
	_stuck_accum += delta
	_hide_cooldown = maxf(0.0, _hide_cooldown - delta)
	_leave_cooldown = maxf(0.0, _leave_cooldown - delta)
	if _think_accum >= 0.18:
		_think_accum = 0.0
		if player.role == Config.Role.CHASER:
			_chaser_think()
		else:
			_runner_think()
	_follow_path(delta)
	_check_stuck()


# ------------------------------------------------------------------ runner

func _runner_think() -> void:
	var threat := _nearest_visible_chaser()
	if threat == null:
		threat = _nearest_chaser_any(FLEE_RANGE)
	if player.hidden:
		player.bot_move = Vector3.ZERO
		player.bot_sprint = false
		player.bot_crouch = true
		if threat and threat.global_position.distance_to(player.global_position) < 4.2 and _leave_cooldown <= 0.0:
			_leave_cooldown = 3.0
			Game.request_leave_hide(player.peer_id)
		return
	if threat:
		_flee_from(threat)
		_try_throw_at(threat)
		return
	# Safe: use props, hide, and wander.
	if not player.held_prop.is_empty():
		_maybe_pickup()
		_maybe_hide()
		_wander()
		return
	_maybe_pickup()
	if _maybe_hide():
		return
	_wander()


func _flee_from(threat: Player) -> void:
	var away := (player.global_position - threat.global_position)
	away.y = 0
	if away.length() < 0.1:
		away = Vector3.FORWARD
	away = away.normalized()
	var dest := player.global_position + away * 9.0
	if map and map.nav and map.nav.ready:
		var rooms: Array = map.nav.rooms()
		var best := dest
		var best_score := -999.0
		for i in 7:
			if rooms.is_empty():
				break
			var room_id: String = rooms[_rng.randi_range(0, rooms.size() - 1)]
			var candidate: Vector3 = map.nav.random_room_point(room_id)
			if candidate == Vector3.ZERO:
				continue
			var score := candidate.distance_to(threat.global_position)
			score -= absf(candidate.distance_to(player.global_position) - 12.0) * 0.35
			if score > best_score:
				best_score = score
				best = candidate
		dest = best
	_set_destination(dest)
	var d := threat.global_position.distance_to(player.global_position)
	player.bot_sprint = d < CHASE_SPRINT_RANGE and player.stamina > 22.0
	player.bot_crouch = false
	if d < 2.6 and player.stamina > 30.0:
		player.bot_sprint = true


# ------------------------------------------------------------------ chaser

func _chaser_think() -> void:
	var target := _nearest_visible_runner()
	if target:
		_aim_target = target
		_target_pos = target.global_position
		var d := player.global_position.distance_to(target.global_position)
		if d < Player.CATCH_RANGE + 0.5:
			player.bot_move = Vector3.ZERO
			player.bot_sprint = false
			player.try_catch()
			return
		_set_destination(target.global_position, 0.6)
		player.bot_sprint = d < CHASE_SPRINT_RANGE and player.stamina > 18.0
		player.bot_crouch = false
		if d < 7.0 and _rng.randf() < 0.06:
			player.use_ability()
		return
	_aim_target = null
	# Search nearby hiding spots if we are close.
	_search_accum += 0.18
	if _search_accum > 1.2:
		_search_accum = 0.0
		_try_search_spot()
	# Investigate noise.
	var noise: Dictionary = game.last_noise()
	if not noise.is_empty():
		var age := Time.get_ticks_msec() / 1000.0 - float(noise.get("time", 0.0))
		if age < 9.0:
			var np: Vector3 = noise.get("pos", Vector3.ZERO)
			if np != Vector3.ZERO:
				_set_destination(np)
				player.bot_sprint = player.stamina > 30.0
				player.bot_crouch = false
				return
	# Sense occasionally.
	_sense_accum += 0.18
	if _sense_accum > 9.0 and player.sense_cd <= 0.0:
		_sense_accum = 0.0
		player.use_ability()
	# Patrol toward rooms that likely contain runners.
	if _path.is_empty() or player.global_position.distance_to(_target_pos) < 1.4:
		var dest := _pick_patrol_point()
		_target_pos = dest
		_set_destination(dest)
	player.bot_sprint = player.stamina > 45.0 and _rng.randf() < 0.5
	player.bot_crouch = false


func _pick_patrol_point() -> Vector3:
	if map == null or map.nav == null or not map.nav.ready:
		return player.global_position + Vector3(_rng.randf_range(-6, 6), 0, _rng.randf_range(-6, 6))
	var rooms: Array = map.nav.rooms()
	if rooms.is_empty():
		return player.global_position
	var candidates: Array = []
	for p in game.players.values():
		if p.role == Config.Role.RUNNER and p.alive and p != player:
			candidates.append(p.global_position)
	if not candidates.is_empty() and _rng.randf() < 0.55:
		var pick: Vector3 = candidates[_rng.randi_range(0, candidates.size() - 1)]
		var room_point: Vector3 = map.nav.nearest_point(pick)
		if room_point != Vector3.ZERO:
			return room_point
	var room_id: String = rooms[_rng.randi_range(0, rooms.size() - 1)]
	var pt: Vector3 = map.nav.random_room_point(room_id)
	return pt if pt != Vector3.ZERO else player.global_position


func _try_search_spot() -> void:
	if map == null or map.hiding_spots.is_empty():
		return
	var best: HidingSpot = null
	var best_d := 2.6
	for spot in map.hiding_spots.values():
		if not is_instance_valid(spot):
			continue
		var d := player.global_position.distance_to(spot.exit_position)
		if d < best_d:
			best_d = d
			best = spot
	if best:
		Game.request_search(best.spot_id, player.peer_id)


# ------------------------------------------------------------------ helper

func _helper_tick(delta: float) -> void:
	var chasers: Array = game.active_chasers()
	var target_pos := player.global_position
	if not chasers.is_empty():
		var chaser: Player = chasers[0]
		target_pos = chaser.global_position + Vector3(0, 2.6, 0)
	var to := target_pos - player.global_position
	if to.length() > 2.0:
		player.bot_move = to.normalized()
	else:
		player.bot_move = Vector3.ZERO
	player.bot_sprint = true
	player.bot_crouch = false
	if player.hint_cd <= 0.0 and not chasers.is_empty():
		player.use_ability()


# ------------------------------------------------------------------ pathing

func _set_destination(dest: Vector3, tolerance: float = 0.9) -> void:
	if map == null or map.nav == null or not map.nav.ready:
		_path = PackedVector3Array([dest])
		_path_index = 0
		return
	if _repath_accum < 0.55 and _path.size() > 0 and dest.distance_to(_target_pos) < 2.0:
		return
	_repath_accum = 0.0
	_target_pos = dest
	_path = map.nav.find_path(player.global_position, dest)
	_path_index = 0
	# Skip a waypoint we are already standing on.
	while _path_index < _path.size() and player.global_position.distance_to(_path[_path_index]) < tolerance:
		_path_index += 1


func _follow_path(_delta: float) -> void:
	if _path.is_empty() or _path_index >= _path.size():
		player.bot_move = Vector3.ZERO
		return
	var wp: Vector3 = _path[_path_index]
	var to := wp - player.global_position
	to.y = 0
	if to.length() < 0.45:
		_path_index += 1
		if _path_index >= _path.size():
			player.bot_move = Vector3.ZERO
		return
	player.bot_move = to.normalized()


func _check_stuck() -> void:
	if _stuck_accum < 1.1:
		return
	_stuck_accum = 0.0
	var moved := player.global_position.distance_to(_last_pos)
	_last_pos = player.global_position
	if moved < 0.25 and player.bot_move.length() > 0.2:
		player.bot_jump = true
		_path.clear()
		_repath_accum = 99.0
		_open_nearby_door()


# ------------------------------------------------------------------ perception

func _nearest_visible_runner() -> Player:
	var best: Player = null
	var best_d := VIEW_RANGE
	for p in game.players.values():
		if p == player or not is_instance_valid(p):
			continue
		if p.role != Config.Role.RUNNER or not p.alive or p.hidden:
			continue
		var d := player.global_position.distance_to(p.global_position)
		if d >= best_d:
			continue
		if not _in_view(p.global_position, d):
			continue
		if not _los(p.global_position):
			continue
		best_d = d
		best = p
	return best


func _nearest_visible_chaser() -> Player:
	var best: Player = null
	var best_d := VIEW_RANGE
	for p in game.players.values():
		if p == player or not is_instance_valid(p):
			continue
		if p.role != Config.Role.CHASER:
			continue
		var d := player.global_position.distance_to(p.global_position)
		if d >= best_d:
			continue
		if not _in_view(p.global_position, d):
			continue
		if not _los(p.global_position):
			continue
		best_d = d
		best = p
	return best


func _nearest_chaser_any(max_dist: float) -> Player:
	var best: Player = null
	var best_d := max_dist
	for p in game.players.values():
		if p == player or not is_instance_valid(p):
			continue
		if p.role != Config.Role.CHASER:
			continue
		var d := player.global_position.distance_to(p.global_position)
		if d < best_d:
			best_d = d
			best = p
	return best


func _in_view(pos: Vector3, d: float) -> bool:
	if d < 3.5:
		return true
	var fwd := -player.visual_root.global_transform.basis.z
	var to := (pos - player.global_position)
	to.y = 0
	if to.length() < 0.1:
		return true
	return fwd.dot(to.normalized()) > -0.1


func _los(pos: Vector3) -> bool:
	var space := player.get_world_3d().direct_space_state
	if space == null:
		return true
	var q := PhysicsRayQueryParameters3D.create(
		player.global_position + Vector3(0, 1.2, 0),
		pos + Vector3(0, 1.2, 0),
		1
	)
	q.exclude = [player.get_rid()]
	return space.intersect_ray(q).is_empty()


# ------------------------------------------------------------------ interactions

func _maybe_pickup() -> void:
	_prop_accum += 0.18
	if _prop_accum < 1.4 or not player.held_prop.is_empty():
		return
	_prop_accum = 0.0
	if map == null:
		return
	var best: PropPickup = null
	var best_d := 2.4
	for pk in map.pickups.values():
		if not is_instance_valid(pk) or pk.is_held:
			continue
		var d := player.global_position.distance_to(pk.global_position)
		if d < best_d:
			best_d = d
			best = pk
	if best:
		Game.request_pickup(best.pickup_id, player.peer_id)


func _maybe_hide() -> bool:
	if _hide_cooldown > 0.0 or map == null or map.hiding_spots.is_empty():
		return false
	var best: HidingSpot = null
	var best_d := HIDE_RANGE
	for spot in map.hiding_spots.values():
		if not is_instance_valid(spot) or spot.occupant_id != 0:
			continue
		var d := player.global_position.distance_to(spot.exit_position)
		if d < best_d:
			best_d = d
			best = spot
	if best and _rng.randf() < 0.75:
		Game.request_hide(best.spot_id, player.peer_id)
		_hide_cooldown = 6.0
		return true
	return false


func _try_throw_at(target: Player) -> void:
	if player.held_prop.is_empty():
		return
	var d := player.global_position.distance_to(target.global_position)
	if d > 12.0:
		return
	var aim := (target.global_position + Vector3(0, 1.1, 0)) - (player.global_position + Vector3(0, 1.3, 0))
	player.bot_aim = aim.normalized()
	player.try_throw()


func _wander() -> void:
	if _path.is_empty() or _path_index >= _path.size():
		var dest := player.global_position
		if map and map.nav and map.nav.ready:
			var rooms: Array = map.nav.rooms()
			if not rooms.is_empty():
				var room_id: String = rooms[_rng.randi_range(0, rooms.size() - 1)]
				dest = map.nav.random_room_point(room_id)
		if dest == Vector3.ZERO:
			dest = player.global_position + Vector3(_rng.randf_range(-5, 5), 0, _rng.randf_range(-5, 5))
		_set_destination(dest)
	player.bot_sprint = false
	player.bot_crouch = _rng.randf() < 0.25


func _open_nearby_door() -> void:
	if map == null or map.doors.is_empty():
		return
	for door in map.doors.values():
		if not is_instance_valid(door) or door.is_open:
			continue
		if player.global_position.distance_to(door.global_position) < 2.6:
			door.interact(player)
			return
