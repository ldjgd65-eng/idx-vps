class_name MapBuilder
extends Node3D
## Builds a complete playable map from MapData: architecture, furniture, props, lights and nav.

const FURN := "res://assets/furniture/"
const REST := "res://assets/restaurant/"
const PROT := "res://assets/prototype/"

var map_id := "suburban"
var data: Dictionary = {}
var cell := 3.2
var wall_height := 3.0
var map_w := 10
var map_h := 8

var rooms_by_id: Dictionary = {}
var room_grid: Array = []
var doors: Dictionary = {}
var hiding_spots: Dictionary = {}
var pickups: Dictionary = {}
var light_switches: Dictionary = {}
var room_lights: Dictionary = {}
var spawn_points: Array[Vector3] = []
var nav: NavGrid
var blockers: Array[AABB] = []
var environment: Environment
var sun: DirectionalLight3D

var _mat_cache: Dictionary = {}
var _scene_cache: Dictionary = {}
var _rng := RandomNumberGenerator.new()
var _prop_counter := 0
var _spot_counter := 0
var _noisy_counter := 0
var _door_keys: Dictionary = {}
var _window_keys: Dictionary = {}


func build(id: String) -> void:
	map_id = id
	data = MapData.get_map(id)
	cell = float(data["cell"])
	wall_height = float(data["wall_height"])
	map_w = int(data["width"])
	map_h = int(data["height"])
	_rng.seed = hash(id)
	rooms_by_id.clear()
	room_grid.clear()
	doors.clear()
	hiding_spots.clear()
	pickups.clear()
	light_switches.clear()
	room_lights.clear()
	spawn_points.clear()
	blockers.clear()
	_door_keys.clear()
	_window_keys.clear()
	for d in data["doors"]:
		_door_keys[_edge_key(d["x"], d["z"], d["dir"])] = d
	for w in data["windows"]:
		_window_keys[_edge_key(w["x"], w["z"], w["dir"])] = w
	_make_room_grid()
	_setup_environment()
	_build_floors_and_ceilings()
	_build_lights()
	_build_walls()
	_build_doors_and_windows()
	_furnish_all_rooms()
	await get_tree().physics_frame
	await get_tree().physics_frame
	_build_hiding_spots()
	_build_light_switches()
	_build_pickups()
	_build_noisy_props()
	await get_tree().physics_frame
	await get_tree().physics_frame
	_build_nav()
	_build_spawn_points()
	print("MAP_BUILD_DONE ", id, " blockers=", blockers.size(), " spots=", hiding_spots.size())


# ---------------------------------------------------------------- environment

func _setup_environment() -> void:
	environment = Environment.new()
	environment.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = data["sky_top"]
	sky_mat.sky_horizon_color = data["sky_horizon"]
	sky_mat.ground_bottom_color = data["sky_horizon"].darkened(0.45)
	sky_mat.ground_horizon_color = data["sky_horizon"].darkened(0.2)
	sky_mat.sun_angle_max = 18.0
	sky_mat.sky_energy_multiplier = 0.9
	sky.sky_material = sky_mat
	environment.sky = sky
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = data["ambient"]
	environment.ambient_light_energy = float(data["ambient_energy"])
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.fog_enabled = true
	environment.fog_light_color = data["fog"]
	environment.fog_density = float(data["fog_density"])
	environment.fog_sky_affect = 0.15
	environment.glow_enabled = false
	var we := WorldEnvironment.new()
	we.environment = environment
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.light_color = data["sun_color"]
	sun.light_energy = float(data["sun_energy"])
	sun.rotation_degrees = Vector3(-58, -38, 0)
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 55.0
	sun.directional_shadow_mode = DirectionalLight3D.SHADOW_PARALLEL_4_SPLITS
	add_child(sun)

	# Exterior ground and a few trees, visible through windows.
	var ground_size := Vector3(map_w * cell + 42.0, 0.2, map_h * cell + 42.0)
	var ground_mat := _simple_mat(Color(0.28, 0.42, 0.24), 0.95)
	_box(ground_size, Vector3(map_w * cell * 0.5, -0.32, map_h * cell * 0.5), ground_mat, true)
	for i in 10:
		var tx := _rng.randf_range(-12.0, map_w * cell + 12.0)
		var tz := _rng.randf_range(-12.0, map_h * cell + 12.0)
		if tx > -2 and tx < map_w * cell + 2 and tz > -2 and tz < map_h * cell + 2:
			continue
		_tree(Vector3(tx, -0.2, tz), _rng.randf_range(0.8, 1.5))


func _tree(pos: Vector3, s: float) -> void:
	var trunk_mat := _simple_mat(Color(0.32, 0.22, 0.14), 0.9)
	var leaf_mat := _simple_mat(Color(0.18, 0.36, 0.2), 0.9)
	_box(Vector3(0.35, 2.2, 0.35) * s, pos + Vector3(0, 1.1 * s, 0), trunk_mat, false)
	var cone := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 1.5
	cm.height = 3.4
	cm.radial_segments = 7
	cone.mesh = cm
	cone.material_override = leaf_mat
	cone.position = pos + Vector3(0, 3.0 * s, 0)
	cone.scale = Vector3.ONE * s
	add_child(cone)


# ---------------------------------------------------------------- structure

func _make_room_grid() -> void:
	room_grid.resize(map_w * map_h)
	room_grid.fill("")
	for r in data["rooms"]:
		rooms_by_id[r["id"]] = r
		for z in range(r["z"], r["z"] + r["h"]):
			for x in range(r["x"], r["x"] + r["w"]):
				if x >= 0 and z >= 0 and x < map_w and z < map_h:
					room_grid[z * map_w + x] = r["id"]


func _room_at_cell(x: int, z: int) -> String:
	if x < 0 or z < 0 or x >= map_w or z >= map_h:
		return ""
	return room_grid[z * map_w + x]


func _build_floors_and_ceilings() -> void:
	var baseboard_mat := _simple_mat(Color(0.24, 0.18, 0.14), 0.8)
	for r in data["rooms"]:
		var w: float = r["w"] * cell
		var h: float = r["h"] * cell
		var cx: float = (r["x"] + r["w"] * 0.5) * cell
		var cz: float = (r["z"] + r["h"] * 0.5) * cell
		var floor_mat := _floor_mat(r["floor"], w, h)
		_box(Vector3(w, 0.2, h), Vector3(cx, -0.1, cz), floor_mat, true)
		var ceil_mat := _wall_mat(data["wall_tint"].darkened(0.06), true)
		_box(Vector3(w, 0.18, h), Vector3(cx, wall_height + 0.09, cz), ceil_mat, true)
		# Baseboards
		var bh := 0.12
		_box(Vector3(w - 0.1, bh, 0.07), Vector3(cx, bh * 0.5, cz - h * 0.5 + 0.06), baseboard_mat, false)
		_box(Vector3(w - 0.1, bh, 0.07), Vector3(cx, bh * 0.5, cz + h * 0.5 - 0.06), baseboard_mat, false)
		_box(Vector3(0.07, bh, h - 0.1), Vector3(cx - w * 0.5 + 0.06, bh * 0.5, cz), baseboard_mat, false)
		_box(Vector3(0.07, bh, h - 0.1), Vector3(cx + w * 0.5 - 0.06, bh * 0.5, cz), baseboard_mat, false)


func _build_lights() -> void:
	for r in data["rooms"]:
		var w: float = r["w"] * cell
		var h: float = r["h"] * cell
		var area := w * h
		var count := 1
		if area > 70.0:
			count = 2
		if area > 140.0:
			count = 3
		var lights: Array = []
		for i in count:
			var u := 0.5 if count == 1 else (0.28 + 0.44 * i / float(maxi(1, count - 1)))
			var v := 0.5 if count == 1 else (0.3 + 0.4 * (i % 2))
			var pos := _pos(r, u, v) + Vector3(0, wall_height - 0.45, 0)
			var light := OmniLight3D.new()
			light.light_color = _room_light_color(r["kind"])
			light.light_energy = 1.05
			light.omni_range = clampf(maxf(w, h) * 0.62, 4.5, 13.0)
			light.omni_attenuation = 1.4
			light.shadow_enabled = false
			light.position = pos
			add_child(light)
			var bulb := _ceiling_lamp(pos)
			lights.append({"light": light, "bulb": bulb, "base": light.light_energy})
		room_lights[r["id"]] = lights


func _ceiling_lamp(pos: Vector3) -> MeshInstance3D:
	var group := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.16
	sm.height = 0.32
	group.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.95, 0.8)
	mat.emission_enabled = true
	mat.emission = Color(1.0, 0.88, 0.65)
	mat.emission_energy_multiplier = 1.2
	group.material_override = mat
	group.position = pos
	add_child(group)
	var stem := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.02
	cm.bottom_radius = 0.02
	cm.height = 0.32
	stem.mesh = cm
	stem.material_override = _simple_mat(Color(0.2, 0.2, 0.2), 0.4, 0.7)
	stem.position = pos + Vector3(0, 0.3, 0)
	add_child(stem)
	return group


func _room_light_color(kind: String) -> Color:
	match kind:
		"bath":
			return Color(0.8, 0.9, 1.0)
		"kitchen":
			return Color(1.0, 0.94, 0.82)
		"garage", "storage":
			return Color(0.85, 0.9, 0.78)
		"grand", "ballroom":
			return Color(1.0, 0.82, 0.58)
		"library", "study":
			return Color(1.0, 0.86, 0.66)
		_:
			return Color(1.0, 0.9, 0.76)


func _build_walls() -> void:
	for z in map_h:
		for x in map_w:
			var room := _room_at_cell(x, z)
			if room.is_empty():
				continue
			var east := _room_at_cell(x + 1, z)
			if east != room:
				_build_edge(x, z, "e", room, east)
			var south := _room_at_cell(x, z + 1)
			if south != room:
				_build_edge(x, z, "s", room, south)
			if x == 0:
				_build_edge(x, z, "w", room, "")
			if z == 0:
				_build_edge(x, z, "n", room, "")


func _build_edge(x: int, z: int, dir: String, room_id: String, other_id: String) -> void:
	var key := _edge_key(x, z, dir)
	var room: Dictionary = rooms_by_id.get(room_id, {})
	var tint: Color = _wall_color(room)
	var mat := _wall_mat(tint, true)
	var len := cell + 0.16
	var thickness := 0.18
	var center := _edge_center(x, z, dir)
	var vertical := dir == "e" or dir == "w"
	if _door_keys.has(key):
		var door_h := 2.15
		var door_w := minf(cell - 0.42, 2.5)
		var lintel_size := Vector3(thickness, wall_height - door_h, len) if vertical else Vector3(len, wall_height - door_h, thickness)
		_box(lintel_size, center + Vector3(0, door_h + (wall_height - door_h) * 0.5, 0), mat, true)
		var gap := (cell - door_w) * 0.5
		if gap > 0.02:
			if vertical:
				_box(Vector3(thickness, door_h, gap), center + Vector3(0, door_h * 0.5, -(door_w * 0.5 + gap * 0.5)), mat, true)
				_box(Vector3(thickness, door_h, gap), center + Vector3(0, door_h * 0.5, door_w * 0.5 + gap * 0.5), mat, true)
			else:
				_box(Vector3(gap, door_h, thickness), center + Vector3(-(door_w * 0.5 + gap * 0.5), door_h * 0.5, 0), mat, true)
				_box(Vector3(gap, door_h, thickness), center + Vector3(door_w * 0.5 + gap * 0.5, door_h * 0.5, 0), mat, true)
		var door := GameDoor.new()
		door.position = center
		door.rotation.y = PI * 0.5 if vertical else 0.0
		add_child(door)
		var door_id := "door_" + key.replace(":", "_")
		door.setup(door_id, door_w, door_h, room_id, other_id, tint)
		doors[door_id] = door
		return
	if _window_keys.has(key):
		_build_window(center, len, vertical, mat)
		return
	var size := Vector3(thickness, wall_height, len) if vertical else Vector3(len, wall_height, thickness)
	_box(size, center + Vector3(0, wall_height * 0.5, 0), mat, true)


func _build_window(center: Vector3, len: float, vertical: bool, wall_mat: Material) -> void:
	var lower := 0.85
	var upper := 2.15
	var thickness := 0.18
	var low_size := Vector3(thickness, lower, len) if vertical else Vector3(len, lower, thickness)
	_box(low_size, center + Vector3(0, lower * 0.5, 0), wall_mat, true)
	var up_h := wall_height - upper
	var up_size := Vector3(thickness, up_h, len) if vertical else Vector3(len, up_h, thickness)
	_box(up_size, center + Vector3(0, upper + up_h * 0.5, 0), wall_mat, true)
	var glass_mat := StandardMaterial3D.new()
	glass_mat.albedo_color = Color(0.55, 0.72, 0.88, 0.3)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass_mat.roughness = 0.05
	glass_mat.metallic = 0.25
	glass_mat.emission_enabled = true
	glass_mat.emission = Color(0.3, 0.45, 0.6)
	glass_mat.emission_energy_multiplier = 0.15
	var glass_size := Vector3(0.04, upper - lower, len - 0.16) if vertical else Vector3(len - 0.16, upper - lower, 0.04)
	_box(glass_size, center + Vector3(0, (lower + upper) * 0.5, 0), glass_mat, true)
	var frame_mat := _simple_mat(Color(0.25, 0.22, 0.18), 0.6)
	var sill_size := Vector3(0.3, 0.08, len) if vertical else Vector3(len, 0.08, 0.3)
	_box(sill_size, center + Vector3(0, lower, 0), frame_mat, false)
	var mull := Vector3(0.08, upper - lower, 0.08)
	_box(mull, center + Vector3(0, (lower + upper) * 0.5, 0), frame_mat, false)


func _build_doors_and_windows() -> void:
	pass


# ---------------------------------------------------------------- furniture

func _furnish_all_rooms() -> void:
	for r in data["rooms"]:
		_furnish_room(r)


func _furnish_room(r: Dictionary) -> void:
	match str(r["kind"]):
		"living":
			_living(r)
		"bedroom":
			_bedroom(r)
		"kitchen":
			_kitchen(r)
		"dining":
			_dining(r)
		"hall":
			_hall(r)
		"bath":
			_bath(r)
		"study":
			_study(r)
		"garage":
			_garage(r)
		"family":
			_family(r)
		"laundry":
			_laundry(r)
		"storage":
			_storage(r)
		"game":
			_game_room(r)
		"grand":
			_grand(r)
		"stairhall":
			_stairhall(r)
		"ballroom":
			_ballroom(r)
		"library":
			_library(r)
		"conservatory":
			_conservatory(r)
		"lobby":
			_lobby(r)
		_:
			_generic(r)


func _living(r: Dictionary) -> void:
	_rug(r, 0.5, 0.5, 1.0)
	_f(r, "furniture:couch", 0.5, 0.18, 0, 1.0)
	_f(r, "furniture:table_low", 0.5, 0.5, 0, 0.85)
	_f(r, "furniture:armchair", 0.17, 0.55, 90, 0.9)
	_f(r, "furniture:lamp_standing", 0.9, 0.22, 0, 0.85)
	_f(r, "furniture:cabinet_medium", 0.9, 0.82, 90, 0.9)
	_plant(r, 0.08, 0.85)
	_tv(r, 0.5, 0.95, 0)
	_noisy_at(_pos(r, 0.5, 0.5) + Vector3(0, 1.0, 0), r["id"])
	_painting(r, 0.25, 0.02, 0, Color(0.7, 0.3, 0.25))


func _bedroom(r: Dictionary) -> void:
	_f(r, "furniture:bed_double_A", 0.5, 0.3, 0, 0.95)
	_f(r, "furniture:table_small", 0.2, 0.12, 0, 0.55)
	_f(r, "furniture:table_small", 0.8, 0.12, 0, 0.55)
	_f(r, "furniture:cabinet_medium", 0.92, 0.62, 90, 0.9)
	_f(r, "furniture:table_small", 0.12, 0.62, 90, 0.7)
	_f(r, "furniture:chair_A", 0.24, 0.62, -90, 0.8)
	_rug(r, 0.5, 0.78, 0.85)
	_plant(r, 0.9, 0.92)
	_noisy_at(_pos(r, 0.2, 0.12) + Vector3(0, 0.75, 0), r["id"])
	_painting(r, 0.5, 0.02, 0, Color(0.35, 0.45, 0.65))


func _kitchen(r: Dictionary) -> void:
	var w: float = r["w"] * cell
	_f(r, "restaurant:kitchencounter_straight_A", 0.16, 0.1, 0, 0.85)
	_f(r, "restaurant:kitchencounter_sink", 0.34, 0.1, 0, 0.85)
	_f(r, "restaurant:kitchencounter_straight_A", 0.52, 0.1, 0, 0.85)
	_f(r, "restaurant:stove_single", 0.68, 0.1, 0, 0.8)
	_f(r, "restaurant:fridge_A", 0.9, 0.12, 0, 0.65)
	_f(r, "restaurant:kitchentable_A", 0.5, 0.56, 0, 0.9)
	_f(r, "furniture:chair_A", 0.35, 0.56, 90, 0.8)
	_f(r, "furniture:chair_A", 0.65, 0.56, -90, 0.8)
	_rug(r, 0.5, 0.58, 0.55)
	_f(r, "furniture:cabinet_small", 0.92, 0.88, 90, 0.8)
	_noisy_at(_pos(r, 0.5, 0.56) + Vector3(0, 1.0, 0), r["id"])
	_painting(r, 0.5, 0.02, 0, Color(0.3, 0.55, 0.4))
	if w < 8.0:
		_f(r, "restaurant:kitchencounter_straight_A", 0.8, 0.1, 0, 0.7)


func _dining(r: Dictionary) -> void:
	_f(r, "furniture:table_medium_long", 0.5, 0.5, 0, 1.0)
	for i in 3:
		var u := 0.28 + i * 0.22
		_f(r, "furniture:chair_A", u, 0.3, 180, 0.75)
		_f(r, "furniture:chair_A", u, 0.7, 0, 0.75)
	_rug(r, 0.5, 0.5, 1.0)
	_f(r, "furniture:cabinet_medium", 0.1, 0.15, 90, 0.85)
	_f(r, "furniture:cabinet_medium", 0.9, 0.85, -90, 0.85)
	_chandelier(r, 0.5, 0.5)
	_noisy_at(_pos(r, 0.5, 0.5) + Vector3(0, 1.05, 0), r["id"])
	_painting(r, 0.5, 0.02, 0, Color(0.55, 0.35, 0.3))


func _hall(r: Dictionary) -> void:
	_runner_rug(r)
	_f(r, "furniture:table_small", 0.5, 0.2, 0, 0.6)
	_plant(r, 0.85, 0.8)
	_painting(r, 0.2, 0.02, 0, Color(0.35, 0.4, 0.6))
	if r["w"] * cell > 4.0:
		_f(r, "furniture:cabinet_medium", 0.12, 0.5, 90, 0.8)


func _bath(r: Dictionary) -> void:
	_bathtub(r, 0.5, 0.22, 0)
	_toilet(r, 0.15, 0.78, 0)
	_sink(r, 0.85, 0.78, 180)
	_rug(r, 0.5, 0.55, 0.5)
	_f(r, "furniture:lamp_table", 0.85, 0.55, 0, 0.8)
	_painting(r, 0.5, 0.02, 0, Color(0.3, 0.45, 0.5))


func _study(r: Dictionary) -> void:
	_f(r, "furniture:table_medium", 0.5, 0.28, 0, 0.9)
	_f(r, "furniture:chair_A", 0.5, 0.45, 180, 0.85)
	_f(r, "furniture:armchair", 0.82, 0.72, -45, 0.9)
	_f(r, "furniture:cabinet_medium", 0.1, 0.25, 90, 0.9)
	_f(r, "furniture:cabinet_medium", 0.1, 0.62, 90, 0.9)
	_rug(r, 0.5, 0.65, 0.8)
	_shelf_wall(r, 0.5, 0.02, 0)
	_noisy_at(_pos(r, 0.5, 0.28) + Vector3(0, 1.0, 0), r["id"])
	_painting(r, 0.8, 0.02, 0, Color(0.45, 0.3, 0.2))


func _garage(r: Dictionary) -> void:
	_car(r, 0.5, 0.52, 90)
	_f(r, "furniture:table_medium_long", 0.5, 0.1, 0, 0.85)
	_f(r, "prototype:Barrel_A", 0.1, 0.85, 0, 0.8)
	_f(r, "prototype:Barrel_B", 0.2, 0.9, 0, 0.8)
	_f(r, "prototype:Box_A", 0.88, 0.82, 0, 0.8)
	_f(r, "prototype:Box_B", 0.82, 0.92, 0, 0.8)
	_f(r, "furniture:cabinet_medium", 0.1, 0.15, 90, 0.85)
	_trap_at(_pos(r, 0.5, 0.8), "puddle", r["id"])
	_painting(r, 0.5, 0.02, 0, Color(0.4, 0.4, 0.4))


func _family(r: Dictionary) -> void:
	_f(r, "furniture:couch", 0.5, 0.18, 0, 1.0)
	_f(r, "furniture:table_low", 0.5, 0.5, 0, 0.85)
	_f(r, "furniture:armchair", 0.15, 0.55, 90, 0.9)
	_tv(r, 0.5, 0.95, 0)
	_rug(r, 0.5, 0.5, 1.0)
	_f(r, "furniture:cabinet_medium", 0.9, 0.15, 90, 0.9)
	_plant(r, 0.1, 0.85)
	_noisy_at(_pos(r, 0.5, 0.5) + Vector3(0, 1.0, 0), r["id"])


func _laundry(r: Dictionary) -> void:
	_washer(r, 0.3, 0.15, 0)
	_washer(r, 0.6, 0.15, 0)
	_f(r, "furniture:cabinet_medium", 0.5, 0.85, 180, 0.85)
	_f(r, "furniture:table_small", 0.85, 0.5, 90, 0.6)
	_f(r, "furniture:cabinet_small", 0.12, 0.5, 90, 0.75)
	_rug(r, 0.5, 0.55, 0.5)


func _storage(r: Dictionary) -> void:
	_f(r, "furniture:cabinet_medium", 0.12, 0.2, 90, 0.9)
	_f(r, "furniture:cabinet_medium", 0.12, 0.75, 90, 0.9)
	_f(r, "furniture:cabinet_medium", 0.88, 0.2, -90, 0.9)
	_f(r, "prototype:Box_A", 0.5, 0.3, 0, 0.85)
	_f(r, "prototype:Box_B", 0.62, 0.42, 20, 0.85)
	_f(r, "prototype:Box_C", 0.4, 0.55, -15, 0.85)
	_f(r, "prototype:Barrel_C", 0.8, 0.8, 0, 0.8)
	_f(r, "prototype:Pallet_Large", 0.5, 0.85, 0, 0.7)
	_noisy_at(_pos(r, 0.3, 0.8) + Vector3(0, 0.4, 0), r["id"])


func _game_room(r: Dictionary) -> void:
	_pool_table(r, 0.5, 0.5, 0)
	_f(r, "furniture:couch", 0.5, 0.1, 0, 0.9)
	_f(r, "furniture:cabinet_medium", 0.1, 0.8, 90, 0.9)
	_arcade(r, 0.9, 0.2, -90)
	_arcade(r, 0.9, 0.4, -90)
	_rug(r, 0.5, 0.85, 0.7)
	_noisy_at(_pos(r, 0.1, 0.5) + Vector3(0, 0.5, 0), r["id"])


func _grand(r: Dictionary) -> void:
	_runner_rug(r)
	_chandelier(r, 0.5, 0.5)
	_f(r, "furniture:couch", 0.2, 0.65, 90, 1.0)
	_f(r, "furniture:couch", 0.8, 0.65, -90, 1.0)
	_f(r, "furniture:table_low", 0.5, 0.65, 0, 0.9)
	_staircase(r, 0.5, 0.3, 0)
	_f(r, "furniture:cabinet_medium", 0.1, 0.1, 90, 1.0)
	_f(r, "furniture:cabinet_medium", 0.9, 0.1, -90, 1.0)
	_plant(r, 0.1, 0.9)
	_plant(r, 0.9, 0.9)
	_painting(r, 0.3, 0.02, 0, Color(0.5, 0.35, 0.2))
	_painting(r, 0.7, 0.02, 0, Color(0.35, 0.3, 0.5))
	_noisy_at(_pos(r, 0.5, 0.65) + Vector3(0, 1.05, 0), r["id"])


func _stairhall(r: Dictionary) -> void:
	_runner_rug(r)
	_chandelier(r, 0.5, 0.5)
	_staircase(r, 0.5, 0.45, 0)
	_f(r, "furniture:cabinet_medium", 0.1, 0.15, 90, 0.9)
	_f(r, "furniture:cabinet_medium", 0.9, 0.15, -90, 0.9)
	_plant(r, 0.12, 0.85)
	_plant(r, 0.88, 0.85)
	_painting(r, 0.2, 0.02, 0, Color(0.45, 0.3, 0.2))
	_painting(r, 0.8, 0.02, 0, Color(0.3, 0.4, 0.5))


func _ballroom(r: Dictionary) -> void:
	_chandelier(r, 0.3, 0.5)
	_chandelier(r, 0.7, 0.5)
	_piano(r, 0.15, 0.2, 90)
	_f(r, "furniture:couch", 0.5, 0.1, 0, 0.9)
	_f(r, "furniture:couch", 0.5, 0.9, 180, 0.9)
	_rug(r, 0.5, 0.5, 1.4)
	_f(r, "furniture:cabinet_medium", 0.9, 0.2, -90, 0.9)
	_painting(r, 0.5, 0.02, 0, Color(0.55, 0.25, 0.3))


func _library(r: Dictionary) -> void:
	_f(r, "furniture:cabinet_medium", 0.1, 0.15, 90, 1.0)
	_f(r, "furniture:cabinet_medium", 0.1, 0.35, 90, 1.0)
	_f(r, "furniture:cabinet_medium", 0.1, 0.55, 90, 1.0)
	_f(r, "furniture:cabinet_medium", 0.9, 0.15, -90, 1.0)
	_f(r, "furniture:cabinet_medium", 0.9, 0.35, -90, 1.0)
	_f(r, "furniture:table_medium_long", 0.5, 0.5, 0, 1.0)
	_f(r, "furniture:chair_A", 0.35, 0.5, 90, 0.8)
	_f(r, "furniture:chair_A", 0.65, 0.5, -90, 0.8)
	_f(r, "furniture:armchair", 0.3, 0.8, 45, 0.9)
	_rug(r, 0.5, 0.5, 1.0)
	_shelf_wall(r, 0.5, 0.02, 0)
	_noisy_at(_pos(r, 0.5, 0.5) + Vector3(0, 1.05, 0), r["id"])


func _conservatory(r: Dictionary) -> void:
	_fountain(r, 0.5, 0.5)
	_plant(r, 0.15, 0.2, 1.4)
	_plant(r, 0.85, 0.2, 1.4)
	_plant(r, 0.15, 0.8, 1.2)
	_plant(r, 0.85, 0.8, 1.2)
	_f(r, "furniture:table_small", 0.5, 0.12, 0, 0.8)
	_f(r, "furniture:chair_A", 0.35, 0.2, 180, 0.8)
	_f(r, "furniture:chair_A", 0.65, 0.2, 180, 0.8)
	_rug(r, 0.5, 0.75, 0.7)
	_noisy_at(_pos(r, 0.5, 0.12) + Vector3(0, 0.9, 0), r["id"])


func _lobby(r: Dictionary) -> void:
	_f(r, "furniture:table_medium_long", 0.5, 0.25, 0, 0.9)
	_f(r, "furniture:chair_A", 0.5, 0.4, 180, 0.8)
	_f(r, "furniture:couch", 0.5, 0.82, 180, 0.9)
	_rug(r, 0.5, 0.6, 0.9)
	_plant(r, 0.1, 0.1, 1.2)
	_plant(r, 0.9, 0.1, 1.2)
	_painting(r, 0.5, 0.02, 0, Color(0.3, 0.5, 0.4))


func _generic(r: Dictionary) -> void:
	_rug(r, 0.5, 0.5, 0.7)
	_f(r, "furniture:cabinet_medium", 0.15, 0.2, 90, 0.9)
	_f(r, "furniture:table_small", 0.5, 0.5, 0, 0.8)


# ---------------------------------------------------------------- furniture helpers

func _f(r: Dictionary, asset: String, u: float, v: float, yaw: float = 0.0, s: float = 1.0, collide: bool = true) -> Node3D:
	return _place_asset(asset, _pos(r, u, v), yaw, s, collide)


func _pos(r: Dictionary, u: float, v: float) -> Vector3:
	return Vector3((r["x"] + u * r["w"]) * cell, 0.0, (r["z"] + v * r["h"]) * cell)


func _rug(r: Dictionary, u: float, v: float, s: float) -> void:
	_place_asset("furniture:rug_rectangle_A", _pos(r, u, v) + Vector3(0, 0.02, 0), 0, s, false)


func _runner_rug(r: Dictionary) -> void:
	var w: float = r["w"] * cell
	var h: float = r["h"] * cell
	_place_asset("furniture:rug_rectangle_stripes_A", _pos(r, 0.5, 0.5) + Vector3(0, 0.02, 0), 0 if w > h else 90, 0.55, false)


func _plant(r: Dictionary, u: float, v: float, s: float = 1.0) -> void:
	_place_asset("furniture:cactus_medium_A", _pos(r, u, v), _rng.randf_range(0, 360), s, false)


func _shelf_wall(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var inst := _place_asset("furniture:shelf_B_large", _pos(r, u, v) + Vector3(0, 1.4, 0), yaw, 0.9, false)
	if inst:
		_place_asset("furniture:book_set", _pos(r, u, v) + Vector3(0, 1.75, 0), yaw, 0.7, false)


func _painting(r: Dictionary, u: float, v: float, yaw: float, color: Color) -> void:
	var pos := _pos(r, u, v) + Vector3(0, 1.7, 0)
	var frame := _box(Vector3(1.3, 0.95, 0.07), pos, _simple_mat(Color(0.65, 0.5, 0.25), 0.5, 0.5), false)
	frame.rotation_degrees.y = yaw
	var canvas := _box(Vector3(1.12, 0.78, 0.08), pos + Vector3(0, 0, 0.02), _simple_mat(color, 0.9), false)
	canvas.rotation_degrees.y = yaw
	if yaw == 0:
		frame.position.z -= 0.05
		canvas.position.z -= 0.04


func _tv(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var pos := _pos(r, u, v) + Vector3(0, 1.25, 0)
	var body := _box(Vector3(1.7, 0.95, 0.12), pos, _simple_mat(Color(0.08, 0.08, 0.09), 0.5), false)
	body.rotation_degrees.y = yaw
	var screen := _box(Vector3(1.55, 0.8, 0.13), pos + Vector3(0, 0, 0.01), _simple_mat(Color(0.1, 0.16, 0.22), 0.2, 0.3, Color(0.1, 0.2, 0.35), 0.35), false)
	screen.rotation_degrees.y = yaw
	var stand := _box(Vector3(0.8, 0.55, 0.4), _pos(r, u, v) + Vector3(0, 0.3, 0), _simple_mat(Color(0.2, 0.15, 0.1), 0.7), true)
	stand.rotation_degrees.y = yaw


func _bathtub(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var white := _simple_mat(Color(0.93, 0.94, 0.92), 0.25)
	var water := StandardMaterial3D.new()
	water.albedo_color = Color(0.35, 0.65, 0.85, 0.55)
	water.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	water.roughness = 0.05
	_box(Vector3(1.8, 0.55, 0.9), base + Vector3(0, 0.28, 0), white, true)
	_box(Vector3(1.6, 0.1, 0.7), base + Vector3(0, 0.52, 0), water, false)
	for sx in [-1.0, 1.0]:
		_box(Vector3(0.1, 0.35, 0.9), base + Vector3(sx * 0.85, 0.72, 0), white, false)
	_box(Vector3(1.8, 0.35, 0.1), base + Vector3(0, 0.72, 0.45), white, false)


func _toilet(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var white := _simple_mat(Color(0.95, 0.95, 0.93), 0.2)
	_box(Vector3(0.45, 0.42, 0.6), base + Vector3(0, 0.21, 0), white, true)
	_box(Vector3(0.5, 0.12, 0.65), base + Vector3(0, 0.46, 0.02), white, false)
	_box(Vector3(0.5, 0.7, 0.18), base + Vector3(0, 0.35, -0.32), white, false)


func _sink(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var white := _simple_mat(Color(0.92, 0.92, 0.9), 0.3)
	_box(Vector3(0.8, 0.8, 0.5), base + Vector3(0, 0.4, 0), white, true)
	_box(Vector3(0.7, 0.08, 0.4), base + Vector3(0, 0.82, 0.02), _simple_mat(Color(0.7, 0.78, 0.8), 0.2, 0.3), false)
	_box(Vector3(0.9, 0.7, 0.04), base + Vector3(0, 1.45, -0.3), _simple_mat(Color(0.7, 0.8, 0.85), 0.1, 0.4), false)


func _washer(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var white := _simple_mat(Color(0.9, 0.9, 0.88), 0.4)
	_box(Vector3(0.85, 0.95, 0.8), base + Vector3(0, 0.48, 0), white, true)
	var door := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.25
	cm.bottom_radius = 0.25
	cm.height = 0.05
	cm.radial_segments = 16
	door.mesh = cm
	door.material_override = _simple_mat(Color(0.18, 0.25, 0.3), 0.1, 0.5)
	door.position = base + Vector3(0, 0.5, 0.42)
	door.rotation_degrees.x = 90
	add_child(door)


func _chandelier(r: Dictionary, u: float, v: float) -> void:
	var base := _pos(r, u, v)
	var gold := _simple_mat(Color(0.75, 0.58, 0.25), 0.3, 0.8)
	var stem := _box(Vector3(0.06, 1.0, 0.06), base + Vector3(0, wall_height - 0.75, 0), gold, false)
	var ring := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.45
	tm.outer_radius = 0.52
	tm.rings = 16
	tm.ring_segments = 6
	ring.mesh = tm
	ring.material_override = gold
	ring.position = base + Vector3(0, wall_height - 1.2, 0)
	ring.rotation.x = PI * 0.5
	add_child(ring)
	var light := OmniLight3D.new()
	light.light_color = Color(1.0, 0.78, 0.48)
	light.light_energy = 1.3
	light.omni_range = 10.0
	light.position = base + Vector3(0, wall_height - 1.2, 0)
	add_child(light)
	for i in 6:
		var ang := TAU * i / 6.0
		var bulb := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.06
		sm.height = 0.12
		bulb.mesh = sm
		var bm := StandardMaterial3D.new()
		bm.albedo_color = Color(1.0, 0.9, 0.65)
		bm.emission_enabled = true
		bm.emission = Color(1.0, 0.8, 0.45)
		bm.emission_energy_multiplier = 2.0
		bulb.material_override = bm
		bulb.position = base + Vector3(cos(ang) * 0.5, wall_height - 1.2, sin(ang) * 0.5)
		add_child(bulb)
	if room_lights.has(r["id"]):
		room_lights[r["id"]].append({"light": light, "bulb": stem, "base": 1.3})


func _staircase(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var mat := _simple_mat(Color(0.62, 0.55, 0.44), 0.7)
	var rail := _simple_mat(Color(0.3, 0.22, 0.15), 0.6)
	for i in 9:
		var step := _box(Vector3(2.4, 0.22, 0.38), base + Vector3(0, 0.11 + i * 0.22, -i * 0.36), mat, true)
		step.rotation_degrees.y = yaw
	_box(Vector3(2.4, 0.2, 1.6), base + Vector3(0, 2.0, -3.2), mat, true)
	for side in [-1.0, 1.0]:
		_box(Vector3(0.08, 1.0, 3.3), base + Vector3(side * 1.2, 1.3, -1.45), rail, false)


func _piano(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var black := _simple_mat(Color(0.06, 0.06, 0.07), 0.25)
	_box(Vector3(2.1, 0.8, 0.8), base + Vector3(0, 0.4, 0), black, true)
	_box(Vector3(1.7, 0.16, 0.35), base + Vector3(0, 0.88, 0.35), _simple_mat(Color(0.95, 0.95, 0.9), 0.2), false)
	for i in 5:
		_box(Vector3(0.08, 0.06, 0.2), base + Vector3(-0.7 + i * 0.35, 0.9, 0.42), _simple_mat(Color(0.02, 0.02, 0.02), 0.2), false)


func _pool_table(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var wood := _simple_mat(Color(0.28, 0.16, 0.1), 0.6)
	var felt := _simple_mat(Color(0.1, 0.4, 0.22), 0.95)
	_box(Vector3(2.8, 0.18, 1.5), base + Vector3(0, 0.85, 0), wood, true)
	_box(Vector3(2.5, 0.06, 1.25), base + Vector3(0, 0.96, 0), felt, false)
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			_box(Vector3(0.16, 0.8, 0.16), base + Vector3(sx * 1.2, 0.4, sz * 0.6), wood, false)


func _arcade(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var body := _box(Vector3(0.85, 1.85, 0.7), base + Vector3(0, 0.92, 0), _simple_mat(Color(0.12, 0.1, 0.18), 0.5), true)
	body.rotation_degrees.y = yaw
	var screen := _box(Vector3(0.6, 0.5, 0.72), base + Vector3(0, 1.35, 0), _simple_mat(Color(0.2, 0.7, 0.9), 0.2, 0.2, Color(0.2, 0.7, 0.9), 0.8), false)
	screen.rotation_degrees.y = yaw


func _car(r: Dictionary, u: float, v: float, yaw: float) -> void:
	var base := _pos(r, u, v)
	var paint := _simple_mat(Color(0.55, 0.15, 0.18), 0.35, 0.4)
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.15, 0.22, 0.28, 0.75)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	glass.roughness = 0.05
	_box(Vector3(4.2, 0.65, 1.85), base + Vector3(0, 0.55, 0), paint, true)
	var cabin := _box(Vector3(2.0, 0.62, 1.7), base + Vector3(0, 1.15, 0), glass, false)
	cabin.rotation_degrees.y = yaw
	for sx in [-1.0, 1.0]:
		for sz in [-1.0, 1.0]:
			var wheel := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.32
			cm.bottom_radius = 0.32
			cm.height = 0.22
			cm.radial_segments = 12
			wheel.mesh = cm
			wheel.material_override = _simple_mat(Color(0.05, 0.05, 0.05), 0.7)
			wheel.position = base + Vector3(sx * 1.35, 0.32, sz * 0.95)
			wheel.rotation_degrees.z = 90
			add_child(wheel)


func _fountain(r: Dictionary, u: float, v: float) -> void:
	var base := _pos(r, u, v)
	var stone := _simple_mat(Color(0.62, 0.6, 0.56), 0.8)
	var water := StandardMaterial3D.new()
	water.albedo_color = Color(0.3, 0.55, 0.7, 0.6)
	water.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	water.roughness = 0.05
	var basin := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.25
	cm.bottom_radius = 1.35
	cm.height = 0.5
	cm.radial_segments = 18
	basin.mesh = cm
	basin.material_override = stone
	basin.position = base + Vector3(0, 0.25, 0)
	add_child(basin)
	var pool := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 1.05
	pm.bottom_radius = 1.05
	pm.height = 0.05
	pm.radial_segments = 18
	pool.mesh = pm
	pool.material_override = water
	pool.position = base + Vector3(0, 0.5, 0)
	add_child(pool)
	_box(Vector3(0.3, 1.3, 0.3), base + Vector3(0, 1.1, 0), stone, false)
	var body := StaticBody3D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 1.3
	shape.height = 0.55
	cs.shape = shape
	cs.position = base + Vector3(0, 0.28, 0)
	body.add_child(cs)
	add_child(body)


# ---------------------------------------------------------------- assets

func _place_asset(asset: String, pos: Vector3, yaw_deg: float, s: float, collide: bool, parent: Node3D = null) -> Node3D:
	var path := _asset_path(asset)
	if path.is_empty():
		return null
	if not _scene_cache.has(path):
		if not ResourceLoader.exists(path):
			push_warning("Missing asset: " + path)
			return null
		_scene_cache[path] = load(path)
	var scene: PackedScene = _scene_cache[path]
	if scene == null:
		return null
	var inst := scene.instantiate()
	if parent == null:
		parent = self
	parent.add_child(inst)
	inst.position = pos
	inst.rotation_degrees = Vector3(0, yaw_deg, 0)
	inst.scale = Vector3.ONE * s
	var aabb := _aabb_of(inst)
	if aabb.size != Vector3.ZERO:
		inst.position.y = pos.y - aabb.position.y * s
	if collide and aabb.size != Vector3.ZERO:
		var body := StaticBody3D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		body.position = aabb.get_center()
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = aabb.size * 0.92
		cs.shape = shape
		body.add_child(cs)
		inst.add_child(body)
		# Transform AABB using the instance's global transform
		var transformed_min: Vector3 = inst.global_transform * aabb.position
		var transformed_max: Vector3 = inst.global_transform * (aabb.position + aabb.size)
		blockers.append(AABB(transformed_min, transformed_max - transformed_min))
	return inst


func _aabb_of(root: Node) -> AABB:
	var acc := {"first": true, "aabb": AABB()}
	for child in root.get_children():
		_walk_aabb(child, child.transform, acc)
	return acc["aabb"]


func _walk_aabb(node: Node, xform: Transform3D, acc: Dictionary) -> void:
	if node is MeshInstance3D and node.mesh:
		var mesh_aabb: AABB = node.mesh.get_aabb()
		# Godot 4.7 GDScript AABB has no .transformed() / .transform();
		# Use Transform3D * AABB operator overload instead.
		var a: AABB = xform * mesh_aabb
		if acc["first"]:
			acc["aabb"] = a
			acc["first"] = false
		else:
			acc["aabb"] = acc["aabb"].merge(a)
	for child in node.get_children():
		_walk_aabb(child, xform * child.transform, acc)


func _asset_path(asset: String) -> String:
	if asset.begins_with("res://"):
		return asset
	var parts := asset.split(":", false, 1)
	if parts.size() < 2:
		return ""
	match parts[0]:
		"furniture":
			return FURN + parts[1] + ".gltf"
		"restaurant":
			return REST + parts[1] + ".gltf"
		"prototype":
			return PROT + parts[1] + ".gltf"
	return ""


# ---------------------------------------------------------------- props and hiding

func _build_hiding_spots() -> void:
	var candidates := [
		Vector2(0.1, 0.12), Vector2(0.9, 0.12), Vector2(0.1, 0.88),
		Vector2(0.9, 0.88), Vector2(0.5, 0.12), Vector2(0.5, 0.88),
		Vector2(0.1, 0.5), Vector2(0.9, 0.5),
	]
	for r in data["rooms"]:
		var kind := str(r["kind"])
		if kind in ["garage", "storage", "bath", "laundry"]:
			continue
		var spot_kind := "curtain" if kind in ["grand", "ballroom", "library", "study", "conservatory", "living", "family"] else "closet"
		var wanted := 1
		var area: float = r["w"] * r["h"] * cell * cell
		if area > 55.0:
			wanted = 2
		var placed := 0
		for c in candidates:
			if placed >= wanted:
				break
			var pos := _pos(r, c.x, c.y)
			var yaw := 0.0
			if c.x > 0.75:
				yaw = -90.0
			elif c.x < 0.25:
				yaw = 90.0
			elif c.y > 0.75:
				yaw = 180.0
			if _spot_blocked(pos, yaw):
				continue
			var spot := HidingSpot.new()
			spot.position = pos
			spot.rotation_degrees.y = yaw
			add_child(spot)
			var id := "spot_%02d" % _spot_counter
			_spot_counter += 1
			spot.setup(id, spot_kind, r["id"])
			hiding_spots[id] = spot
			placed += 1
		if placed == 0 and area > 18.0:
			# Guarantee at least one spot in larger rooms.
			var pos := _pos(r, 0.5, 0.12)
			if not _spot_blocked(pos, 0.0):
				var spot := HidingSpot.new()
				spot.position = pos
				spot.rotation_degrees.y = 0
				add_child(spot)
				var id := "spot_%02d" % _spot_counter
				_spot_counter += 1
				spot.setup(id, "closet", r["id"])
				hiding_spots[id] = spot


func _spot_blocked(pos: Vector3, yaw: float) -> bool:
	var space := get_world_3d().direct_space_state
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.9, 2.3, 1.1)
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = shape
	q.collision_mask = 1
	q.collide_with_areas = false
	q.collide_with_bodies = true
	var basis := Basis(Vector3.UP, deg_to_rad(yaw))
	q.transform = Transform3D(basis, pos + Vector3(0, 1.2, 0))
	return not space.intersect_shape(q, 1).is_empty()


func _build_light_switches() -> void:
	for r in data["rooms"]:
		if str(r["kind"]) in ["storage", "garage"]:
			continue
		var pos := _pos(r, 0.5, 0.025) + Vector3(0, 1.25, 0)
		if _switch_near_door(pos):
			pos = _pos(r, 0.2, 0.025) + Vector3(0, 1.25, 0)
		if _switch_near_door(pos):
			pos = _pos(r, 0.8, 0.025) + Vector3(0, 1.25, 0)
		var sw := LightSwitch.new()
		sw.position = pos
		sw.rotation_degrees.y = 0
		add_child(sw)
		var id := "switch_" + str(r["id"])
		sw.setup(id, r["id"])
		light_switches[id] = sw


func _switch_near_door(pos: Vector3) -> bool:
	for d in doors.values():
		if Vector2(d.global_position.x, d.global_position.z).distance_to(Vector2(pos.x, pos.z)) < 1.2:
			return true
	return false


func _build_pickups() -> void:
	for r in data["rooms"]:
		var kind := str(r["kind"])
		var props: Array = []
		match kind:
			"kitchen":
				props = ["pan", "banana", "bottle"]
			"dining":
				props = ["banana", "bottle"]
			"garage":
				props = ["ball", "pan"]
			"game":
				props = ["ball", "ball"]
			"living", "family":
				props = ["ball"]
			"ballroom":
				props = ["ball"]
			"library":
				props = ["ball"]
			"study":
				props = ["bottle"]
			"hall":
				props = ["bottle"]
			"laundry":
				props = ["bottle"]
			_:
				props = []
		var n := 0
		for p in props:
			var pos := _clear_floor_spot(r, n)
			if pos == Vector3.ZERO:
				continue
			var pickup := PropPickup.new()
			pickup.position = pos
			pickup.home_position = pos
			add_child(pickup)
			var id := "prop_%03d" % _prop_counter
			_prop_counter += 1
			pickup.setup(id, p)
			pickups[id] = pickup
			n += 1


func _build_noisy_props() -> void:
	for r in data["rooms"]:
		var kind := str(r["kind"])
		if kind in ["living", "dining", "study", "library", "grand", "ballroom", "conservatory", "lobby", "storage"]:
			var pos := _clear_floor_spot(r, 5)
			if pos != Vector3.ZERO:
				_noisy_at(pos + Vector3(0, 0.2, 0), r["id"])


func _noisy_at(pos: Vector3, room_id: String) -> void:
	var np := NoisyProp.new()
	np.position = pos
	add_child(np)
	var id := "noisy_%03d" % _noisy_counter
	_noisy_counter += 1
	np.setup(id, room_id)


func _clear_floor_spot(r: Dictionary, index: int) -> Vector3:
	var candidates := [
		Vector2(0.3, 0.35), Vector2(0.7, 0.35), Vector2(0.3, 0.65),
		Vector2(0.7, 0.65), Vector2(0.5, 0.5), Vector2(0.5, 0.75),
		Vector2(0.2, 0.5), Vector2(0.8, 0.5),
	]
	for i in candidates.size():
		var c: Vector2 = candidates[(i + index) % candidates.size()]
		var pos := _pos(r, c.x, c.y)
		if _floor_clear(pos):
			return pos + Vector3(0, 0.05, 0)
	return Vector3.ZERO


func _floor_clear(pos: Vector3) -> bool:
	var space := get_world_3d().direct_space_state
	var shape := SphereShape3D.new()
	shape.radius = 0.32
	var q := PhysicsShapeQueryParameters3D.new()
	q.shape = shape
	q.collision_mask = 1
	q.collide_with_areas = false
	q.collide_with_bodies = true
	q.transform = Transform3D(Basis.IDENTITY, pos + Vector3(0, 0.6, 0))
	return space.intersect_shape(q, 1).is_empty()


func _trap_at(pos: Vector3, kind: String, _room_id: String) -> void:
	var trap := SlipTrap.new()
	trap.position = pos + Vector3(0, 0.03, 0)
	add_child(trap)
	var id := "trap_%03d" % _prop_counter
	_prop_counter += 1
	trap.setup(id, kind)


# ---------------------------------------------------------------- nav and spawns

func _build_nav() -> void:
	var saved: Dictionary = {}
	for d in doors.values():
		saved[d] = d.body.collision_layer
		d.body.collision_layer = 0
	nav = NavGrid.new()
	nav.build(self, data)
	for d in saved:
		if is_instance_valid(d) and is_instance_valid(d.body):
			d.body.collision_layer = int(saved[d])


func _build_spawn_points() -> void:
	for r in data["rooms"]:
		var candidates := [
			Vector2(0.5, 0.5), Vector2(0.3, 0.6), Vector2(0.7, 0.4),
			Vector2(0.4, 0.3), Vector2(0.6, 0.7),
		]
		var added := 0
		for c in candidates:
			var pos := _pos(r, c.x, c.y)
			var nearest := nav.nearest_point(pos) if nav else pos
			if nearest.distance_to(pos) > 1.6:
				continue
			spawn_points.append(nearest + Vector3(0, 0.05, 0))
			added += 1
			if added >= 3:
				break


# ---------------------------------------------------------------- material helpers

func _floor_mat(kind: String, w: float, h: float) -> StandardMaterial3D:
	var tex := "wood_floor"
	var tint := Color(0.95, 0.9, 0.85)
	match kind:
		"marble":
			tex = "marble"
			tint = Color(0.95, 0.95, 0.92)
		"terracotta":
			tex = "terracotta"
			tint = Color(0.92, 0.85, 0.78)
		"carpet":
			tex = "carpet"
			tint = Color(0.9, 0.88, 0.86)
	var uv := Vector3(maxf(1.0, w / 3.2), maxf(1.0, h / 3.2), 1.0)
	return _tex_mat(tex, tint, uv, false)


func _wall_mat(color: Color, triplanar: bool) -> StandardMaterial3D:
	return _tex_mat("stucco", color, Vector3(0.45, 0.45, 0.45), triplanar)


func _tex_mat(tex: String, tint: Color, uv: Vector3, triplanar: bool) -> StandardMaterial3D:
	var key := "%s_%s_%s_%s" % [tex, tint.to_html(), str(uv), str(triplanar)]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	var path := "res://assets/textures/" + tex + ".jpg"
	if ResourceLoader.exists(path):
		m.albedo_texture = load(path)
	m.albedo_color = tint
	m.roughness = 0.92
	m.uv1_scale = uv
	m.uv1_triplanar = triplanar
	m.uv1_world_triplanar = triplanar
	m.texture_repeat = 0
	_mat_cache[key] = m
	return m


func _simple_mat(color: Color, roughness: float = 0.8, metallic: float = 0.0, emission: Color = Color.BLACK, emission_energy: float = 0.0) -> StandardMaterial3D:
	var key := "simple_%s_%.2f_%.2f_%s_%.2f" % [color.to_html(), roughness, metallic, emission.to_html(), emission_energy]
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	if emission_energy > 0.0:
		m.emission_enabled = true
		m.emission = emission
		m.emission_energy_multiplier = emission_energy
	_mat_cache[key] = m
	return m


func _wall_color(r: Dictionary) -> Color:
	if r.is_empty():
		return data["wall_tint"]
	var base: Color = data["wall_tint"]
	match str(r["kind"]):
		"bath":
			return base.lerp(Color(0.75, 0.86, 0.9), 0.3)
		"bedroom":
			return base.lerp(Color(0.95, 0.84, 0.74), 0.18)
		"kitchen":
			return base.lerp(Color(0.9, 0.93, 0.86), 0.25)
		"storage", "garage":
			return base.darkened(0.12)
		"grand", "ballroom":
			return base.lerp(Color(0.95, 0.88, 0.74), 0.3)
		"conservatory":
			return base.lerp(Color(0.8, 0.9, 0.82), 0.3)
		_:
			return base


func _box(size: Vector3, pos: Vector3, mat: Material, collide: bool, parent: Node3D = null, yaw: float = 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees.y = yaw
	if parent == null:
		parent = self
	parent.add_child(mi)
	if collide:
		var body := StaticBody3D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		cs.shape = shape
		body.add_child(cs)
		mi.add_child(body)
	return mi


func _edge_key(x: int, z: int, dir: String) -> String:
	return "%d:%d:%s" % [x, z, dir]


func _edge_center(x: int, z: int, dir: String) -> Vector3:
	match dir:
		"e":
			return Vector3((x + 1) * cell, 0, (z + 0.5) * cell)
		"w":
			return Vector3(x * cell, 0, (z + 0.5) * cell)
		"s":
			return Vector3((x + 0.5) * cell, 0, (z + 1) * cell)
		_:
			return Vector3((x + 0.5) * cell, 0, z * cell)
