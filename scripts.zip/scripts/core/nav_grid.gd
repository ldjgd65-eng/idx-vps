class_name NavGrid
## Runtime A* navigation grid built from physics queries against the generated map.

const CELL := 0.7

var astar := AStar3D.new()
var nx := 0
var nz := 0
var room_of: Dictionary = {}          # point id -> room id
var points: Dictionary = {}           # point id -> Vector3
var room_points: Dictionary = {}      # room id -> Array[int]
var ready := false


func build(world: Node3D, data: Dictionary) -> void:
	ready = false
	astar.clear()
	room_of.clear()
	points.clear()
	room_points.clear()
	var map_cell: float = float(data["cell"])
	var map_w: int = int(data["width"])
	var map_h: int = int(data["height"])
	nx = int(ceil(map_w * map_cell / CELL))
	nz = int(ceil(map_h * map_cell / CELL))
	var room_grid := _make_room_grid(data)
	var space := world.get_world_3d().direct_space_state
	if space == null:
		return
	var sphere := SphereShape3D.new()
	sphere.radius = 0.33
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = sphere
	query.collision_mask = 1
	query.collide_with_areas = false
	query.collide_with_bodies = true
	for iz in nz:
		for ix in nx:
			var pos := Vector3(ix * CELL + CELL * 0.5, 0.0, iz * CELL + CELL * 0.5)
			var room := _room_at(pos, room_grid, map_cell, map_w, map_h)
			if room.is_empty():
				continue
			query.transform = Transform3D(Basis.IDENTITY, pos + Vector3(0, 0.9, 0))
			if not space.intersect_shape(query, 1).is_empty():
				continue
			var id := iz * nx + ix
			astar.add_point(id, pos)
			points[id] = pos
			room_of[id] = room
			if not room_points.has(room):
				room_points[room] = []
			room_points[room].append(id)
	for iz in nz:
		for ix in nx:
			var id := iz * nx + ix
			if not points.has(id):
				continue
			for d in [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(1, -1)]:
				var jx: int = ix + d.x
				var jz: int = iz + d.y
				if jx < 0 or jz < 0 or jx >= nx or jz >= nz:
					continue
				var jid: int = jz * nx + jx
				if not points.has(jid):
					continue
				if d.x != 0 and d.y != 0:
					if not points.has(iz * nx + jx) or not points.has(jz * nx + ix):
						continue
				astar.connect_points(id, jid, true)
	ready = true


func find_path(from: Vector3, to: Vector3) -> PackedVector3Array:
	if not ready or astar.get_point_count() == 0:
		return PackedVector3Array([to])
	var a := astar.get_closest_point(from, true)
	var b := astar.get_closest_point(to, true)
	if a < 0 or b < 0:
		return PackedVector3Array([to])
	var path := astar.get_point_path(a, b)
	if path.is_empty():
		return PackedVector3Array([to])
	if path[path.size() - 1].distance_to(to) > 0.6:
		path.append(Vector3(to.x, path[path.size() - 1].y, to.z))
	return path


func nearest_point(pos: Vector3) -> Vector3:
	if not ready or astar.get_point_count() == 0:
		return pos
	var id := astar.get_closest_point(pos, true)
	if id < 0:
		return pos
	return astar.get_point_position(id)


func random_room_point(room_id: String) -> Vector3:
	if not room_points.has(room_id):
		return Vector3.ZERO
	var arr: Array = room_points[room_id]
	if arr.is_empty():
		return Vector3.ZERO
	var id: int = arr[randi() % arr.size()]
	return points[id]


func rooms() -> Array:
	return room_points.keys()


func has_room(room_id: String) -> bool:
	return room_points.has(room_id) and not room_points[room_id].is_empty()


func _make_room_grid(data: Dictionary) -> Array:
	var map_w: int = int(data["width"])
	var map_h: int = int(data["height"])
	var grid := []
	grid.resize(map_w * map_h)
	grid.fill("")
	for r in data["rooms"]:
		for z in range(r["z"], r["z"] + r["h"]):
			for x in range(r["x"], r["x"] + r["w"]):
				if x >= 0 and z >= 0 and x < map_w and z < map_h:
					grid[z * map_w + x] = r["id"]
	return grid


func _room_at(pos: Vector3, grid: Array, map_cell: float, map_w: int, map_h: int) -> String:
	var x := int(floor(pos.x / map_cell))
	var z := int(floor(pos.z / map_cell))
	if x < 0 or z < 0 or x >= map_w or z >= map_h:
		return ""
	return grid[z * map_w + x]
