class_name NoisyProp
extends RigidBody3D
## Breakable vase. Makes a broad noise clue when knocked over.

var prop_id := ""
var room_id := ""
var _broken := false


func setup(id: String, room: String) -> void:
	prop_id = id
	room_id = room
	collision_layer = 8
	collision_mask = 1 | 2 | 8
	contact_monitor = true
	max_contacts_reported = 3
	mass = 0.4
	_build()
	body_entered.connect(_on_body_entered)


func _build() -> void:
	var body := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.1
	cm.bottom_radius = 0.16
	cm.height = 0.36
	cm.radial_segments = 12
	body.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.25, 0.55, 0.62)
	mat.roughness = 0.25
	mat.metallic = 0.1
	body.material_override = mat
	body.position = Vector3(0, 0.18, 0)
	add_child(body)
	var neck := MeshInstance3D.new()
	var nm := CylinderMesh.new()
	nm.top_radius = 0.075
	nm.bottom_radius = 0.1
	nm.height = 0.08
	neck.mesh = nm
	var nmat := StandardMaterial3D.new()
	nmat.albedo_color = Color(0.85, 0.72, 0.4)
	nmat.metallic = 0.7
	nmat.roughness = 0.25
	neck.material_override = nmat
	neck.position = Vector3(0, 0.4, 0)
	add_child(neck)
	var cs := CollisionShape3D.new()
	var shape := CylinderShape3D.new()
	shape.radius = 0.15
	shape.height = 0.4
	cs.shape = shape
	cs.position = Vector3(0, 0.2, 0)
	add_child(cs)


func _on_body_entered(_body: Node3D) -> void:
	if not Game.is_authority() or _broken:
		return
	var speed := linear_velocity.length()
	if speed < 1.6:
		return
	_broken = true
	var pos := global_position
	Audio.play_3d("vase_break", pos, 0.0, 20.0)
	Game.emit_noise(pos, 15.0, room_id, "A vase smashed")
	Game.despawn_noisy(prop_id)
	_spawn_shards(pos)
	queue_free()


func _spawn_shards(pos: Vector3) -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.25, 0.55, 0.62)
	mat.roughness = 0.3
	for i in 6:
		var shard := RigidBody3D.new()
		shard.collision_layer = 8
		shard.collision_mask = 1
		var mi := MeshInstance3D.new()
		var bm := BoxMesh.new()
		bm.size = Vector3(randf_range(0.05, 0.12), randf_range(0.02, 0.06), randf_range(0.05, 0.12))
		mi.mesh = bm
		mi.material_override = mat
		shard.add_child(mi)
		var cs := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = bm.size
		cs.shape = shape
		shard.add_child(cs)
		get_parent().add_child(shard)
		shard.global_position = pos + Vector3(0, 0.2, 0)
		shard.linear_velocity = Vector3(randf_range(-2, 2), randf_range(1, 3), randf_range(-2, 2))
		var t := get_tree().create_timer(4.0)
		t.timeout.connect(shard.queue_free)
