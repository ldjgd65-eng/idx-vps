class_name LightSwitch
extends Area3D
## Wall panel that toggles a room's lights and briefly disrupts Chaser sense.

var switch_id := ""
var room_id := ""
var is_on := true
var _panel_mat: StandardMaterial3D
var _led_mat: StandardMaterial3D


func setup(id: String, room: String) -> void:
	switch_id = id
	room_id = room
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	_build()


func _build() -> void:
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.34, 0.5, 0.18)
	cs.shape = shape
	add_child(cs)

	_panel_mat = StandardMaterial3D.new()
	_panel_mat.albedo_color = Color(0.9, 0.9, 0.86)
	_panel_mat.roughness = 0.6
	var back := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.26, 0.4, 0.05)
	back.mesh = bm
	back.material_override = _panel_mat
	add_child(back)

	var rocker := MeshInstance3D.new()
	var rm := BoxMesh.new()
	rm.size = Vector3(0.14, 0.22, 0.05)
	rocker.mesh = rm
	var rocker_mat := StandardMaterial3D.new()
	rocker_mat.albedo_color = Color(0.78, 0.78, 0.72)
	rocker_mat.roughness = 0.5
	rocker.material_override = rocker_mat
	rocker.position = Vector3(0, 0, 0.035)
	add_child(rocker)

	_led_mat = StandardMaterial3D.new()
	_led_mat.albedo_color = Color(0.35, 1.0, 0.5)
	_led_mat.emission_enabled = true
	_led_mat.emission = Color(0.25, 1.0, 0.4)
	_led_mat.emission_energy_multiplier = 2.0
	var led := MeshInstance3D.new()
	var lm := SphereMesh.new()
	lm.radius = 0.02
	lm.height = 0.04
	led.mesh = lm
	led.material_override = _led_mat
	led.position = Vector3(0.09, 0.16, 0.04)
	add_child(led)


func get_prompt(_player) -> String:
	return "Lights Off" if is_on else "Lights On"


func interact(_player) -> void:
	Game.request_light_toggle(switch_id)


func set_on(value: bool) -> void:
	is_on = value
	if _led_mat:
		if is_on:
			_led_mat.albedo_color = Color(0.35, 1.0, 0.5)
			_led_mat.emission = Color(0.25, 1.0, 0.4)
		else:
			_led_mat.albedo_color = Color(1.0, 0.4, 0.3)
			_led_mat.emission = Color(1.0, 0.3, 0.2)
