class_name GameDoor
extends Node3D
## Hinged door with open / closed / locked states. State is owned by Game.

var door_id := ""
var room_a := ""
var room_b := ""
var width := 2.4
var height := 2.2
var is_open := false
var locked := false
var force_time := 0.0

var pivot: Node3D
var body: StaticBody3D
var panel_mesh: MeshInstance3D
var lock_light: MeshInstance3D
var frame_mat: StandardMaterial3D
var door_mat: StandardMaterial3D
var _busy := false


func setup(id: String, w: float, h: float, a: String, b: String, tint: Color) -> void:
	door_id = id
	width = w
	height = h
	room_a = a
	room_b = b
	_build(tint)


func _build(tint: Color) -> void:
	frame_mat = StandardMaterial3D.new()
	frame_mat.albedo_color = tint.darkened(0.35)
	frame_mat.roughness = 0.8
	door_mat = StandardMaterial3D.new()
	door_mat.albedo_color = Color(0.55, 0.36, 0.22).lerp(tint, 0.18)
	door_mat.roughness = 0.72

	var frame := Node3D.new()
	add_child(frame)
	_add_box(frame, Vector3(0.09, height, 0.24), Vector3(-width * 0.5 - 0.045, height * 0.5, 0), frame_mat)
	_add_box(frame, Vector3(0.09, height, 0.24), Vector3(width * 0.5 + 0.045, height * 0.5, 0), frame_mat)
	_add_box(frame, Vector3(width + 0.18, 0.12, 0.26), Vector3(0, height + 0.06, 0), frame_mat)

	pivot = Node3D.new()
	pivot.position = Vector3(-width * 0.5, 0, 0)
	add_child(pivot)
	body = StaticBody3D.new()
	body.collision_layer = 1 | 4
	body.collision_mask = 0
	pivot.add_child(body)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(width - 0.05, height - 0.04, 0.14)
	cs.shape = shape
	cs.position = Vector3(width * 0.5, height * 0.5, 0)
	body.add_child(cs)

	panel_mesh = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(width - 0.05, height - 0.04, 0.12)
	panel_mesh.mesh = bm
	panel_mesh.material_override = door_mat
	panel_mesh.position = Vector3(width * 0.5, height * 0.5, 0)
	pivot.add_child(panel_mesh)

	# Recessed panels for a bit of toy-like detail.
	for side in [-1.0, 1.0]:
		var inset := MeshInstance3D.new()
		var ib := BoxMesh.new()
		ib.size = Vector3(width * 0.55, height * 0.34, 0.02)
		inset.mesh = ib
		var im := StandardMaterial3D.new()
		im.albedo_color = door_mat.albedo_color.darkened(0.12)
		im.roughness = 0.8
		inset.material_override = im
		inset.position = Vector3(width * 0.5, height * 0.5 + side * height * 0.23, 0.07)
		pivot.add_child(inset)

	var knob := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.07
	sm.height = 0.14
	knob.mesh = sm
	var km := StandardMaterial3D.new()
	km.albedo_color = Color(0.95, 0.78, 0.35)
	km.metallic = 0.8
	km.roughness = 0.25
	knob.material_override = km
	knob.position = Vector3(width - 0.25, height * 0.48, 0.1)
	pivot.add_child(knob)

	lock_light = MeshInstance3D.new()
	var lm := BoxMesh.new()
	lm.size = Vector3(0.1, 0.1, 0.03)
	lock_light.mesh = lm
	var lmat := StandardMaterial3D.new()
	lmat.albedo_color = Color(1.0, 0.25, 0.2)
	lmat.emission_enabled = true
	lmat.emission = Color(1.0, 0.2, 0.15)
	lmat.emission_energy_multiplier = 1.6
	lock_light.material_override = lmat
	lock_light.position = Vector3(width - 0.25, height * 0.78, 0.1)
	lock_light.visible = false
	pivot.add_child(lock_light)


func _add_box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)


func get_prompt(player) -> String:
	if player == null:
		return ""
	var role: int = player.role
	if locked:
		if role == Config.Role.CHASER:
			return "Force Open Door"
		return "Unlock & Open"
	if is_open:
		if role == Config.Role.RUNNER:
			return "Close & Lock Door"
		return "Close Door"
	return "Open Door"


func interact(player) -> void:
	if _busy:
		return
	var role: int = player.role if player else Config.Role.RUNNER
	if role == Config.Role.CHASER:
		if locked:
			Game.request_door_action(door_id, "force")
		elif is_open:
			Game.request_door_action(door_id, "close")
		else:
			Game.request_door_action(door_id, "open")
	elif role == Config.Role.RUNNER:
		if locked:
			Game.request_door_action(door_id, "unlock_open")
		elif is_open:
			Game.request_door_action(door_id, "close_lock")
		else:
			Game.request_door_action(door_id, "open")


func apply_state(state: String) -> void:
	match state:
		"open":
			locked = false
			_set_open(true)
		"close":
			locked = false
			_set_open(false)
		"close_lock":
			locked = true
			_set_open(false)
		"lock":
			locked = true
		"unlock_open":
			locked = false
			_set_open(true)
		"force_open":
			locked = false
			_set_open(true)
			Audio.play_3d("wood_impact", global_position, -1.0)
	_update_lock_visual()


func begin_force_visual() -> void:
	force_time = 0.0
	_busy = true
	var tw := create_tween()
	tw.tween_property(panel_mesh, "position:x", width * 0.5 + 0.025, 0.07)
	tw.tween_property(panel_mesh, "position:x", width * 0.5 - 0.025, 0.07)
	tw.set_loops(8)
	await get_tree().create_timer(1.2).timeout
	_busy = false


func _set_open(value: bool) -> void:
	if is_open == value:
		return
	is_open = value
	_busy = true
	var target := -1.92 if value else 0.0
	var tw := create_tween()
	tw.tween_property(pivot, "rotation:y", target, 0.24).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_OUT)
	tw.finished.connect(func(): _busy = false)
	Audio.play_3d("creak" if value else "door_open", global_position, -8.0, 18.0)


func _update_lock_visual() -> void:
	if lock_light:
		lock_light.visible = locked
