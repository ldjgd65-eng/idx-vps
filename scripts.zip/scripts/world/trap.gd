class_name SlipTrap
extends Area3D
## Banana peel or water puddle. Server-authoritative slip trigger.

var trap_id := ""
var kind := "puddle"
var _used := false
var _cooldowns: Dictionary = {}
var lifetime := 30.0


func setup(id: String, trap_kind: String) -> void:
	trap_id = id
	kind = trap_kind
	collision_layer = 16
	collision_mask = 2
	monitoring = true
	body_entered.connect(_on_body_entered)
	if kind == "puddle":
		lifetime = 45.0
	_build()
	var timer := get_tree().create_timer(lifetime)
	timer.timeout.connect(func():
		if is_instance_valid(self):
			queue_free()
	)


func _build() -> void:
	if kind == "puddle":
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 1.15
		cm.bottom_radius = 1.15
		cm.height = 0.025
		cm.radial_segments = 24
		mi.mesh = cm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.3, 0.55, 0.85, 0.62)
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.roughness = 0.06
		mat.metallic = 0.15
		mi.material_override = mat
		mi.position = Vector3(0, 0.02, 0)
		add_child(mi)
		var ring := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 1.05
		tm.outer_radius = 1.18
		tm.rings = 24
		tm.ring_segments = 4
		ring.mesh = tm
		var rmat := StandardMaterial3D.new()
		rmat.albedo_color = Color(0.55, 0.8, 1.0, 0.7)
		rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		rmat.emission_enabled = true
		rmat.emission = Color(0.2, 0.5, 0.8)
		rmat.emission_energy_multiplier = 0.4
		ring.material_override = rmat
		ring.position = Vector3(0, 0.035, 0)
		add_child(ring)
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = 1.15
		shape.height = 0.2
		cs.shape = shape
		cs.position = Vector3(0, 0.1, 0)
		add_child(cs)
	else:
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(1.0, 0.83, 0.14)
		mat.roughness = 0.65
		for i in 4:
			var seg := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.085
			sm.height = 0.17
			seg.mesh = sm
			seg.material_override = mat
			var t := float(i) / 3.0
			seg.position = Vector3(lerpf(-0.28, 0.28, t), 0.05 + sin(t * PI) * 0.05, 0)
			seg.rotation.z = lerpf(-0.6, 0.6, t)
			add_child(seg)
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = 0.55
		shape.height = 0.2
		cs.shape = shape
		cs.position = Vector3(0, 0.1, 0)
		add_child(cs)


func _on_body_entered(body: Node3D) -> void:
	if not Game.is_authority():
		return
	if Game.state != Config.MatchState.ACTIVE:
		return
	if not body.has_method("apply_slip"):
		return
	if body.hidden:
		return
	var now := Time.get_ticks_msec() / 1000.0
	if _cooldowns.has(body.peer_id) and now - float(_cooldowns[body.peer_id]) < 3.0:
		return
	_cooldowns[body.peer_id] = now
	body.apply_slip(1.15)
	Game.notify_event("%s slipped!" % body.display_name, Config.ROLE_COLORS[0])
	Audio.play_3d("slip", global_position, -2.0, 18.0)
	if kind == "banana" and not _used:
		_used = true
		Game.remove_trap(trap_id)
