class_name PropPickup
extends Area3D
## Pickable party prop. The server owns whether it is available or held.

var pickup_id := ""
var kind := "ball"
var home_position := Vector3.ZERO
var is_held := false


func setup(id: String, prop_kind: String) -> void:
	pickup_id = id
	kind = prop_kind
	collision_layer = 4
	collision_mask = 0
	monitoring = false
	_build()


func _build() -> void:
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.32
	cs.shape = shape
	cs.position = Vector3(0, 0.22, 0)
	add_child(cs)
	match kind:
		"pan":
			_build_pan()
		"banana":
			_build_banana()
		"bottle":
			_build_bottle()
		_:
			_build_ball()


func _build_ball() -> void:
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.19
	sm.height = 0.38
	sm.radial_segments = 16
	sm.rings = 8
	mi.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.96, 0.94, 0.88)
	mat.roughness = 0.55
	mi.material_override = mat
	mi.position = Vector3(0, 0.19, 0)
	add_child(mi)
	var stripe := MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.13
	tm.outer_radius = 0.19
	tm.rings = 12
	tm.ring_segments = 6
	stripe.mesh = tm
	var smat := StandardMaterial3D.new()
	smat.albedo_color = Color(0.85, 0.18, 0.18)
	smat.roughness = 0.5
	stripe.material_override = smat
	stripe.position = Vector3(0, 0.19, 0)
	stripe.rotation.x = PI * 0.5
	add_child(stripe)


func _build_pan() -> void:
	var pan := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.24
	cm.bottom_radius = 0.19
	cm.height = 0.08
	cm.radial_segments = 14
	pan.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.18, 0.18, 0.2)
	mat.metallic = 0.75
	mat.roughness = 0.35
	pan.material_override = mat
	pan.position = Vector3(0, 0.12, 0)
	add_child(pan)
	var handle := MeshInstance3D.new()
	var hm := BoxMesh.new()
	hm.size = Vector3(0.34, 0.05, 0.08)
	handle.mesh = hm
	var hmat := StandardMaterial3D.new()
	hmat.albedo_color = Color(0.28, 0.16, 0.1)
	hmat.roughness = 0.7
	handle.material_override = hmat
	handle.position = Vector3(0.38, 0.13, 0)
	add_child(handle)


func _build_banana() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.85, 0.18)
	mat.roughness = 0.65
	for i in 5:
		var seg := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.075
		sm.height = 0.15
		seg.mesh = sm
		seg.material_override = mat
		var t := float(i) / 4.0
		seg.position = Vector3(lerpf(-0.22, 0.22, t), 0.1 + sin(t * PI) * 0.08, 0)
		seg.rotation.z = lerpf(-0.5, 0.5, t)
		add_child(seg)
	var tip := MeshInstance3D.new()
	var tm := SphereMesh.new()
	tm.radius = 0.04
	tm.height = 0.08
	tip.mesh = tm
	var tipmat := StandardMaterial3D.new()
	tipmat.albedo_color = Color(0.3, 0.22, 0.1)
	tip.material_override = tipmat
	tip.position = Vector3(0.24, 0.1, 0)
	add_child(tip)


func _build_bottle() -> void:
	var body := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.06
	cm.bottom_radius = 0.07
	cm.height = 0.34
	cm.radial_segments = 12
	body.mesh = cm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.35, 0.7, 0.95, 0.85)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness = 0.15
	body.material_override = mat
	body.position = Vector3(0, 0.17, 0)
	add_child(body)
	var cap := MeshInstance3D.new()
	var cm2 := CylinderMesh.new()
	cm2.top_radius = 0.045
	cm2.bottom_radius = 0.045
	cm2.height = 0.06
	cap.mesh = cm2
	var cmat := StandardMaterial3D.new()
	cmat.albedo_color = Color(0.2, 0.45, 0.8)
	cap.material_override = cmat
	cap.position = Vector3(0, 0.37, 0)
	add_child(cap)


func get_prompt(_player) -> String:
	if is_held:
		return ""
	match kind:
		"pan":
			return "Pick Up Frying Pan"
		"banana":
			return "Pick Up Banana Peel"
		"bottle":
			return "Pick Up Water Bottle"
		_:
			return "Pick Up Ball"


func interact(player) -> void:
	if is_held:
		return
	Game.request_pickup(pickup_id, player.peer_id)


func set_held(held: bool) -> void:
	is_held = held
	visible = not held
	var shapes := find_children("*", "CollisionShape3D", true, false)
	for s in shapes:
		s.set_deferred("disabled", held)
