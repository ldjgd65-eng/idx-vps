class_name HidingSpot
extends StaticBody3D
## Closet or curtain alcove that a Runner can enter and a Chaser can search.

var spot_id := ""
var kind := "closet"
var room_id := ""
var occupant_id := 0
var exit_position := Vector3.ZERO
var hide_position := Vector3.ZERO
var search_cooldown := 0.0

var _glow: MeshInstance3D
var _glow_mat: StandardMaterial3D
var _doors: Array[MeshInstance3D] = []
var _open_amt := 0.0


func setup(id: String, spot_kind: String, room: String) -> void:
	spot_id = id
	kind = spot_kind
	room_id = room
	collision_layer = 1 | 4
	collision_mask = 0
	_build()


func _build() -> void:
	if kind == "curtain":
		_build_curtain()
	else:
		_build_closet()
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.5, 2.2, 0.75) if kind != "curtain" else Vector3(1.7, 2.3, 0.7)
	cs.shape = shape
	cs.position = Vector3(0, shape.size.y * 0.5, 0)
	add_child(cs)

	_glow = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.055
	sm.height = 0.11
	_glow.mesh = sm
	_glow_mat = StandardMaterial3D.new()
	_glow_mat.albedo_color = Color(0.5, 0.9, 1.0)
	_glow_mat.emission_enabled = true
	_glow_mat.emission = Color(0.4, 0.85, 1.0)
	_glow_mat.emission_energy_multiplier = 1.8
	_glow.material_override = _glow_mat
	_glow.position = Vector3(0, 2.35, 0.15)
	add_child(_glow)

	exit_position = global_transform * Vector3(0, 0, 0.95)
	hide_position = global_transform * Vector3(0, 0, 0.15)
	exit_position.y = 0.05
	hide_position.y = 0.05


func _build_closet() -> void:
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.47, 0.31, 0.2)
	body_mat.roughness = 0.85
	var trim_mat := StandardMaterial3D.new()
	trim_mat.albedo_color = Color(0.3, 0.19, 0.12)
	trim_mat.roughness = 0.8
	_box(Vector3(1.5, 2.2, 0.75), Vector3(0, 1.1, 0), body_mat)
	_box(Vector3(1.58, 0.1, 0.82), Vector3(0, 2.2, 0), trim_mat)
	for side in [-1.0, 1.0]:
		var d := _box(Vector3(0.7, 2.02, 0.06), Vector3(side * 0.365, 1.08, 0.39), body_mat)
		var knob := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.035
		sm.height = 0.07
		knob.mesh = sm
		var km := StandardMaterial3D.new()
		km.albedo_color = Color(0.95, 0.78, 0.35)
		km.metallic = 0.7
		knob.material_override = km
		knob.position = Vector3(side * 0.08, 1.05, 0.44)
		add_child(knob)
		_doors.append(d)
	# Thin dark reveal around the doors.
	_box(Vector3(1.44, 1.9, 0.02), Vector3(0, 1.1, 0.36), trim_mat)


func _build_curtain() -> void:
	var back_mat := StandardMaterial3D.new()
	back_mat.albedo_color = Color(0.28, 0.16, 0.18)
	back_mat.roughness = 0.9
	var rail_mat := StandardMaterial3D.new()
	rail_mat.albedo_color = Color(0.75, 0.62, 0.35)
	rail_mat.metallic = 0.7
	rail_mat.roughness = 0.3
	_box(Vector3(1.7, 2.3, 0.08), Vector3(0, 1.15, -0.33), back_mat)
	for side in [-1.0, 1.0]:
		_box(Vector3(0.1, 2.3, 0.7), Vector3(side * 0.8, 1.15, 0), back_mat)
	_box(Vector3(1.75, 0.08, 0.1), Vector3(0, 2.3, 0.28), rail_mat)
	var curtain_mat := StandardMaterial3D.new()
	curtain_mat.albedo_color = Color(0.62, 0.14, 0.2)
	curtain_mat.roughness = 0.95
	for side in [-1.0, 1.0]:
		var c := _box(Vector3(0.55, 2.2, 0.1), Vector3(side * 0.52, 1.12, 0.28), curtain_mat)
		_doors.append(c)
	# Soft red glow to read as a hiding place.
	var lamp := OmniLight3D.new()
	lamp.light_color = Color(0.85, 0.3, 0.35)
	lamp.light_energy = 0.35
	lamp.omni_range = 2.2
	lamp.position = Vector3(0, 1.8, 0.2)
	add_child(lamp)


func _box(size: Vector3, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	add_child(mi)
	return mi


func get_prompt(player) -> String:
	if player == null:
		return ""
	if player.role == Config.Role.CHASER:
		return "Search Hiding Spot"
	if occupant_id != 0:
		return "Occupied"
	return "Hide Here"


func interact(player) -> void:
	if player == null:
		return
	if player.role == Config.Role.CHASER:
		Game.request_search(spot_id, player.peer_id)
	else:
		Game.request_hide(spot_id, player.peer_id)


func set_occupant(id: int) -> void:
	occupant_id = id
	if _glow_mat:
		if id != 0:
			_glow_mat.albedo_color = Color(1.0, 0.62, 0.2)
			_glow_mat.emission = Color(1.0, 0.55, 0.15)
		else:
			_glow_mat.albedo_color = Color(0.5, 0.9, 1.0)
			_glow_mat.emission = Color(0.4, 0.85, 1.0)
	if id != 0 and kind == "closet":
		Audio.play_3d("creak", global_position, -16.0, 8.0)


func set_doors_ajar(amount: float) -> void:
	_open_amt = clampf(amount, 0.0, 1.0)
	for i in _doors.size():
		var d := _doors[i]
		var side := -1.0 if i % 2 == 0 else 1.0
		d.rotation.y = side * _open_amt * 0.35
