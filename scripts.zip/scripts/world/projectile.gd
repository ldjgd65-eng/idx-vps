class_name ThrownProp
extends RigidBody3D
## Server-simulated thrown ball or pan. Clients receive transform snapshots.

var prop_id := ""
var kind := "ball"
var thrower_id := 0
var _sync_accum := 0.0
var _bounce_cd := 0.0
var _spawned_at := 0.0
var _hit := false


func setup(id: String, prop_kind: String, owner_id: int, dir: Vector3, speed: float) -> void:
	prop_id = id
	kind = prop_kind
	thrower_id = owner_id
	collision_layer = 8
	collision_mask = 1 | 2
	contact_monitor = true
	max_contacts_reported = 6
	continuous_cd = true
	mass = 0.6
	gravity_scale = 1.0
	var pm := PhysicsMaterial.new()
	pm.bounce = 0.55 if kind == "ball" else 0.2
	pm.friction = 0.6
	physics_material_override = pm
	_build()
	_spawned_at = Time.get_ticks_msec() / 1000.0
	if not Game.is_authority():
		freeze = true
		freeze_mode = RigidBody3D.FREEZE_MODE_STATIC
	else:
		linear_velocity = dir.normalized() * speed + Vector3(0, 1.2, 0)
		angular_velocity = Vector3(randf_range(-8, 8), randf_range(-8, 8), randf_range(-8, 8))
	body_entered.connect(_on_body_entered)
	var t := get_tree().create_timer(7.0)
	t.timeout.connect(func():
		if is_instance_valid(self):
			if Game.is_authority():
				Game.despawn_projectile(prop_id)
			queue_free()
	)


func _build() -> void:
	var cs := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.18
	cs.shape = shape
	add_child(cs)
	if kind == "pan":
		var pan := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.24
		cm.bottom_radius = 0.19
		cm.height = 0.08
		cm.radial_segments = 12
		pan.mesh = cm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.18, 0.18, 0.2)
		mat.metallic = 0.75
		mat.roughness = 0.35
		pan.material_override = mat
		add_child(pan)
		var handle := MeshInstance3D.new()
		var hm := BoxMesh.new()
		hm.size = Vector3(0.34, 0.05, 0.08)
		handle.mesh = hm
		var hmat := StandardMaterial3D.new()
		hmat.albedo_color = Color(0.28, 0.16, 0.1)
		handle.material_override = hmat
		handle.position = Vector3(0.36, 0, 0)
		add_child(handle)
	else:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 0.18
		sm.height = 0.36
		sm.radial_segments = 14
		sm.rings = 7
		mi.mesh = sm
		var mat := StandardMaterial3D.new()
		mat.albedo_color = Color(0.96, 0.94, 0.88)
		mat.roughness = 0.5
		mi.material_override = mat
		add_child(mi)
		var stripe := MeshInstance3D.new()
		var tm := TorusMesh.new()
		tm.inner_radius = 0.12
		tm.outer_radius = 0.18
		tm.rings = 10
		tm.ring_segments = 5
		stripe.mesh = tm
		var smat := StandardMaterial3D.new()
		smat.albedo_color = Color(0.85, 0.18, 0.18)
		stripe.material_override = smat
		stripe.rotation.x = PI * 0.5
		add_child(stripe)


func _physics_process(delta: float) -> void:
	if not Game.is_authority():
		return
	_sync_accum += delta
	_bounce_cd = maxf(0.0, _bounce_cd - delta)
	if _sync_accum >= 0.06:
		_sync_accum = 0.0
		Game.sync_projectile(prop_id, global_position, global_rotation)


func _on_body_entered(body: Node3D) -> void:
	if not Game.is_authority() or _hit:
		return
	if Time.get_ticks_msec() / 1000.0 - _spawned_at < 0.12:
		return
	if body is Player:
		if body.peer_id == thrower_id:
			return
		if body.role == Config.Role.CHASER:
			_hit = true
			body.apply_stun(1.6 if kind == "ball" else 1.25, global_position, 5.0)
			Game.notify_event("%s got bonked!" % body.display_name, Color(1.0, 0.55, 0.3))
			Audio.play_3d("impact", global_position, 0.0, 22.0)
			Game.despawn_projectile(prop_id)
			queue_free()
		return
	if _bounce_cd <= 0.0:
		_bounce_cd = 0.18
		Audio.play_3d("ball_bounce", global_position, -10.0, 14.0)
