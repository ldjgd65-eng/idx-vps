extends Node
## ShameRun application shell: world hosting, screen routing and match lifecycle.

const MENU_SCREENS := ["main_menu", "character", "solo", "network", "lobby", "settings", "how_to_play", "credits"]

var game_world: Node3D
var menu_world: Node3D
var menu_stage: MenuStage
var ui_layer: CanvasLayer
var screen_root: Control
var hud_root: Control
var overlay_root: Control
var fade: ColorRect

var screens: Dictionary = {}
var current_screen := ""
var hud: GameHUD
var loading: LoadingScreen
var pause_menu: PauseMenu
var results: ResultsScreen

var preview_map_id := "suburban"
var _overlay_return := ""
var _last_result: Dictionary = {}
var _fade_tween: Tween
var _toast_panel: PanelContainer
var _toast_label: Label
var _toast_tween: Tween


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_world()
	_build_ui()
	_connect_signals()
	Game.world_root = game_world
	set_preview_map(preview_map_id)
	set_preview_character(Settings.character_id)
	show_screen("main_menu")
	play_menu_music()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


func _build_world() -> void:
	game_world = Node3D.new()
	game_world.name = "GameWorld"
	add_child(game_world)
	game_world.visible = false

	menu_world = Node3D.new()
	menu_world.name = "MenuWorld"
	add_child(menu_world)
	menu_stage = MenuStage.new()
	menu_stage.name = "MenuStage"
	menu_world.add_child(menu_stage)


func _build_ui() -> void:
	ui_layer = CanvasLayer.new()
	ui_layer.name = "UI"
	ui_layer.layer = 10
	add_child(ui_layer)

	screen_root = _full_control("Screens")
	ui_layer.add_child(screen_root)
	hud_root = _full_control("HUD")
	ui_layer.add_child(hud_root)
	overlay_root = _full_control("Overlays")
	ui_layer.add_child(overlay_root)

	_add_screen("main_menu", MainMenu.new())
	_add_screen("character", CharacterSelect.new())
	_add_screen("solo", SoloSetup.new())
	_add_screen("network", NetworkMenu.new())
	_add_screen("lobby", LobbyScreen.new())
	_add_screen("settings", SettingsMenu.new())
	_add_screen("how_to_play", HowToPlay.new())
	_add_screen("credits", CreditsScreen.new())

	loading = LoadingScreen.new()
	overlay_root.add_child(loading)

	results = ResultsScreen.new()
	results.main = self
	overlay_root.add_child(results)

	pause_menu = PauseMenu.new()
	pause_menu.main = self
	overlay_root.add_child(pause_menu)

	_build_toast()

	fade = ColorRect.new()
	fade.color = Color(0.02, 0.015, 0.03, 1.0)
	fade.modulate.a = 0.0
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui_layer.add_child(fade)


func _full_control(node_name: String) -> Control:
	var c := Control.new()
	c.name = node_name
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c


func _add_screen(key: String, screen: GameScreen) -> void:
	screen.main = self
	screen.name = key
	screen_root.add_child(screen)
	screens[key] = screen


func _build_toast() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_theme_constant_override("margin_top", 16)
	overlay_root.add_child(margin)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_child(row)
	_toast_panel = UiKit.panel_box(13, Color(0.075, 0.065, 0.1, 0.97), Color(1, 1, 1, 0.16), 12)
	_toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast_panel.visible = false
	row.add_child(_toast_panel)
	_toast_label = UiTheme.text_label("", 14, UiTheme.TEXT)
	_toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_toast_panel.add_child(_toast_label)


func _connect_signals() -> void:
	Game.state_changed.connect(_on_game_state)
	Game.loading_text.connect(_on_loading_text)
	Game.local_player_ready.connect(_on_local_player_ready)
	Game.match_ended.connect(_on_match_ended)
	Net.connection_succeeded.connect(_on_connection_succeeded)
	Net.server_disconnected.connect(_on_server_disconnected)
	Net.connection_failed.connect(_on_connection_failed)


# =============================================================== screens

func show_screen(key: String, data: Dictionary = {}) -> void:
	if not screens.has(key):
		push_error("Unknown screen: %s" % key)
		return
	var from_pause := bool(data.get("from_pause", false))
	if not from_pause:
		_abandon_match_if_needed()
		_overlay_return = ""
	if current_screen != "" and screens.has(current_screen):
		var old: GameScreen = screens[current_screen]
		old.on_hide()
		old.visible = false
	current_screen = key
	var s: GameScreen = screens[key]
	s.visible = true
	s.on_show(data)
	if not from_pause:
		menu_world.visible = true
		game_world.visible = false
		if menu_stage.camera:
			menu_stage.camera.current = true
		play_menu_music()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_fade_in()


func _hide_all_screens() -> void:
	for key in screens.keys():
		var s: GameScreen = screens[key]
		if s.visible:
			s.on_hide()
		s.visible = false
	current_screen = ""


func _abandon_match_if_needed() -> void:
	var active_states := [
		Config.MatchState.PREPARING, Config.MatchState.COUNTDOWN,
		Config.MatchState.ACTIVE, Config.MatchState.RESOLVING, Config.MatchState.RESULTS,
	]
	if Game.state in active_states:
		get_tree().paused = false
		Game.paused = false
		pause_menu.close()
		results.visible = false
		Game.return_to_menu()


func show_menu_back() -> void:
	if _overlay_return == "pause" and Game.state in [Config.MatchState.COUNTDOWN, Config.MatchState.ACTIVE]:
		_hide_all_screens()
		_overlay_return = ""
		pause_menu.open()
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		return
	show_screen("main_menu")


func close_settings() -> void:
	show_menu_back()


func _fade_in() -> void:
	if fade == null:
		return
	if _fade_tween and _fade_tween.is_valid():
		_fade_tween.kill()
	fade.modulate.a = 0.65
	_fade_tween = create_tween()
	_fade_tween.tween_property(fade, "modulate:a", 0.0, 0.24)


func _toast(text: String, color: Color = UiTheme.TEXT, duration: float = 3.2) -> void:
	if _toast_panel == null:
		return
	_toast_label.text = text
	_toast_label.add_theme_color_override("font_color", color)
	_toast_panel.visible = true
	_toast_panel.modulate.a = 1.0
	if _toast_tween and _toast_tween.is_valid():
		_toast_tween.kill()
	_toast_tween = create_tween()
	_toast_tween.tween_interval(duration)
	_toast_tween.tween_property(_toast_panel, "modulate:a", 0.0, 0.45)
	_toast_tween.tween_callback(func(): _toast_panel.visible = false)


# =============================================================== match lifecycle

func _on_game_state(new_state: int) -> void:
	print("STATE_CHANGED ", new_state, " t=", Time.get_ticks_msec())
	match new_state:
		Config.MatchState.PREPARING:
			_enter_match()
			loading.show_loading(Game.map_id)
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		Config.MatchState.COUNTDOWN, Config.MatchState.ACTIVE:
			get_tree().paused = false
			loading.hide_loading()
			menu_world.visible = false
			game_world.visible = true
			if menu_stage.camera:
				menu_stage.camera.current = false
			_ensure_hud()
			if hud:
				hud.visible = true
			Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
		Config.MatchState.RESULTS:
			get_tree().paused = false
			if hud:
				hud.visible = false
			Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
		Config.MatchState.MENU:
			_exit_to_menu()
		Config.MatchState.LOBBY:
			_exit_to_lobby()


func _enter_match() -> void:
	get_tree().paused = false
	print("ENTER_MATCH map=", Game.map_id)
	_last_result.clear()
	pause_menu.close()
	results.visible = false
	loading.hide_loading()
	_clear_hud()
	_hide_all_screens()
	menu_world.visible = false
	game_world.visible = true
	if menu_stage.camera:
		menu_stage.camera.current = false
	_overlay_return = ""
	Audio.play_music(Audio.MUSIC_GAME, 0.7)


func _exit_to_menu() -> void:
	get_tree().paused = false
	_in_match_cleanup()
	menu_world.visible = true
	game_world.visible = false
	if menu_stage.camera:
		menu_stage.camera.current = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_overlay_return = ""
	show_screen("main_menu")
	play_menu_music()


func _exit_to_lobby() -> void:
	get_tree().paused = false
	_in_match_cleanup()
	menu_world.visible = true
	game_world.visible = false
	if menu_stage.camera:
		menu_stage.camera.current = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_overlay_return = ""
	show_screen("lobby")
	play_menu_music()


func _in_match_cleanup() -> void:
	loading.hide_loading()
	pause_menu.close()
	results.visible = false
	_clear_hud()
	_last_result.clear()


func _on_loading_text(text: String) -> void:
	if loading and loading.visible:
		loading.set_status(text)


func _on_local_player_ready(p: Player) -> void:
	_clear_hud()
	_create_hud(p)
	if Game.state == Config.MatchState.COUNTDOWN or Game.state == Config.MatchState.ACTIVE:
		hud.visible = true


func _create_hud(p: Player) -> void:
	hud = GameHUD.new()
	hud.name = "GameHUD"
	hud_root.add_child(hud)
	hud.setup(p)
	if not p.pause_requested.is_connected(_open_pause):
		p.pause_requested.connect(_open_pause)


func _ensure_hud() -> void:
	if hud and is_instance_valid(hud):
		return
	var p := Game.local_player()
	if p:
		_create_hud(p)


func _clear_hud() -> void:
	if hud and is_instance_valid(hud):
		hud.visible = false
		hud.set_process(false)
		hud.queue_free()
	hud = null


func _on_match_ended(result: Dictionary) -> void:
	_last_result = result
	pause_menu.close()
	if hud:
		hud.visible = false
	results.set_result(result)
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE


# =============================================================== navigation API

func start_solo(config: Dictionary) -> void:
	get_tree().paused = false
	Game.paused = false
	pause_menu.close()
	results.visible = false
	_overlay_return = ""
	Game.start_solo(config)


func host_game(port: int, max_players: int) -> bool:
	var ok := Net.host_game(port, max_players)
	if ok:
		preview_map_id = Net.lobby_map
		_overlay_return = ""
		show_screen("lobby")
	return ok


func join_game(ip: String, port: int) -> bool:
	return Net.join_game(ip, port)


func begin_host_match() -> void:
	if Net.is_hosting():
		Game.host_start_match()


func leave_network() -> void:
	Net.leave()
	_overlay_return = ""
	show_screen("main_menu")
	play_menu_music()


func rematch() -> void:
	results.visible = false
	get_tree().paused = false
	Game.paused = false
	Game.request_rematch()


func return_to_lobby() -> void:
	results.visible = false
	get_tree().paused = false
	Game.paused = false
	Game.return_to_lobby()


func leave_match() -> void:
	get_tree().paused = false
	Game.paused = false
	pause_menu.close()
	results.visible = false
	Game.return_to_menu()


func quit_game() -> void:
	Settings.save_settings()
	get_tree().quit()


func play_menu_music() -> void:
	Audio.play_music(Audio.MUSIC_MENU)


func set_preview_map(id: String) -> void:
	preview_map_id = id
	if menu_stage and is_instance_valid(menu_stage):
		menu_stage.set_map(id)


func set_preview_character(id: String) -> void:
	if menu_stage and is_instance_valid(menu_stage):
		menu_stage.set_character(id)


# =============================================================== pause

func _open_pause() -> void:
	if current_screen == "settings" or current_screen == "how_to_play":
		show_menu_back()
		return
	if pause_menu.visible or results.visible:
		return
	if Game.state != Config.MatchState.ACTIVE and Game.state != Config.MatchState.COUNTDOWN:
		return
	if Game.is_solo:
		Game.pause_game(true)
		get_tree().paused = true
	else:
		var p := Game.local_player()
		if p:
			p.input_enabled = false
	pause_menu.open()
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	Audio.play_ui("click")


func resume_game() -> void:
	if not pause_menu.visible:
		return
	pause_menu.close()
	get_tree().paused = false
	if Game.is_solo:
		Game.pause_game(false)
	else:
		var p := Game.local_player()
		if p:
			p.input_enabled = true
	if Game.state == Config.MatchState.COUNTDOWN or Game.state == Config.MatchState.ACTIVE:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	Audio.play_ui("click")


func open_settings_from_pause() -> void:
	_overlay_return = "pause"
	pause_menu.close()
	show_screen("settings", {"from_pause": true})


func open_how_to_from_pause() -> void:
	_overlay_return = "pause"
	pause_menu.close()
	show_screen("how_to_play", {"from_pause": true})


# =============================================================== networking feedback

func _on_connection_succeeded() -> void:
	show_screen("lobby")
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	_toast("Connected to the host.", UiTheme.LIME)


func _on_server_disconnected() -> void:
	if current_screen == "lobby" or Game.state == Config.MatchState.LOBBY:
		Net.leave(false)
		show_screen("main_menu")
	_toast("Host disconnected. The party is over.", UiTheme.PINK, 4.0)


func _on_connection_failed(reason: String) -> void:
	_toast(reason, UiTheme.PINK, 4.0)


# =============================================================== input

func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("pause") or event.is_echo():
		return
	if pause_menu.visible:
		resume_game()
		get_viewport().set_input_as_handled()
	elif results.visible:
		pass
	elif Game.state == Config.MatchState.ACTIVE or Game.state == Config.MatchState.COUNTDOWN:
		_open_pause()
		get_viewport().set_input_as_handled()
	elif current_screen in ["settings", "how_to_play", "credits", "character", "solo", "network"]:
		show_menu_back()
		get_viewport().set_input_as_handled()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if Game.state == Config.MatchState.ACTIVE and Game.is_solo and current_screen.is_empty() and not get_tree().paused and not results.visible:
			_open_pause()
