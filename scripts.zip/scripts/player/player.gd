class_name Player
extends CharacterBody3D
## Shared human/AI character controller. Humans and bots feed the same action API.

signal prompt_changed(text: String)
signal stamina_changed(value: float)
signal emote_menu_requested
signal pause_requested
signal scoreboard_toggled(visible: bool)
signal hidden_changed(hidden: bool)
signal role_changed_local(role: int)
signal ability_used(kind: String)

const WALK_SPEED := 4.5
const SPRINT_MULT := 1.55
const CROUCH_MULT := 0.5
const CHASER_MULT := 1.13
const HELPER_SPEED := 8.5
const ACCEL := 30.0
const FRICTION := 24.0
const GRAVITY := 20.0
const JUMP_SPEED := 5.3
const MAX_STAMINA := 100.0
const STAMINA_DRAIN := 21.0
const STAMINA_REGEN := 16.0
const STAMINA_DELAY := 1.15
const CATCH_RANGE := 2.45
const CATCH_COOLDOWN := 2.0
const SENSE_COOLDOWN := 12.0
const HINT_COOLDOWN := 30.0

var peer_id := 1
var display_name := "Player"
var character_id := "barbarian"
var role := Config.Role.RUNNER
var is_bot := false
var is_local := false

var stamina := MAX_STAMINA
var hidden := false
var hiding_spot: Node = null
var stunned := false
var stun_timer := 0.0
var sprinting := false
var crouching := false
var held_prop := ""
var held_prop_id := ""
var catch_cd := 0.0
var sense_cd := 0.0
var hint_cd := 0.0
var alive := true
var frozen := false

var camera_yaw := 0.0
var camera_pitch := -0.15
var camera_shake := 0.0

var move_input := Vector2.ZERO
var bot_move := Vector3.ZERO
var bot_sprint := false
var bot_crouch := false
var bot_jump := false
var bot_aim := Vector3.ZERO
var input_enabled := true
var want_crouch_input := false
var want_sprint_input := false

var _stamina_delay := 0.0
var _foot_timer := 0.0
var _net_pos := Vector3.ZERO
var _net_yaw := 0.0
var _net_anim := "Idle"
var _net_hidden := false
var _anim_name := "Idle"
var _anim_speed := 1.0
var _shake_time := 0.0
var _interact_target: Node = null
var _prompt := ""
var _catch_target: Player = null
var _sense_marker_time := 0.0

var capsule: CollisionShape3D
var visual_root: Node3D
var model: Node3D
var anim: AnimationPlayer
var head: Node3D
var spring: SpringArm3D
var camera: Camera3D
var ray: RayCast3D
var name_label: Label3D
var role_label: Label3D
var role_ring: MeshInstance3D
var sense_marker: Node3D
var held_root: Node3D
var foot_player: AudioStreamPlayer3D
var _horns: Array[MeshInstance3D] = []


func configure(id: int, pname: String, char_id: String, bot: bool, local: bool) -> void:
	peer_id = id
	display_name = pname
	character_id = char_id
	is_bot = bot
	is_local = local


func _ready() -> void:
	collision_layer = 2
	collision_mask = 1 | 8
	floor_max_angle = deg_to_rad(50)
	floor_snap_length = 0.35
	_build_body()
	_build_visual()
	_build_labels()
	_build_camera()
	_build_interaction()
	if not is_local:
		collision_layer = 2
		collision_mask = 1
		if not is_bot:
			set_physics_process(false)
		set_process(true)
	else:
		set_process(true)
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if is_local and Game.state in [Config.MatchState.COUNTDOWN, Config.MatchState.ACTIVE] else Input.mouse_mode


func _build_body() -> void:
	capsule = CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.34
	shape.height = 1.7
	capsule.shape = shape
	capsule.position = Vector3(0, 0.85, 0)
	add_child(capsule)
	visual_root = Node3D.new()
	add_child(visual_root)


func _build_visual() -> void:
	var cdata := Config.character_data(character_id)
	var path: String = cdata["path"]
	if ResourceLoader.exists(path):
		var scene: PackedScene = load(path)
		model = scene.instantiate()
		visual_root.add_child(model)
		model.rotation.y = PI
		model.scale = Vector3.ONE * float(cdata["scale"])
		anim = _find_anim(model)
		if anim:
			anim.play("Idle", 0.1)
	held_root = Node3D.new()
	held_root.position = Vector3(0.34, 1.05, -0.28)
	visual_root.add_child(held_root)


func _find_anim(node: Node) -> AnimationPlayer:
	if node is AnimationPlayer:
		return node
	for child in node.get_children():
		var a := _find_anim(child)
		if a:
			return a
	return null


func _build_labels() -> void:
	var font: Font = load("res://assets/fonts/Fredoka.ttf")
	name_label = Label3D.new()
	name_label.text = display_name
	name_label.font = font
	name_label.font_size = 26
	name_label.pixel_size = 0.0045
	name_label.outline_size = 7
	name_label.outline_modulate = Color(0.02, 0.02, 0.03, 0.9)
	name_label.modulate = Color(1, 1, 1)
	name_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_label.position = Vector3(0, 2.28, 0)
	name_label.visible = not is_local
	add_child(name_label)

	role_label = Label3D.new()
	role_label.font = font
	role_label.font_size = 20
	role_label.pixel_size = 0.004
	role_label.outline_size = 6
	role_label.outline_modulate = Color(0.02, 0.02, 0.03, 0.9)
	role_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	role_label.position = Vector3(0, 2.06, 0)
	role_label.visible = not is_local
	add_child(role_label)

	role_ring = MeshInstance3D.new()
	var tm := TorusMesh.new()
	tm.inner_radius = 0.3
	tm.outer_radius = 0.37
	tm.rings = 20
	tm.ring_segments = 5
	role_ring.mesh = tm
	role_ring.position = Vector3(0, 2.0, 0)
	add_child(role_ring)

	sense_marker = Node3D.new()
	add_child(sense_marker)
	var beam := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.05
	cm.bottom_radius = 0.05
	cm.height = 2.6
	cm.radial_segments = 6
	beam.mesh = cm
	var bm := StandardMaterial3D.new()
	bm.albedo_color = Color(1.0, 0.2, 0.15, 0.5)
	bm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.emission_enabled = true
	bm.emission = Color(1.0, 0.15, 0.1)
	bm.emission_energy_multiplier = 2.5
	beam.material_override = bm
	beam.position = Vector3(0, 1.4, 0)
	sense_marker.add_child(beam)
	var ex := Label3D.new()
	ex.text = "!"
	ex.font = load("res://assets/fonts/LuckiestGuy.ttf")
	ex.font_size = 80
	ex.pixel_size = 0.005
	ex.modulate = Color(1.0, 0.25, 0.2)
	ex.outline_size = 12
	ex.outline_modulate = Color(0, 0, 0, 0.9)
	ex.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	ex.no_depth_test = true
	ex.position = Vector3(0, 2.9, 0)
	sense_marker.add_child(ex)
	sense_marker.visible = false
	_update_role_visual()


func _build_camera() -> void:
	head = Node3D.new()
	head.position = Vector3(0, 1.52, 0)
	add_child(head)
	spring = SpringArm3D.new()
	spring.spring_length = 3.4
	spring.margin = 0.22
	spring.collision_mask = 1
	head.add_child(spring)
	camera = Camera3D.new()
	camera.position = Vector3(0, 0, 3.4)
	camera.fov = Settings.fov
	camera.near = 0.05
	camera.current = is_local
	spring.add_child(camera)
	spring.add_excluded_object(get_rid())
	foot_player = AudioStreamPlayer3D.new()
	foot_player.bus = "SFX"
	foot_player.max_distance = 16.0
	foot_player.unit_size = 3.0
	add_child(foot_player)
	Settings.setting_changed.connect(_on_setting_changed)


func _build_interaction() -> void:
	ray = RayCast3D.new()
	ray.target_position = Vector3(0, 0, -3.3)
	ray.collision_mask = 1 | 4 | 8
	ray.collide_with_areas = true
	ray.collide_with_bodies = true
	ray.enabled = true
	camera.add_child(ray)
	ray.add_excluded_object(get_rid())


func _on_setting_changed(key: String, _value: Variant) -> void:
	if key == "fov" and camera:
		camera.fov = Settings.fov


func set_role(new_role: int) -> void:
	role = new_role as Config.Role
	alive = new_role != Config.Role.LOBBY
	if new_role == Config.Role.HELPER:
		collision_layer = 0
		collision_mask = 0
		visible = true
		if visual_root:
			visual_root.visible = false
		if name_label:
			name_label.visible = false
		if role_label:
			role_label.visible = false
		if role_ring:
			role_ring.visible = false
		spring.spring_length = 0.06
		camera.position.z = 0.06
		spring.collision_mask = 0
		head.position.y = 1.6
	elif new_role == Config.Role.LOBBY:
		frozen = true
	else:
		collision_layer = 2
		collision_mask = 1 | 8
		if visual_root:
			visual_root.visible = true
		if name_label:
			name_label.visible = not is_local
		if role_label:
			role_label.visible = not is_local
		if role_ring:
			role_ring.visible = true
		spring.spring_length = 3.4
		camera.position.z = 3.4
		spring.collision_mask = 1
		head.position.y = 1.52
	_update_role_visual()
	if is_local:
		role_changed_local.emit(role)


func _update_role_visual() -> void:
	if role_ring == null:
		return
	var col := Config.role_color(role)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	mat.emission_energy_multiplier = 1.3
	role_ring.material_override = mat
	if role_label:
		role_label.text = Config.role_name(role)
		role_label.modulate = col
	if name_label:
		name_label.modulate = Color(1, 1, 1) if role != Config.Role.HELPER else col.lightened(0.3)
	for h in _horns:
		h.visible = role == Config.Role.CHASER
	if role == Config.Role.CHASER and _horns.is_empty() and visual_root:
		_build_horns()
	elif role != Config.Role.CHASER:
		for h in _horns:
			h.visible = false


func _build_horns() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.75, 0.12, 0.12)
	mat.emission_enabled = true
	mat.emission = Color(0.9, 0.1, 0.08)
	mat.emission_energy_multiplier = 0.9
	for side in [-1.0, 1.0]:
		var horn := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 0.0
		cm.bottom_radius = 0.075
		cm.height = 0.28
		cm.radial_segments = 7
		horn.mesh = cm
		horn.material_override = mat
		horn.position = Vector3(side * 0.16, 1.82, 0.02)
		horn.rotation.z = side * 0.35
		visual_root.add_child(horn)
		_horns.append(horn)


func set_local(value: bool) -> void:
	is_local = value
	if camera:
		camera.current = value
	if name_label:
		name_label.visible = not value
	if role_label:
		role_label.visible = not value


func _unhandled_input(event: InputEvent) -> void:
	if not is_local or Game.paused or frozen:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED and not hidden:
		var sens := Settings.sensitivity * 0.0024
		camera_yaw -= event.relative.x * sens
		camera_pitch -= event.relative.y * sens * (1.0 if not Settings.invert_y else -1.0)
		camera_pitch = clampf(camera_pitch, -1.25, 0.72)
		get_viewport().set_input_as_handled()
	elif event.is_action_pressed("pause"):
		pause_requested.emit()
		get_viewport().set_input_as_handled()


func _physics_process(delta: float) -> void:
	if not is_local and not is_bot:
		return
	if frozen:
		return
	catch_cd = maxf(0.0, catch_cd - delta)
	sense_cd = maxf(0.0, sense_cd - delta)
	hint_cd = maxf(0.0, hint_cd - delta)
	if hidden:
		if is_local and input_enabled:
			if Input.is_action_just_pressed("interact"):
				Game.request_leave_hide(peer_id)
			if Input.is_action_just_pressed("emote"):
				emote_menu_requested.emit()
			if Input.is_action_just_pressed("scoreboard"):
				scoreboard_toggled.emit(true)
			elif Input.is_action_just_released("scoreboard"):
				scoreboard_toggled.emit(false)
		_update_camera(delta)
		_update_prompt()
		return
	if role == Config.Role.HELPER:
		_physics_helper(delta)
		_update_camera(delta)
		_update_prompt()
		return
	if stunned:
		stun_timer -= delta
		velocity.x = move_toward(velocity.x, 0.0, FRICTION * delta)
		velocity.z = move_toward(velocity.z, 0.0, FRICTION * delta)
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		if stun_timer <= 0.0:
			stunned = false
			visual_root.rotation.z = 0.0
		_update_camera(delta)
		_update_prompt()
		return
	if Game.state != Config.MatchState.ACTIVE or Game.paused:
		velocity.x = move_toward(velocity.x, 0.0, FRICTION * delta)
		velocity.z = move_toward(velocity.z, 0.0, FRICTION * delta)
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()
		_update_camera(delta)
		_update_prompt()
		return

	var input_vec := Vector2.ZERO
	if is_local and input_enabled:
		input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		if Input.is_action_just_pressed("interact"):
			do_interact()
		if Input.is_action_just_pressed("catch"):
			try_catch()
		if Input.is_action_just_pressed("throw"):
			try_throw()
		if Input.is_action_just_pressed("drop"):
			try_drop()
		if Input.is_action_just_pressed("sense"):
			use_ability()
		if Input.is_action_just_pressed("emote"):
			emote_menu_requested.emit()
		if Input.is_action_just_pressed("jump"):
			bot_jump = true
		if Input.is_action_just_pressed("scoreboard"):
			scoreboard_toggled.emit(true)
		elif Input.is_action_just_released("scoreboard"):
			scoreboard_toggled.emit(false)
		want_crouch_input = Input.is_action_pressed("crouch")
		want_sprint_input = Input.is_action_pressed("sprint")
	else:
		input_vec = Vector2(bot_move.x, bot_move.z)
		want_crouch_input = bot_crouch
		want_sprint_input = bot_sprint
		if bot_jump:
			bot_jump = false
			_try_jump()

	if is_bot:
		input_vec = Vector2(bot_move.x, bot_move.z)
		want_crouch_input = bot_crouch
		want_sprint_input = bot_sprint
		if bot_jump:
			bot_jump = false
			_try_jump()

	var move_dir := Vector3.ZERO
	if is_bot:
		move_dir = Vector3(bot_move.x, 0, bot_move.z)
		if move_dir.length() > 1.0:
			move_dir = move_dir.normalized()
	else:
		move_dir = Vector3(input_vec.x, 0, input_vec.y).rotated(Vector3.UP, camera_yaw)
		if move_dir.length() > 1.0:
			move_dir = move_dir.normalized()

	crouching = want_crouch_input and not sprinting
	var moving := move_dir.length_squared() > 0.01
	sprinting = want_sprint_input and moving and stamina > 4.0 and not crouching
	if sprinting:
		stamina = maxf(0.0, stamina - STAMINA_DRAIN * delta)
		_stamina_delay = STAMINA_DELAY
	else:
		_stamina_delay = maxf(0.0, _stamina_delay - delta)
		if _stamina_delay <= 0.0:
			stamina = minf(MAX_STAMINA, stamina + STAMINA_REGEN * delta)
	stamina_changed.emit(stamina)

	var speed := WALK_SPEED
	if role == Config.Role.CHASER:
		speed *= CHASER_MULT
	if crouching:
		speed *= CROUCH_MULT
	if sprinting:
		speed *= SPRINT_MULT
	var desired := move_dir * speed
	velocity.x = move_toward(velocity.x, desired.x, ACCEL * delta)
	velocity.z = move_toward(velocity.z, desired.z, ACCEL * delta)
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	if moving:
		var target_yaw := atan2(-move_dir.x, -move_dir.z)
		visual_root.rotation.y = lerp_angle(visual_root.rotation.y, target_yaw, minf(1.0, 12.0 * delta))
	move_and_slide()
	_update_crouch(delta)
	_update_camera(delta)
	_update_prompt()
	_update_animation(move_dir.length())
	_update_footsteps(delta)
	if is_local:
		Game.report_local_state(self)


func _try_jump() -> void:
	if is_on_floor() and not crouching:
		velocity.y = JUMP_SPEED


func _update_crouch(_delta: float) -> void:
	var target_height := 1.1 if crouching else 1.7
	var target_pos := 0.55 if crouching else 0.85
	var shape := capsule.shape as CapsuleShape3D
	if shape and absf(shape.height - target_height) > 0.01:
		shape.height = target_height
		capsule.position.y = target_pos
		head.position.y = 1.08 if crouching else 1.52


func _physics_helper(delta: float) -> void:
	var input_vec := Vector2.ZERO
	if is_local:
		input_vec = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
		if Input.is_action_just_pressed("sense"):
			use_ability()
		if Input.is_action_just_pressed("interact"):
			do_interact()
		if Input.is_action_just_pressed("emote"):
			emote_menu_requested.emit()
	else:
		input_vec = Vector2(bot_move.x, bot_move.z)
	var dir := Vector3(input_vec.x, 0, input_vec.y).rotated(Vector3.UP, camera_yaw)
	var vertical := 0.0
	if is_local:
		if Input.is_action_pressed("jump"):
			vertical += 1.0
		if Input.is_action_pressed("crouch"):
			vertical -= 1.0
	dir.y = vertical
	if dir.length() > 1.0:
		dir = dir.normalized()
	velocity = dir * HELPER_SPEED
	move_and_slide()
	_update_camera(delta)
	_update_prompt()
	if is_local:
		Game.report_local_state(self)


func _update_camera(delta: float) -> void:
	if not is_local:
		return
	head.rotation.y = camera_yaw
	spring.rotation.x = camera_pitch
	if hidden or role == Config.Role.HELPER:
		spring.spring_length = 0.06
		camera.position.z = 0.06
	else:
		spring.spring_length = 3.4
		camera.position.z = 3.4
	if _shake_time > 0.0:
		_shake_time -= delta
		var amp := 0.08 * Settings.camera_shake * clampf(_shake_time / 0.35, 0.0, 1.0)
		camera.h_offset = randf_range(-amp, amp)
		camera.v_offset = randf_range(-amp, amp)
	else:
		camera.h_offset = 0.0
		camera.v_offset = 0.0


func _update_prompt() -> void:
	var new_prompt := ""
	var target: Node = null
	if hidden:
		new_prompt = "Leave Hiding Spot"
	elif role == Config.Role.HELPER:
		new_prompt = ""
	else:
		ray.force_raycast_update()
		var collider := ray.get_collider()
		target = _find_interactable(collider)
		if target:
			new_prompt = str(target.get_prompt(self))
		if new_prompt.is_empty() and role == Config.Role.CHASER:
			_catch_target = _nearest_runner(CATCH_RANGE)
			if _catch_target:
				new_prompt = "CATCH %s" % _catch_target.display_name
		elif role != Config.Role.CHASER:
			_catch_target = null
	if new_prompt != _prompt:
		_prompt = new_prompt
		prompt_changed.emit(new_prompt)
	_interact_target = target


func _find_interactable(node: Node) -> Node:
	var n := node
	for i in 6:
		if n == null:
			return null
		if n.has_method("get_prompt") and n.has_method("interact"):
			return n
		n = n.get_parent()
	return null


func _nearest_runner(max_dist: float) -> Player:
	var best: Player = null
	var best_d := max_dist
	for p in Game.players.values():
		if p == self or not is_instance_valid(p):
			continue
		if p.role != Config.Role.RUNNER or p.hidden or not p.alive:
			continue
		var d := global_position.distance_to(p.global_position)
		if d < best_d and _has_line_of_sight(p):
			best_d = d
			best = p
	return best


func _has_line_of_sight(target: Player) -> bool:
	var space := get_world_3d().direct_space_state
	var q := PhysicsRayQueryParameters3D.create(
		global_position + Vector3(0, 1.2, 0),
		target.global_position + Vector3(0, 1.2, 0),
		1
	)
	q.exclude = [get_rid()]
	var hit := space.intersect_ray(q)
	return hit.is_empty()


func do_interact() -> void:
	if hidden:
		Game.request_leave_hide(peer_id)
		return
	if _interact_target and is_instance_valid(_interact_target):
		_interact_target.interact(self)


func try_catch() -> void:
	if role != Config.Role.CHASER or catch_cd > 0.0 or hidden or stunned:
		return
	var target := _nearest_runner(CATCH_RANGE)
	if target:
		Game.request_catch(peer_id, target.peer_id)
		catch_cd = CATCH_COOLDOWN
		_play_anim("Interact", 0.08, 1.35)
		Audio.play_3d("throw_swing", global_position, -8.0, 12.0)


func use_ability() -> void:
	if hidden or stunned:
		return
	if role == Config.Role.CHASER:
		if sense_cd <= 0.0:
			sense_cd = SENSE_COOLDOWN
			ability_used.emit("sense")
			Game.request_sense(peer_id)
			Audio.play_sfx("sparkle", -8.0, 0.9)
	elif role == Config.Role.HELPER:
		if hint_cd <= 0.0:
			hint_cd = HINT_COOLDOWN
			ability_used.emit("hint")
			Game.request_hint(peer_id)
			Audio.play_sfx("swap_chime", -6.0, 1.1)


func try_throw() -> void:
	if held_prop.is_empty() or hidden or stunned:
		return
	var origin := camera.global_position if is_local else global_position + Vector3(0, 1.3, 0)
	var dir := Vector3.ZERO
	if is_local:
		dir = -camera.global_transform.basis.z
	elif bot_aim.length() > 0.01:
		dir = bot_aim.normalized()
	else:
		dir = -visual_root.global_transform.basis.z
	Game.request_throw(peer_id, held_prop, origin, dir)
	held_prop = ""
	held_prop_id = ""
	_update_held_visual()
	_play_anim("Throw", 0.08, 1.2)


func try_drop() -> void:
	if held_prop.is_empty() or hidden:
		return
	var fwd := -visual_root.global_transform.basis.z
	Game.request_drop(peer_id, held_prop, global_position + Vector3(0, 0.4, 0) + fwd * 0.6)
	held_prop = ""
	held_prop_id = ""
	_update_held_visual()


func set_held(kind: String, id: String) -> void:
	held_prop = kind
	held_prop_id = id
	_update_held_visual()


func clear_held() -> void:
	held_prop = ""
	held_prop_id = ""
	_update_held_visual()


func _update_held_visual() -> void:
	if held_root == null:
		return
	for c in held_root.get_children():
		c.queue_free()
	if held_prop.is_empty():
		return
	var mat := StandardMaterial3D.new()
	match held_prop:
		"ball":
			mat.albedo_color = Color(0.95, 0.93, 0.88)
			var mi := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.14
			sm.height = 0.28
			mi.mesh = sm
			mi.material_override = mat
			held_root.add_child(mi)
		"pan":
			mat.albedo_color = Color(0.16, 0.16, 0.18)
			mat.metallic = 0.8
			var mi := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.2
			cm.bottom_radius = 0.16
			cm.height = 0.06
			mi.mesh = cm
			mi.material_override = mat
			mi.rotation.z = 0.4
			held_root.add_child(mi)
		"banana":
			mat.albedo_color = Color(1.0, 0.85, 0.18)
			var mi := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.08
			sm.height = 0.2
			mi.mesh = sm
			mi.material_override = mat
			held_root.add_child(mi)
		"bottle":
			mat.albedo_color = Color(0.35, 0.7, 0.95, 0.9)
			mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			var mi := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.05
			cm.bottom_radius = 0.06
			cm.height = 0.28
			mi.mesh = cm
			mi.material_override = mat
			held_root.add_child(mi)


func enter_hide(spot: Node) -> void:
	if hidden:
		return
	hiding_spot = spot
	hidden = true
	crouching = true
	capsule.set_deferred("disabled", true)
	collision_layer = 0
	collision_mask = 0
	visual_root.visible = false
	if name_label:
		name_label.visible = false
	if role_label:
		role_label.visible = false
	role_ring.visible = false
	sense_marker.visible = false
	if spot and is_instance_valid(spot):
		var exit_pos = spot.get("exit_position")
		if exit_pos is Vector3:
			global_position = exit_pos
	spring.spring_length = 0.06
	camera.position.z = 0.06
	spring.collision_mask = 0
	head.position.y = 1.45
	hidden_changed.emit(true)
	Audio.play_3d("creak", global_position, -8.0, 10.0)
	_prompt = "Leave Hiding Spot"
	prompt_changed.emit(_prompt)


func leave_hide(forced: bool = false) -> void:
	if not hidden:
		return
	if hiding_spot and is_instance_valid(hiding_spot):
		global_position = hiding_spot.exit_position + hiding_spot.global_transform.basis.z * 0.55
	hidden = false
	hiding_spot = null
	capsule.set_deferred("disabled", false)
	collision_layer = 2 if role != Config.Role.HELPER else 0
	collision_mask = 1 | 8 if role != Config.Role.HELPER else 0
	visual_root.visible = role != Config.Role.HELPER
	if name_label:
		name_label.visible = not is_local
	if role_label:
		role_label.visible = not is_local
	role_ring.visible = role != Config.Role.HELPER
	crouching = false
	spring.spring_length = 3.4
	camera.position.z = 3.4
	spring.collision_mask = 1 if role != Config.Role.HELPER else 0
	head.position.y = 1.52
	hidden_changed.emit(false)
	if not forced:
		_prompt = ""
		prompt_changed.emit("")


func set_hidden_state(value: bool, spot: Node = null) -> void:
	if value and not hidden:
		enter_hide(spot if spot else hiding_spot)
	elif not value and hidden:
		leave_hide(true)


func apply_stun(duration: float, _source: Vector3 = Vector3.ZERO, force: float = 0.0) -> void:
	if hidden:
		return
	if stunned:
		stun_timer = maxf(stun_timer, duration * 0.6)
		return
	stunned = true
	stun_timer = duration
	sprinting = false
	if force > 0.0:
		var away := (global_position - _source)
		away.y = 0
		if away.length() > 0.01:
			velocity += away.normalized() * force
	_play_anim("Hit_A", 0.06, 1.0)
	_shake_time = 0.35
	Audio.play_3d("impact", global_position, -6.0, 15.0)


func apply_slip(duration: float) -> void:
	if hidden:
		return
	stunned = true
	stun_timer = duration
	sprinting = false
	visual_root.rotation.z = PI * 0.42
	_play_anim("Hit_B", 0.05, 1.0)
	_shake_time = 0.3
	Audio.play_3d("slip", global_position, -4.0, 14.0)


func play_emote(emote_name: String) -> void:
	if hidden or role == Config.Role.HELPER:
		return
	Game.broadcast_emote(peer_id, emote_name)


func play_caught(swap: bool) -> void:
	if role == Config.Role.HELPER:
		return
	_play_anim("Cheer" if swap else "Hit_A", 0.08, 1.1)
	_shake_time = 0.4
	if is_local:
		Audio.play_sfx("swap_chime" if swap else "lose2", -5.0, 1.0)


func play_emote_visual(emote_name: String) -> void:
	match emote_name:
		"cheer":
			_play_anim("Cheer", 0.12, 1.0)
		"dodge":
			_play_anim("Dodge_Backward", 0.1, 1.0)
		"sit":
			_play_anim("Sit_Floor_Down", 0.1, 1.0)
		"punch":
			_play_anim("Unarmed_Melee_Attack_Punch_A", 0.08, 1.1)


func set_sense_marker(visible_now: bool, duration: float = 2.4) -> void:
	if sense_marker == null:
		return
	sense_marker.visible = visible_now
	_sense_marker_time = duration if visible_now else 0.0


func _update_animation(move_len: float) -> void:
	if anim == null:
		return
	var target := "Idle"
	var speed := 1.0
	if stunned:
		target = "Hit_A"
	elif crouching and move_len > 0.1:
		target = "Walking_C"
		speed = 0.8
	elif sprinting:
		target = "Running_A"
		speed = 1.05
	elif move_len > 0.1:
		target = "Walking_A"
		speed = 0.9 + clampf(velocity.length() / 8.0, 0.0, 0.5)
	elif crouching:
		target = "Idle"
		speed = 0.75
	_play_anim(target, 0.12, speed)


func _play_anim(anim_name: String, blend: float = 0.12, speed: float = 1.0) -> void:
	if anim == null:
		return
	if not anim.has_animation(anim_name):
		anim_name = "Idle"
		if not anim.has_animation(anim_name):
			return
	if _anim_name == anim_name:
		anim.speed_scale = speed
		return
	_anim_name = anim_name
	_anim_speed = speed
	anim.play(anim_name, blend)
	anim.speed_scale = speed


func _update_footsteps(delta: float) -> void:
	if foot_player == null:
		return
	if not is_on_floor() or velocity.length() < 0.8 or hidden:
		return
	_foot_timer -= delta
	if _foot_timer <= 0.0:
		_foot_timer = 0.42 if not sprinting else 0.27
		if not Audio.streams.has("footstep_wood"):
			return
		foot_player.stream = Audio.streams["footstep_wood"]
		foot_player.volume_db = -17.0 if crouching else (-11.0 if sprinting else -14.0)
		foot_player.pitch_scale = randf_range(0.9, 1.1)
		foot_player.play()


func _process(delta: float) -> void:
	if is_local or is_bot:
		if _sense_marker_time > 0.0:
			_sense_marker_time -= delta
			if _sense_marker_time <= 0.0:
				sense_marker.visible = false
		return
	if _net_hidden:
		global_position = global_position.lerp(_net_pos, clampf(delta * 16.0, 0.0, 1.0))
		return
	var d := global_position.distance_to(_net_pos)
	if d > 4.0:
		global_position = _net_pos
	else:
		global_position = global_position.lerp(_net_pos, clampf(delta * 13.0, 0.0, 1.0))
	visual_root.rotation.y = lerp_angle(visual_root.rotation.y, _net_yaw, clampf(delta * 12.0, 0.0, 1.0))
	if _net_anim != _anim_name:
		_play_anim(_net_anim, 0.15, _anim_speed)
		if _net_anim == "Running_A":
			anim.speed_scale = 1.05


func apply_net_state(pos: Vector3, yaw: float, anim_name: String, is_hidden: bool, is_sprinting: bool) -> void:
	_net_pos = pos
	_net_yaw = yaw
	_net_anim = anim_name
	_net_hidden = is_hidden
	_anim_speed = 1.05 if is_sprinting else 1.0
	if is_hidden and not hidden:
		hidden = true
		visual_root.visible = false
		if name_label:
			name_label.visible = false
		if role_label:
			role_label.visible = false
		role_ring.visible = false
	elif not is_hidden and hidden and not is_local:
		hidden = false
		visual_root.visible = role != Config.Role.HELPER
		if name_label:
			name_label.visible = true
		if role_label:
			role_label.visible = true
		role_ring.visible = role != Config.Role.HELPER


func net_state() -> Dictionary:
	return {
		"pos": global_position,
		"yaw": visual_root.rotation.y,
		"anim": _anim_name,
		"hidden": hidden,
		"sprint": sprinting,
	}


func set_frozen(value: bool) -> void:
	frozen = value
	if value:
		velocity = Vector3.ZERO
		_prompt = ""
		prompt_changed.emit("")


func celebrate(win: bool) -> void:
	if role == Config.Role.HELPER:
		return
	_play_anim("Cheer" if win else "Hit_A", 0.2, 1.0)
